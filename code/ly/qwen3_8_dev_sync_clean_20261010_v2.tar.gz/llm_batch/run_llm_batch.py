"""Resume-safe LLM batch runner for frozen citation-verification inputs.

Set one of:
  ANTHROPIC_BASE_URL + ANTHROPIC_AUTH_TOKEN + ANTHROPIC_MODEL
  OPENAI_BASE_URL + OPENAI_API_KEY + OPENAI_MODEL
  ALI_API_KEY  (DashScope compatible-mode, default model qwen-plus)
"""

from __future__ import annotations

import argparse
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

from prompt_common import LABELS, parse_model_json

REQUIRED = {"claim_id", "label", "evidence_ids", "reason", "confidence", "failure_status"}

OUTPUT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "claim_id",
        "label",
        "evidence_ids",
        "reason",
        "confidence",
        "failure_status",
    ],
    "properties": {
        "claim_id": {"type": "integer"},
        "label": {
            "type": "string",
            "enum": ["ACCURATE", "NOT_ACCURATE", "IRRELEVANT"],
        },
        "evidence_ids": {
            "type": "array",
            "items": {"type": "string", "pattern": "^D[0-9]{2}:S[0-9]{2}$"},
            "maxItems": 5,
        },
        "reason": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "failure_status": {"type": ["string", "null"]},
    },
}


def load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def append_jsonl(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, ensure_ascii=False) + "\n")


def detect_provider(explicit: str | None) -> str:
    if explicit:
        return explicit
    if os.environ.get("ANTHROPIC_AUTH_TOKEN") and os.environ.get("ANTHROPIC_BASE_URL"):
        return "anthropic"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    if os.environ.get("ALI_API_KEY"):
        return "ali"
    raise SystemExit("No API credentials found. Set ANTHROPIC_*, OPENAI_*, or ALI_API_KEY.")


def call_anthropic(system: str, user: str, timeout: float) -> tuple[int, str, str]:
    base = os.environ["ANTHROPIC_BASE_URL"].rstrip("/")
    model = os.environ.get("ANTHROPIC_MODEL") or "claude-sonnet-4-5"
    response = httpx.post(
        base + "/v1/messages",
        headers={
            "x-api-key": os.environ["ANTHROPIC_AUTH_TOKEN"],
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": model,
            "max_tokens": 800,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        },
        timeout=timeout,
    )
    if response.status_code >= 400:
        return response.status_code, "", response.text
    data = response.json()
    pieces = []
    for block in data.get("content") or []:
        if isinstance(block, dict) and block.get("type") == "text":
            pieces.append(block.get("text") or "")
    return response.status_code, "".join(pieces), response.text


def call_openai_compatible(system: str, user: str, timeout: float, ali: bool) -> tuple[int, str, str, str]:
    if ali:
        url = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
        key = os.environ["ALI_API_KEY"]
        model = os.environ.get("ALI_MODEL") or "qwen-plus"
    else:
        url = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/") + "/chat/completions"
        key = os.environ["OPENAI_API_KEY"]
        model = os.environ.get("OPENAI_MODEL") or "gpt-4o-mini"
    response = httpx.post(
        url,
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={
            "model": model,
            "temperature": 0,
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "citation_verification",
                    "schema": OUTPUT_SCHEMA,
                },
            },
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        },
        timeout=timeout,
    )
    if response.status_code >= 400:
        return response.status_code, "", response.text, model
    data = response.json()
    text = (((data.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
    return response.status_code, text, response.text, model


def normalize_output(claim_id: int, payload: dict | None, allowed: set[str], parse_error: str | None) -> dict:
    if parse_error or payload is None:
        return {
            "claim_id": claim_id,
            "label": "IRRELEVANT",
            "evidence_ids": [],
            "reason": "模型输出无法解析。",
            "confidence": 0.0,
            "failure_status": parse_error or "invalid_output",
        }
    issues = []
    extra = set(payload) - REQUIRED
    missing = REQUIRED - set(payload)
    if extra or missing:
        issues.append("field_mismatch")
    label = payload.get("label")
    if label not in LABELS:
        issues.append("invalid_label")
        label = "IRRELEVANT"
    evidence_ids = payload.get("evidence_ids") or []
    if not isinstance(evidence_ids, list):
        evidence_ids = []
        issues.append("invalid_evidence_ids")
    evidence_ids = [str(item) for item in evidence_ids]
    if len(evidence_ids) != len(set(evidence_ids)) or len(evidence_ids) > 5:
        issues.append("evidence_ids_constraint")
    invalid = sorted(set(evidence_ids) - allowed)
    if invalid:
        issues.append("evidence_id_out_of_range")
        evidence_ids = [item for item in evidence_ids if item in allowed]
    reason = payload.get("reason")
    if not isinstance(reason, str) or not 1 <= len(reason) <= 120:
        issues.append("invalid_reason")
        reason = (reason if isinstance(reason, str) else "理由缺失")[:120] or "理由缺失"
    confidence = payload.get("confidence")
    if not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or not 0 <= float(confidence) <= 1:
        issues.append("invalid_confidence")
        confidence = 0.0
    failure = payload.get("failure_status")
    if failure is False or failure == 0:
        failure = None
    if isinstance(failure, str) and failure.strip().lower() in {"success", "ok", "none", "null", "pass", "false", "no", "0", ""}:
        failure = None
    if failure is not None and not isinstance(failure, str):
        issues.append("invalid_failure_status")
        failure = "invalid_failure_status"
    if issues and not failure:
        failure = ",".join(issues)
    return {
        "claim_id": int(payload.get("claim_id", claim_id)),
        "label": label,
        "evidence_ids": evidence_ids,
        "reason": reason,
        "confidence": float(confidence),
        "failure_status": failure,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--provider", choices=["anthropic", "openai", "ali"])
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--sleep", type=float, default=0.4)
    parser.add_argument("--timeout", type=float, default=120)
    args = parser.parse_args()
    provider = detect_provider(args.provider)
    inputs = load_jsonl(args.inputs)
    if args.limit:
        inputs = inputs[: args.limit]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    out_path = args.out_dir / "model_outputs.jsonl"
    raw_path = args.out_dir / "raw_responses.jsonl"
    done = {int(row["claim_id"]) for row in load_jsonl(out_path)}
    meta = {
        "provider": provider,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "input_file": str(args.inputs),
        "already_done": len(done),
        "todo": len(inputs),
    }
    (args.out_dir / "run_metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    ok = 0
    failed = 0
    for row in inputs:
        claim_id = int(row["claim_id"])
        if claim_id in done:
            continue
        try:
            if provider == "anthropic":
                status, text, raw = call_anthropic(row["system_prompt"], row["user_prompt"], args.timeout)
                model = os.environ.get("ANTHROPIC_MODEL")
            elif provider == "ali":
                status, text, raw, model = call_openai_compatible(row["system_prompt"], row["user_prompt"], args.timeout, True)
            else:
                status, text, raw, model = call_openai_compatible(row["system_prompt"], row["user_prompt"], args.timeout, False)
        except Exception as exc:
            status, text, raw, model = 0, "", str(exc), provider
        if status >= 400 or status == 0:
            parsed, parse_error = None, f"http_{status or 'exception'}"
        else:
            parsed, parse_error = parse_model_json(text)
        output = normalize_output(claim_id, parsed, set(row.get("allowed_evidence_ids") or []), parse_error)
        output["model_name"] = model
        append_jsonl(out_path, output)
        append_jsonl(
            raw_path,
            {
                "claim_id": claim_id,
                "http_status": status,
                "model": model,
                "raw_text": text,
                "raw_body_head": (raw or "")[:2000],
            },
        )
        done.add(claim_id)
        if output["failure_status"]:
            failed += 1
        else:
            ok += 1
        print(f"claim_id={claim_id} status={status} failure={output['failure_status']}", flush=True)
        if status in {401, 402, 403}:
            print("FATAL_AUTH_OR_BILLING", flush=True)
            raise SystemExit(2)
        time.sleep(args.sleep)
    print(json.dumps({"done": len(done), "new_ok": ok, "new_failed": failed, "out": str(out_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
