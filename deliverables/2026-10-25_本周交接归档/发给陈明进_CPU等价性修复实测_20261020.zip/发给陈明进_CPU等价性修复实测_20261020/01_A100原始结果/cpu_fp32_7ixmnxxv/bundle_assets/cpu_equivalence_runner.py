"""CPU FP32, tiny real Qwen3.5 text architecture, LoRA, actual Trainer.train.

Synthetic fixtures use the official tokenizer/template and complete vocabulary.
This is a training-logic test, not a 27B quantized reproducibility claim.
"""
import gc
import hashlib
import importlib.metadata
import inspect
import json
import math
from pathlib import Path
from types import SimpleNamespace

LOSS_ATOL, LOSS_RTOL = 1e-6, 1e-5
TENSOR_ATOL, TENSOR_RTOL = 1e-6, 1e-4
TARGETS = ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']


def need(value, message):
    if not value:
        raise RuntimeError(message)


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def file_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def loss_close(a, b):
    return math.isfinite(a) and math.isfinite(b) and abs(a-b) <= LOSS_ATOL + LOSS_RTOL * abs(b)


def run(output, assets, model_path, package_info):
    import torch
    import torch.nn.functional as F
    from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer, Trainer, TrainerCallback, TrainingArguments, set_seed
    from peft import LoraConfig, TaskType, get_peft_model
    from cmj.route1_qwen38_train_sarol_memopt_v1 import SupervisedLogitsTrainer
    from cmj.route1_memopt_before_fix import SupervisedLogitsTrainer as BeforeFixTrainer
    from shared.route1_qwen38.data_contract import AssistantOnlyCollator, encode_assistant_record

    need(not torch.cuda.is_initialized(), 'CPU verification must not initialize CUDA')
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    versions = {n: importlib.metadata.version(n) for n in ['torch','transformers','peft','accelerate','datasets']}
    need(versions['transformers'] == '5.8.0', 'Expected the observed transformers 5.8.0 environment')
    need(versions['peft'] == '0.21.2' and versions['accelerate'] == '1.14.0', 'PEFT/Accelerate versions differ')
    tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True, trust_remote_code=False)
    need(tokenizer.eos_token_id is not None, 'Official tokenizer has no EOS')
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    side = tokenizer.padding_side
    need(side in ['left','right'], 'Unknown official padding side')
    full_config = AutoConfig.from_pretrained(str(model_path), local_files_only=True, trust_remote_code=False)
    text = getattr(full_config, 'text_config', full_config)
    need(type(text).__name__ == 'Qwen3_5TextConfig', 'Expected Qwen3_5TextConfig')
    cfg = text.to_dict()
    # Keep the complete official vocabulary; reduce network width/depth only.
    cfg.update(hidden_size=32, intermediate_size=64, num_hidden_layers=4,
               num_attention_heads=1, num_key_value_heads=1, head_dim=32,
               linear_conv_kernel_dim=4, linear_key_head_dim=8, linear_value_head_dim=8,
               linear_num_key_heads=2, linear_num_value_heads=4,
               layer_types=['linear_attention']*3 + ['full_attention'],
               max_position_embeddings=2048, use_cache=False, attention_dropout=0.0,
               tie_word_embeddings=False, dtype='float32', pad_token_id=tokenizer.pad_token_id,
               bos_token_id=tokenizer.bos_token_id, eos_token_id=tokenizer.eos_token_id,
               rope_parameters={'rope_type':'default','rope_theta':10000.0,
                                'partial_rotary_factor':0.25,'mrope_section':[1,1,2],
                                'mrope_interleaved':True})
    cfg.pop('quantization_config', None)
    tiny_config = type(text).from_dict(cfg)
    tiny_config._attn_implementation = 'eager'
    write(output/'tiny_config.json', tiny_config.to_dict())
    vocab_size = tiny_config.vocab_size
    records, features = [], []
    for i in range(29):
        record = {'claim_id':f'cpu_fixture_{i:02}',
                  'label':['ACCURATE','NOT_ACCURATE','IRRELEVANT'][i%3],
                  'system_prompt':'Return the citation label as JSON.',
                  'user_prompt':f'CPU numerical fixture {i}. ' + 'Evidence. '*(i%3+1)}
        feature = encode_assistant_record(record, tokenizer, 2048)
        need(max(feature['input_ids']) < vocab_size, 'Fixture token exceeds complete model vocabulary')
        need(feature['labels'][0] == -100, 'The first token must not be a causal target')
        need(any(t == tokenizer.eos_token_id for t in feature['labels']), 'Real assistant EOS is not supervised')
        records.append(record)
        features.append(feature)
    need(len({sum(t!=-100 for t in f['labels']) for f in features})>=2, 'Target lengths must vary')
    write(output/'fixtures.json', {'scope':'Synthetic CPU-only numerical fixtures, not a Train/Test evaluation split',
                                  'official_tokenizer':str(model_path), 'enable_thinking':False,
                                  'records':records,'features':features})
    runtime_source = '\n\n'.join(inspect.getsource(x) for x in
        [Trainer.training_step, Trainer.compute_loss, Trainer._inner_training_loop, SupervisedLogitsTrainer])
    (output/'actual_trainer_sources.txt').write_text(runtime_source, encoding='utf-8')

    def snapshot(model, gradients=False):
        values, missing = {}, []
        for name, p in model.named_parameters():
            if not p.requires_grad:
                continue
            value = p.grad if gradients else p
            if value is None:
                missing.append(name)
                continue
            need(value.dtype == torch.float32 and value.device.type == 'cpu', 'Expected CPU FP32 tensors')
            need(bool(torch.isfinite(value).all()), 'Nonfinite LoRA tensor: '+name)
            values[name] = value.detach().clone()
        need(bool(values), 'Empty trainable tensor set')
        return values, missing

    def compare(actual, reference):
        a, am = actual
        b, bm = reference
        names = set(a)|set(b)
        details = []
        for name in sorted(names):
            if name not in a or name not in b or a[name].shape != b[name].shape:
                details.append({'name':name,'passed':False,'reason':'missing tensor or shape mismatch'})
                continue
            diff = float((a[name]-b[name]).abs().max())
            passed = bool(torch.allclose(a[name], b[name], atol=TENSOR_ATOL, rtol=TENSOR_RTOL))
            details.append({'name':name,'passed':passed,'max_abs':diff})
        return {'passed':bool(names) and not am and not bm and set(a)==set(b) and all(x['passed'] for x in details),
                'missing_actual_gradients':am,'missing_reference_gradients':bm,
                'max_abs':max((x.get('max_abs',0.0) for x in details),default=0.0),
                'parameter_count':len(details),'per_parameter':details}

    def make_model():
        set_seed(42)
        base = AutoModelForCausalLM.from_config(tiny_config, trust_remote_code=False)
        need(type(base).__name__ == 'Qwen3_5ForCausalLM', 'Unexpected tiny model architecture')
        for p in base.parameters(): p.requires_grad_(False)
        model = get_peft_model(base, LoraConfig(r=16,lora_alpha=32,lora_dropout=0.0,
                                target_modules=TARGETS,bias='none',task_type=TaskType.CAUSAL_LM))
        model.to(device='cpu', dtype=torch.float32)
        generator = torch.Generator(device='cpu').manual_seed(314159)
        with torch.no_grad():
            for n,p in model.named_parameters():
                if p.requires_grad:
                    need('lora_' in n, 'Unexpected non-LoRA trainable parameter')
                    p.copy_(torch.randn(p.shape,generator=generator,dtype=torch.float32)*0.02)
        for module in model.modules():
            if isinstance(module,torch.nn.Dropout):
                need(module.p==0.0,'Dropout must be disabled for this numerical test')
        return model

    model = make_model()
    trainable_initial, missing = snapshot(model)
    need(not missing, 'Missing trainable initialization')
    need(any('lora_A' in n for n in trainable_initial) and any('lora_B' in n for n in trainable_initial), 'LoRA A/B not covered')
    need(all(bool(v.ne(0).any()) for v in trainable_initial.values()), 'Degenerate all-zero LoRA tensor')
    base_before = hashlib.sha256()
    for n,p in model.named_parameters():
        if not p.requires_grad:
            base_before.update(n.encode()); base_before.update(p.detach().contiguous().numpy().tobytes())
    base_initial_sha = base_before.hexdigest()

    class Collator:
        def __init__(self,padded,eos_pad):
            self.padded = padded
            self.pad_id = tokenizer.eos_token_id if eos_pad else tokenizer.pad_token_id
            self.base = AssistantOnlyCollator(SimpleNamespace(pad_token_id=self.pad_id,padding_side=side))
        def __call__(self,rows):
            need(len(rows)==1,'Actual microbatch must be 1')
            row = dict(rows[0]); index = row.pop('_audit_index')
            if self.padded:
                extra = 3 + index%5
                for key,fill in [('input_ids',self.pad_id),('attention_mask',0),('labels',-100)]:
                    values = [fill]*extra
                    row[key] = row[key]+values if side=='right' else values+row[key]
            batch = self.base([row])
            padding = batch['attention_mask']==0
            need(bool(batch['labels'][padding].eq(-100).all()),'Padding has supervised targets')
            need(bool(((batch['input_ids']==tokenizer.eos_token_id)&batch['labels'].ne(-100)).any()),'Assistant EOS was incorrectly masked')
            batch['_audit_index'] = torch.tensor([index])
            return batch

    class ObserveMixin:
        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            source_labels = inputs['labels']
            loss, outputs = super().compute_loss(model,dict(inputs),return_outputs=True,num_items_in_batch=num_items_in_batch)
            need(outputs.logits.shape[-1]==vocab_size,'Logits do not cover full tiny model vocabulary')
            need(loss.dtype==torch.float32 and bool(torch.isfinite(loss)),'Nonfinite/non-FP32 loss')
            self._raw_loss = float(loss.detach())
            if self._branch=='standard':
                with torch.no_grad():
                    # Independent token-sum oracle, shift t-1 -> t, no per-micro mean.
                    shifted = F.pad(source_labels,(0,1),value=-100)[:,1:]
                    summed = F.cross_entropy(outputs.logits.float().reshape(-1,vocab_size),shifted.reshape(-1),ignore_index=-100,reduction='sum')
                    denominator = num_items_in_batch if num_items_in_batch is not None else shifted.ne(-100).sum()
                    expected = float(summed/denominator)
                need(loss_close(self._raw_loss,expected),'Native reference loss disagrees with token-sum oracle')
                self._oracle_loss = expected
            return (loss,outputs) if return_outputs else loss
        def training_step(self,model,inputs,num_items_in_batch=None):
            inputs = dict(inputs); index = int(inputs.pop('_audit_index').item())
            signature = {k:inputs[k].tolist() for k in ['input_ids','attention_mask','labels']}
            row = {'micro_step':len(self._micros)+1,'sample_index':index,
                   'batch_sha256':hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest(),
                   'supervised_tokens':int(inputs['labels'][:,1:].ne(-100).sum()),
                   'padding_tokens':int(inputs['attention_mask'].eq(0).sum()),
                   'num_items_in_batch':int(num_items_in_batch) if num_items_in_batch is not None else None,
                   'actual_accumulation_steps':int(self.current_gradient_accumulation_steps),
                   'model_accepts_loss_kwargs':bool(self.model_accepts_loss_kwargs)}
            result = super().training_step(model,inputs,num_items_in_batch=num_items_in_batch)
            row.update(raw_loss=self._raw_loss,returned_scaled_loss=float(result))
            gradients = snapshot(model,True)
            if self._branch=='standard':
                row['oracle_loss'] = self._oracle_loss
                self._reference.append({'row':dict(row),'gradients':gradients})
            else:
                ref = self._reference[len(self._micros)]
                row['same_batch'] = row['batch_sha256']==ref['row']['batch_sha256']
                row['raw_loss_close'] = loss_close(row['raw_loss'],ref['row']['raw_loss'])
                row['scaled_loss_close'] = loss_close(row['returned_scaled_loss'],ref['row']['returned_scaled_loss'])
                row['scaled_loss_abs_diff'] = abs(row['returned_scaled_loss']-ref['row']['returned_scaled_loss'])
                row['gradients_before_clipping'] = compare(gradients,ref['gradients'])
                row['passed'] = row['same_batch'] and row['raw_loss_close'] and row['scaled_loss_close'] and row['gradients_before_clipping']['passed']
            self._micros.append(row)
            print(f"CPU_MICRO case={self._case} branch={self._branch} step={row['micro_step']} tokens={row['supervised_tokens']} cycle_tokens={row['num_items_in_batch']} loss={row['raw_loss']:.8f}",flush=True)
            return result

    class Standard(ObserveMixin,Trainer): pass
    class Fixed(ObserveMixin,SupervisedLogitsTrainer): pass
    class Original(ObserveMixin,BeforeFixTrainer): pass

    def one_case(name,count,accum,padded,eos_pad=False,negative=False):
        directory = output/name
        directory.mkdir()
        references, reference_updates, branches = [], [], {}
        used = features[:count]
        dataset = [{**f,'_audit_index':i} for i,f in enumerate(used)]
        for branch,cls in [('standard',Standard),('original_before_fix' if negative else 'fixed',Original if negative else Fixed)]:
            with torch.no_grad():
                for n,p in model.named_parameters():
                    if p.requires_grad: p.copy_(trainable_initial[n])
            model.zero_grad(set_to_none=True)
            state_initial_sha = hashlib.sha256(b''.join(v.contiguous().numpy().tobytes() for v in snapshot(model)[0].values())).hexdigest()
            updates = []

            class Callback(TrainerCallback):
                def on_train_begin(self,args,state,control,**kwargs):
                    need(not kwargs['optimizer'].state_dict()['state'],'Optimizer did not start from identical empty state')
                def on_step_end(self,args,state,control,**kwargs):
                    params = snapshot(kwargs['model'])
                    changed = any(not torch.equal(v,trainable_initial[n]) for n,v in params[0].items())
                    row = {'global_step':int(state.global_step),'parameters_changed_from_initial':changed}
                    if branch=='standard': reference_updates.append(params)
                    else: row['parameters_after_update'] = compare(params,reference_updates[len(updates)])
                    updates.append(row)
            arguments = TrainingArguments(output_dir=str(directory/branch),num_train_epochs=1,
                per_device_train_batch_size=1,gradient_accumulation_steps=accum,learning_rate=1e-4,
                optim='adamw_torch',lr_scheduler_type='constant',warmup_steps=0,weight_decay=0.0,
                max_grad_norm=1.0,bf16=False,fp16=False,use_cpu=True,
                gradient_checkpointing=False,report_to='none',seed=42,data_seed=42,
                remove_unused_columns=False,dataloader_drop_last=False,dataloader_num_workers=0,
                dataloader_pin_memory=False,save_strategy='no',logging_strategy='no',disable_tqdm=True)
            trainer = cls(model=model,args=arguments,train_dataset=dataset,
                          data_collator=Collator(padded,eos_pad),callbacks=[Callback()])
            trainer._case=name;trainer._branch=branch;trainer._reference=references;trainer._micros=[]
            if branch=='standard':
                need(trainer.model_accepts_loss_kwargs,'Native reference is not using cycle token count')
            elif not negative:
                need(trainer.model_accepts_loss_kwargs,'Fixed actual trainer is not accepting cycle token count')
            result = trainer.train()
            micros = trainer._micros
            need(len(micros)==count and sorted(x['sample_index'] for x in micros)==list(range(count)),'Missing/repeated fixture')
            need(len(updates)==math.ceil(count/accum),'Missing optimizer update')
            need(all(x['parameters_changed_from_initial'] for x in updates),'Parameter-update check is degenerate')
            for start in range(0,count,accum):
                cycle = micros[start:start+accum]
                need(all(x['actual_accumulation_steps']==len(cycle) for x in cycle),'Tail cycle divisor wrong')
                if branch=='standard' or not negative:
                    need(all(x['num_items_in_batch']==sum(v['supervised_tokens'] for v in cycle) for x in cycle),'Effective token denominator wrong')
            need(all((r['padding_tokens']>0)==padded for r in micros),'Actual padding coverage differs')
            passed = True if branch=='standard' else all(r['passed'] for r in micros) and all(u['parameters_after_update']['passed'] for u in updates)
            branches[branch] = {'passed':passed,'initial_trainable_sha256':state_initial_sha,
                'microbatches':micros,'updates':updates,'train_result':result.metrics}
            write(directory/(branch+'.json'),branches[branch])
            trainer.optimizer.state.clear();trainer.optimizer=None;trainer.lr_scheduler=None
            del trainer
            model.zero_grad(set_to_none=True)
            gc.collect()
        need(len({v['initial_trainable_sha256'] for v in branches.values()})==1,'Initial LoRA parameters differ')
        candidate = branches['original_before_fix' if negative else 'fixed']
        numeric_difference = any(not r['scaled_loss_close'] or not r['gradients_before_clipping']['passed'] for r in candidate['microbatches'])
        result = {'count':count,'accumulation':accum,'padded':padded,'eos_equals_pad_test':eos_pad,
                  'branches':branches,'passed':not candidate['passed'] and numeric_difference if negative else candidate['passed'],
                  'scope':'expected rejection of original normalization' if negative else 'fixed actual Trainer comparison',
                  'actual_numeric_difference_detected':numeric_difference}
        write(directory/'case_result.json',result)
        print(f"CPU_CASE {name} {'PASS' if result['passed'] else 'FAIL'}",flush=True)
        del references, reference_updates
        gc.collect()
        return {'passed':result['passed'],'count':count,'accumulation':accum,'padded':padded,
                'expected_negative':negative,'artifact':str(directory/'case_result.json')}

    summary = {'status':'RUNNING','versions':versions,'package':package_info,
               'model_class':type(model.get_base_model()).__name__,'tiny_model_vocab_size':vocab_size,
               'official_full_vocabulary_preserved':vocab_size==text.vocab_size,
               'actual_candidate_trainer_sha256':file_sha(assets/'code/cmj/route1_qwen38_train_sarol_memopt_v1.py'),
               'dropout':0.0,'nonzero_lora_A_and_B_initialization':True,'original_training_dropout':0.05,
               'padding_side':side,'precision':'CPU FP32, no quantization',
               'tolerances':{'loss_atol':LOSS_ATOL,'loss_rtol':LOSS_RTOL,'gradient_and_parameter_atol':TENSOR_ATOL,'gradient_and_parameter_rtol':TENSOR_RTOL},
               'optimizer':'AdamW torch; fresh identical state; lr=1e-4; constant schedule; max_grad_norm=1.0',
               'cases':{},'official_27B_weights_loaded':False,'frozen_adapters_modified':False,
               'scope':'Tiny real text architecture and actual LoRA/Trainer logic only; not 27B/NF4 numerical equivalence or revised classification evaluation'}
    write(output/'summary.json',summary)
    for name,count,accum,padded,eos_pad,negative in [
        ('single_micro',3,1,False,False,False),('accum4_tail',5,4,False,False,False),
        ('padded_accum4_tail',5,4,True,False,False),
        ('production_accum16_tail13',29,16,False,False,False),
        ('eos_as_pad_accum4_tail',5,4,True,True,False),
        ('negative_original_normalization',5,4,True,False,True)]:
        summary['cases'][name] = one_case(name,count,accum,padded,eos_pad,negative)
        write(output/'summary.json',summary)
    # Reject empty/asymmetric comparisons, rather than accepting empty maxima.
    summary['empty_and_asymmetric_tensors_rejected'] = (
        not compare(({},[]),({},[]))['passed'] and
        not compare(({'A':torch.ones(2)},[]),({'B':torch.ones(2)},[]))['passed'])
    need(summary['empty_and_asymmetric_tensors_rejected'],'Empty/asymmetric gradients accepted')
    base_after = hashlib.sha256()
    for n,p in model.named_parameters():
        if not p.requires_grad:
            base_after.update(n.encode());base_after.update(p.detach().contiguous().numpy().tobytes())
    need(base_after.hexdigest()==base_initial_sha,'Frozen tiny base parameters changed')
    need(not torch.cuda.is_initialized(),'CPU verification initialized CUDA')
    summary['cuda_initialized']=False
    summary['tiny_base_parameters_unchanged']=True
    summary['status']='CPU_FP32_ACTUAL_QWEN_LORA_TRAINER_PASS_NOT_27B_EQUIVALENCE' if all(v['passed'] for v in summary['cases'].values()) else 'CPU_FP32_EQUIVALENCE_NOT_ESTABLISHED'
    write(output/'summary.json',summary)
    return summary
