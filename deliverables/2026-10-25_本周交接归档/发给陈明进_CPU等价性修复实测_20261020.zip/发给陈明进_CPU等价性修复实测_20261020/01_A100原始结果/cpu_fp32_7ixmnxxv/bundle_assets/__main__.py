"""Zipapp entry. Verify with stdlib before importing any model runtime."""
import argparse
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import tempfile
import traceback
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify_bundle(path):
    with zipfile.ZipFile(path) as z:
        manifest = json.loads(z.read('manifest.json'))
        expected = set(manifest['files']) | {'manifest.json'}
        if set(z.namelist()) != expected or len(z.namelist()) != len(expected):
            raise ValueError('Unexpected or duplicate zip member')
        data = {}
        for name, digest in manifest['files'].items():
            if name.startswith('/') or '\\' in name or '..' in Path(name).parts or ':' in name:
                raise ValueError('Unsafe bundle path')
            raw = z.read(name)
            if sha(raw) != digest:
                raise ValueError('Bundle hash mismatch: '+name)
            if name.endswith('.py'):
                ast.parse(raw.decode('utf-8'), filename=name)
            data[name] = raw
    return manifest, data


def main():
    parser = argparse.ArgumentParser(description='CPU FP32 actual Qwen/LoRA/Trainer candidate verification; no GPU/27B loading')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check-bundle', action='store_true')
    mode.add_argument('--verify-only', action='store_true')
    mode.add_argument('--run-cpu', action='store_true')
    parser.add_argument('--model-path', type=Path, default=Path('/home/admire/models/Qwen3.8-27B'))
    parser.add_argument('--output-root', type=Path, default=Path('/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/route1_equivalence_cpu_fix_20261020'))
    args = parser.parse_args()
    package = Path(sys.argv[0]).resolve()
    manifest, files = verify_bundle(package)
    print('bundle_files_verified='+str(len(files)),flush=True)
    if args.check_bundle:
        print('bundle_syntax_and_hashes_ok=true model_loaded=false numerical_verification_performed=false')
        return 0
    model_files = {}
    for name,digest in manifest['official_model_files'].items():
        p = args.model_path/name
        if not p.is_file() or sha(p.read_bytes()) != digest:
            raise ValueError('Official config/tokenizer file absent or hash differs: '+str(p))
        model_files[name] = digest
    template = args.model_path/'chat_template.jinja'
    if template.exists():
        digest = sha(template.read_bytes())
        if digest != manifest['optional_chat_template_sha256']:
            raise ValueError('External chat template differs')
        model_files[template.name] = digest
    versions = {n:importlib.metadata.version(n) for n in ['torch','transformers','peft','accelerate','datasets']}
    for name,expected in [('transformers','5.8.0'),('peft','0.21.2'),('accelerate','1.14.0')]:
        if versions[name] != expected:
            raise ValueError('Observed environment changed: '+name)
    if not versions['torch'].startswith('2.11.0'):
        raise ValueError('Observed torch environment changed')
    info = {'package_sha256':sha(package.read_bytes()), 'package_files':manifest['files'],
            'official_model_files':model_files,'versions':versions}
    if args.verify_only:
        print(json.dumps({'status':'CPU_PACKAGE_PREFLIGHT_PASS_NO_MODEL_RUN',**info,
                          'model_loaded':False,'inference_performed':False,'gpu_used':False},ensure_ascii=False),flush=True)
        return 0
    # Set before torch/transformers import. CPU test must never initialize CUDA.
    os.environ['CUDA_VISIBLE_DEVICES']=''
    os.environ['HF_HUB_OFFLINE']='1'
    os.environ['TRANSFORMERS_OFFLINE']='1'
    os.environ['TOKENIZERS_PARALLELISM']='false'
    os.environ['OMP_NUM_THREADS']='4'
    os.environ['MKL_NUM_THREADS']='4'
    args.output_root.mkdir(parents=True,exist_ok=True)
    run = Path(tempfile.mkdtemp(prefix='cpu_fp32_',dir=args.output_root))
    assets = run/'bundle_assets'
    for name,data in files.items():
        p = assets/name
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(data)
    (run/'run_request.json').write_text(json.dumps({'scope':manifest['scope'],**info,
        'model_path':str(args.model_path),'cpu_only':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    sys.path.insert(0,str(assets/'code'))
    sys.path.insert(0,str(assets))
    print('output_dir='+str(run),flush=True)
    try:
        import cpu_equivalence_runner
        result = cpu_equivalence_runner.run(run,assets,args.model_path,info)
        print('status='+result['status'],flush=True)
        print('summary='+str(run/'summary.json'),flush=True)
        return 0 if result['status']=='CPU_FP32_ACTUAL_QWEN_LORA_TRAINER_PASS_NOT_27B_EQUIVALENCE' else 1
    except Exception as e:
        traceback.print_exc()
        (run/'failure.json').write_text(json.dumps({'status':'CPU_VALIDATION_ERROR','error_type':type(e).__name__,
            'error':str(e),'summary_may_be_partial':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print('status=CPU_VALIDATION_ERROR report='+str(run/'failure.json'),flush=True)
        return 1


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
