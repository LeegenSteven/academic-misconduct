"""Match original stdout to JSON events, preserve sources, prepare handoff."""
import hashlib
import json
import re
import shutil
from pathlib import Path
import zipfile

ROOT=Path(r'C:\Users\y\Desktop\学术引用不端\10.19-11.2\19daipao')
WORK=ROOT/'A100_CPU等价性修复验证_20261020'
RUN=WORK/'实测回传/cpu_fp32_7ixmnxxv'
LOG=WORK/'实测回传/route1_cpu_fix_20261020_ORcZvZ.run.log'
AUDIT=WORK/'实测核验_20261020'
DELIVERY=ROOT/'发给陈明进_CPU等价性修复实测_20261020'
ZIP=DELIVERY.with_suffix('.zip')


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    assert not DELIVERY.exists() and not ZIP.exists()
    source_paths=[p for p in RUN.rglob('*') if p.is_file()]+[LOG,WORK/'route1_equivalence_cpu_fix_v1_20261020.pyz']
    source_hashes={str(p):sha(p) for p in source_paths}
    previous=read(AUDIT/'完整结果核验.json')
    for name,digest in previous['raw_downloaded_file_sha256'].items():assert sha(RUN/name)==digest
    summary=read(RUN/'summary.json')
    log=LOG.read_text(encoding='utf-8')
    assert 'Traceback (most recent call last)' not in log
    assert log.count('status='+summary['status'])==1
    remote='/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/route1_equivalence_cpu_fix_20261020/cpu_fp32_7ixmnxxv'
    assert 'output_dir='+remote in log and 'summary='+remote+'/summary.json' in log
    events=re.findall(r'^CPU_MICRO case=(\S+) branch=(\S+) step=(\d+) tokens=(\d+) cycle_tokens=(\S+) loss=(\S+)$',log,re.M)
    expected=[]
    per_case={}
    for case_name,meta in summary['cases'].items():
        case=read(RUN/case_name/'case_result.json')
        assert meta['passed'] and case['passed']
        assert log.count('CPU_CASE '+case_name+' PASS')==1
        for branch_name,branch in case['branches'].items():
            for r in branch['microbatches']:
                expected.append((case_name,branch_name,str(r['micro_step']),str(r['supervised_tokens']),
                                 str(r['num_items_in_batch']),format(r['raw_loss'],'.8f')))
        per_case[case_name]={'passed':True,'microbatch_log_records':sum(len(b['microbatches']) for b in case['branches'].values()),
                             'scope':'negative rejection' if meta['expected_negative'] else 'fixed candidate'}
    assert events==expected and len(events)==104
    assert len(re.findall(r'^CPU_CASE ',log,re.M))==6
    DELIVERY.mkdir()
    raw=DELIVERY/'01_A100原始结果'
    shutil.copytree(RUN,raw/RUN.name)
    shutil.copy2(LOG,raw/LOG.name)
    tools=DELIVERY/'02_验证工具'
    tools.mkdir()
    for name in ['route1_equivalence_cpu_fix_v1_20261020.pyz',
                 'route1_equivalence_cpu_fix_v1_20261020.pyz.sha256','先看这里.md','本地检查.json']:
        shutil.copy2(WORK/name,tools/name)
    # Keep verifier provenance and actual predeclared thresholds in the handoff.
    shutil.copy2(Path(__file__),tools/'package_cpu_equivalence_result_20261020.py')
    shutil.copy2(Path(__file__).with_name('audit_downloaded_cpu_result_20261020.py'),tools/'audit_downloaded_cpu_result_20261020.py')
    checks=DELIVERY/'03_核验说明'
    checks.mkdir()
    completed={**previous,'status':'DOWNLOADED_CPU_REPORTS_AND_STDOUT_RECONCILED_PASS',
               'stdout_log_downloaded':True,'stdout_log_sha256':sha(LOG),
               'stdout_microbatch_events_matched':104,'stdout_case_passes_matched':6,
               'run_artifact_checksums_scope':'SHA-256 calculated on unchanged downloaded files; embedded code also checked against original local package',
               'source_A100_run_dir':remote,'source_A100_stdout_log':'/home/admire/'+LOG.name,
               'source_files_unchanged':True}
    write(checks/'完整结果与日志核验.json',completed)
    write(checks/'原始文件哈希.json',{
        **{f'{RUN.name}/{rel}':digest for rel,digest in previous['raw_downloaded_file_sha256'].items()},
        LOG.name:sha(LOG)})
    report=(AUDIT/'核验结论.md').read_text(encoding='utf-8')
    report=report.replace('仍需归档外部运行日志。','外部运行日志已回收，104条microbatch事件、6个场景通过状态与报告逐条一致。')
    report=report.replace('先下载/home/admire/route1_cpu_fix_20261020_ORcZvZ.run.log，与本目录核验及实测目录一并发给陈明进。当前本项可报告“修复候选CPU FP32验证通过，日志归档待补”；不能写为整个Mbio复现核验已完成。',
                          '原始报告、源码、输入fixture、验证包和运行日志均已归档，可报告“修复候选CPU FP32验证通过，完整日志已核对”。请陈明进继续对照10月17日实际训练脚本和checkpoint来源，分别确认长度复算、实现归档及后续GPU补测状态；本项通过不代表整个Mbio复现核验已经完成。')
    (checks/'核验结论.md').write_text(report,encoding='utf-8')
    reply='修复候选的CPU FP32实测已完成并核对原始报告、实际源码哈希和完整日志。使用同架构小配置Qwen3.5、官方完整词表、实际LoRA与Trainer流程，五个正向场景全部通过，包含16步累积加末尾13条、真实padding及EOS/pad共ID；32个LoRA张量的梯度和更新后参数最大差均为0，loss最大绝对差约9.54e-7，未放宽预定容差。旧归一化版本负例产生了实际梯度和更新差异，已被测试识别。材料包已保留原始记录与恢复命令。这个结论支持修复候选在CPU上的目标和更新逻辑，27B量化验证及历史checkpoint实现仍需单独核对；请继续确认实际训练脚本、长度复算和后续GPU验证安排，现有Test结果保持原口径。\n'
    (DELIVERY/'可发送说明.txt').write_text(reply,encoding='utf-8')
    readme='''# CPU等价性修复实测交付

日期：2026年10月20日。

结论：修复候选CPU FP32等价性验证通过，五个正向场景和一个预期失败对照检查均满足协议。原始日志的104条microbatch事件及6个场景状态与完整JSON结果逐条吻合；本地原始文件保持原字节。

先读03_核验说明/核验结论.md；可发送说明.txt为回传消息文本。01_A100原始结果保存A100完整运行目录及外部日志，02_验证工具保存同一验证包、协议和本地核对工具。file_hashes.json可核对本包全部交付文件。

该测试使用实际SupervisedLogitsTrainer类，在CPU随机初始化的小配置Qwen3.5模型上执行。覆盖三标签、变长目标、实际padding、EOS/pad共ID、完整16步和末尾13条；LoRA A/B固定非零初值，测试dropout为0。原训练dropout=0.05独立保留。参照与候选都经过原生Trainer.training_step及外层累积、优化器更新流程。固定容差写在工具协议和原始summary中。

五个修复版场景中，全部32个LoRA张量的梯度和更新后参数最大差为0，最大loss绝对差为9.5367431640625e-7。旧归一化版本对照的缩放loss最大差约0.163931、梯度差约1.6939e-4、参数更新差约3.3822e-4；其PASS表示预期错误成功被识别。

源码及包内哈希与上传的原始验证包一致。完整报告与外部日志均已下载，本包记录的原始结果SHA-256是在本地下载文件上计算的值。

## 复查与恢复

在已记录的A100环境，先用02_验证工具内的pyz执行--verify-only；预检通过后再按同目录先看这里.md运行--run-cpu。恢复会生成新的独立结果目录，不能将复跑结果覆盖本次记录。CPU通过不证明27B/NF4逐位等价，也不会改变历史checkpoint。

A100环境：Python 3.13.12（用户终端回传）、torch 2.11.0+cu130（终端）/2.11.0（包元数据）、transformers 5.8.0、PEFT 0.21.2、accelerate 1.14.0、datasets 5.0.0。该运行报告记录CUDA未初始化，27B权重未加载。

## 后续仍需分别核对

陈明进主责对照10月17日实际训练文件及其哈希、checkpoint来源、Sarol Train2141长度/样本数复算；再分别安排修复候选的GPU验证、保存与重载。CPU通过可以支持本次候选逻辑，不将其写成历史adapter已自动修复。正式基准预测、旧失败记录和原冻结成绩继续保留；是否需要纠正训练由实际历史实现核验结果决定。
'''
    (DELIVERY/'00_先看结论.md').write_text(readme,encoding='utf-8')
    write(DELIVERY/'file_hashes.json',{str(p.relative_to(DELIVERY)).replace('\\','/'):sha(p)
        for p in sorted(DELIVERY.rglob('*')) if p.is_file()})
    for rel,digest in read(DELIVERY/'file_hashes.json').items():assert sha(DELIVERY/rel)==digest
    for name,digest in source_hashes.items():assert sha(Path(name))==digest
    with zipfile.ZipFile(ZIP,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(DELIVERY.rglob('*')):
            if p.is_file():z.write(p,DELIVERY.name+'/'+str(p.relative_to(DELIVERY)).replace('\\','/'))
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        expected_names=[]
        for p in DELIVERY.rglob('*'):
            if p.is_file():
                arc=DELIVERY.name+'/'+str(p.relative_to(DELIVERY)).replace('\\','/')
                expected_names.append(arc)
                assert z.read(arc)==p.read_bytes()
        assert set(expected_names)==set(z.namelist())
    ZIP.with_suffix('.zip.sha256').write_text(sha(ZIP)+'  '+ZIP.name+'\n',encoding='utf-8')
    print(json.dumps({'status':completed['status'],'log_micro_events':104,'case_passes':6,
                      'source_files_unchanged':True,'folder':str(DELIVERY),'zip':str(ZIP),
                      'zip_bytes':ZIP.stat().st_size,'zip_sha256':sha(ZIP)},ensure_ascii=False))


if __name__=='__main__':main()
