"""Reconcile downloaded original CPU reports; no torch/model execution."""
import hashlib
import json
import math
from pathlib import Path
import zipfile

BASE=Path(r'C:\Users\y\Desktop\学术引用不端\10.19-11.2\19daipao\A100_CPU等价性修复验证_20261020')
RUN=BASE/'实测回传/cpu_fp32_7ixmnxxv'
OUT=BASE/'实测核验_20261020'
EXPECTED={'single_micro':(3,1,False),'accum4_tail':(5,4,False),
          'padded_accum4_tail':(5,4,True),'production_accum16_tail13':(29,16,False),
          'eos_as_pad_accum4_tail':(5,4,True),'negative_original_normalization':(5,4,True)}


def load(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def close(a,b):return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=1e-6+1e-5*abs(b)
def check_comparison(c):
    assert not c['missing_actual_gradients'] and not c['missing_reference_gradients']
    ps=c['per_parameter']
    assert len(ps)==c['parameter_count']==32 and len({p['name'] for p in ps})==32
    assert all(math.isfinite(p['max_abs']) and p['max_abs']>=0 for p in ps)
    assert max(p['max_abs'] for p in ps)==c['max_abs']
    assert c['passed']==all(p['passed'] for p in ps)
    return {p['name'] for p in ps}


def main():
    assert not OUT.exists()
    originals={str(p.relative_to(RUN)):sha(p) for p in RUN.rglob('*') if p.is_file()}
    summary=load(RUN/'summary.json');request=load(RUN/'run_request.json')
    package=BASE/'route1_equivalence_cpu_fix_v1_20261020.pyz'
    assert sha(package)==summary['package']['package_sha256']==request['package_sha256']=='4a5aff55ec531714be9954ea4c865184fe8da83a1bfb5a469b198fc5487f55a0'
    with zipfile.ZipFile(package) as z:
        manifest=json.loads(z.read('manifest.json'))
        assert manifest['files']==summary['package']['package_files']==request['package_files']
        for rel,expected in manifest['files'].items():
            assert sha(RUN/'bundle_assets'/rel)==expected
            assert (RUN/'bundle_assets'/rel).read_bytes()==z.read(rel)
    assert summary['status']=='CPU_FP32_ACTUAL_QWEN_LORA_TRAINER_PASS_NOT_27B_EQUIVALENCE'
    assert set(summary['cases'])==set(EXPECTED)
    assert summary['tolerances']==manifest['tolerances']
    assert summary['versions']==request['versions']
    assert summary['package']['official_model_files']==manifest['official_model_files']
    assert summary['actual_candidate_trainer_sha256']==manifest['files']['code/cmj/route1_qwen38_train_sarol_memopt_v1.py']
    assert summary['model_class']=='Qwen3_5ForCausalLM' and summary['tiny_model_vocab_size']==248320
    assert summary['official_full_vocabulary_preserved'] and summary['nonzero_lora_A_and_B_initialization']
    assert summary['dropout']==0.0 and summary['original_training_dropout']==0.05
    assert summary['cuda_initialized'] is False and summary['official_27B_weights_loaded'] is False
    assert summary['tiny_base_parameters_unchanged'] and summary['empty_and_asymmetric_tensors_rejected']
    assert not (RUN/'failure.json').exists()
    tiny=load(RUN/'tiny_config.json')
    assert tiny['vocab_size']==248320 and tiny['hidden_size']==32 and tiny['num_hidden_layers']==4
    assert tiny['layer_types']==['linear_attention']*3+['full_attention']
    fixture=load(RUN/'fixtures.json')
    assert len(fixture['records'])==len(fixture['features'])==29
    assert {r['label'] for r in fixture['records']}=={'ACCURATE','NOT_ACCURATE','IRRELEVANT'}
    table=[];shared_names=None
    for name,(count,accum,padded) in EXPECTED.items():
        case=load(RUN/name/'case_result.json')
        assert case['passed'] and case['count']==count and case['accumulation']==accum and case['padded']==padded
        negative=name=='negative_original_normalization'
        std=case['branches']['standard'];candidate=case['branches']['original_before_fix' if negative else 'fixed']
        for branch_name,branch in case['branches'].items():
            assert branch==load(RUN/name/(branch_name+'.json'))
            rows=branch['microbatches']
            assert len(rows)==count and sorted(r['sample_index'] for r in rows)==list(range(count))
            assert len(branch['updates'])==math.ceil(count/accum)
            assert [u['global_step'] for u in branch['updates']]==list(range(1,math.ceil(count/accum)+1))
            assert all(u['parameters_changed_from_initial'] for u in branch['updates'])
            for row in rows:
                f=fixture['features'][row['sample_index']]
                signature={k:list(f[k]) for k in ['input_ids','attention_mask','labels']}
                if padded:
                    pads=3+row['sample_index']%5
                    # Reconstruct the exact padding ID selected by this scenario.
                    pad_ids={tiny['eos_token_id'] if name=='eos_as_pad_accum4_tail' else tiny['pad_token_id']}
                    hashes=[]
                    for pad in pad_ids:
                        sig={k:list(v) for k,v in signature.items()}
                        for key,fill in [('input_ids',pad),('attention_mask',0),('labels',-100)]:
                            extension=[fill]*pads
                            sig[key]=sig[key]+extension if summary['padding_side']=='right' else extension+sig[key]
                        hashes.append(hashlib.sha256(json.dumps({k:[v] for k,v in sig.items()},sort_keys=True).encode()).hexdigest())
                    assert row['batch_sha256'] in hashes
                    assert row['padding_tokens']==pads
                else:
                    assert row['batch_sha256']==hashlib.sha256(json.dumps({k:[v] for k,v in signature.items()},sort_keys=True).encode()).hexdigest()
                    assert row['padding_tokens']==0
                assert row['supervised_tokens']==sum(t!=-100 for t in f['labels'][1:])
                assert math.isfinite(row['raw_loss']) and math.isfinite(row['returned_scaled_loss'])
            for start in range(0,count,accum):
                chunk=rows[start:start+accum]
                assert all(r['actual_accumulation_steps']==len(chunk) for r in chunk)
                if branch_name=='standard' or not negative:
                    assert all(r['num_items_in_batch']==sum(x['supervised_tokens'] for x in chunk) for r in chunk)
            if branch_name=='standard':assert all(close(r['raw_loss'],r['oracle_loss']) for r in rows)
        assert std['initial_trainable_sha256']==candidate['initial_trainable_sha256']
        loss_max=scaled_max=gradient_max=parameter_max=0.0
        for a,b in zip(std['microbatches'],candidate['microbatches']):
            assert a['batch_sha256']==b['batch_sha256'] and b['same_batch']
            assert b['raw_loss_close']==close(b['raw_loss'],a['raw_loss'])
            assert b['scaled_loss_close']==close(b['returned_scaled_loss'],a['returned_scaled_loss'])
            assert b['scaled_loss_abs_diff']==abs(b['returned_scaled_loss']-a['returned_scaled_loss'])
            names=check_comparison(b['gradients_before_clipping'])
            if shared_names is None:shared_names=names
            assert names==shared_names
            for module in ['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']:
                assert any('.'+module+'.lora_' in n for n in names)
            loss_max=max(loss_max,abs(b['raw_loss']-a['raw_loss']))
            scaled_max=max(scaled_max,b['scaled_loss_abs_diff'])
            gradient_max=max(gradient_max,b['gradients_before_clipping']['max_abs'])
        for update in candidate['updates']:
            assert check_comparison(update['parameters_after_update'])==shared_names
            parameter_max=max(parameter_max,update['parameters_after_update']['max_abs'])
        passed=all(r['passed'] for r in candidate['microbatches']) and all(u['parameters_after_update']['passed'] for u in candidate['updates'])
        assert candidate['passed']==passed
        if negative:
            assert not passed and case['actual_numeric_difference_detected']
            assert gradient_max>1e-6 and parameter_max>1e-6 and scaled_max>1e-6
        else:
            assert passed
            # Downloaded FP32 run is stronger than its tolerance flags: all
            # per-parameter gradient/update maximum differences are exactly 0.
            assert gradient_max==parameter_max==0.0
        table.append({'case':name,'scope':'expected_negative_rejected' if negative else 'fixed_candidate_pass',
                      'samples_per_branch':count,'accumulation':accum,'updates_per_branch':math.ceil(count/accum),
                      'loss_max_abs':loss_max,'scaled_loss_max_abs':scaled_max,'gradient_max_abs':gradient_max,
                      'parameter_max_abs':parameter_max,'trainable_LoRA_tensor_count':len(shared_names)})
    assert originals=={str(p.relative_to(RUN)):sha(p) for p in RUN.rglob('*') if p.is_file()}
    OUT.mkdir()
    result={'status':'DOWNLOADED_CPU_REPORTS_RECONCILED_PASS_LOG_PENDING',
            'local_verification_date':'2026-10-20','run_id':RUN.name,'run_files_checked':len(originals),
            'package_and_extracted_source_hashes_match':True,'all_case_and_branch_reports_agree':True,
            'batch_hashes_reconstructed_from_fixtures':True,'native_token_sum_oracle_records_checked':True,
            'all_32_trainable_tensor_names_checked':True,'case_results':table,
            'stdout_log_downloaded':False,'local_numerical_rerun_performed':False,
            'scope':'Downloaded CPU FP32 tiny actual Qwen/LoRA/Trainer reports; not 27B/NF4 verification or historical adapter repair',
            'raw_downloaded_file_sha256':originals,'auditor_sha256':sha(Path(__file__))}
    (OUT/'完整结果核验.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['# 修复候选CPU FP32实测核验','',
           '本地核验日期：2026年10月20日。运行目录：cpu_fp32_7ixmnxxv。', '',
           '结论：收到的完整报告与终端PASS一致，修复候选在本次小配置Qwen3.5文本架构、实际LoRA与实际Trainer流程下的CPU FP32等价性验证通过。仍需归档外部运行日志。','',
           '已核对38个下载文件；本地验证包、报告记录及8项实际解包源码哈希一致。逐场景文件与summary交叉一致，按fixtures重新构造batch哈希，核对全部32个LoRA张量名称、监督token分母、实际累积周期及优化器更新次数。', '',
           '五个修复版场景的最大梯度差和最大更新后参数差均为0。最大loss绝对差为9.5367431640625e-7；按运行前固定的atol=1e-6、rtol=1e-5通过，梯度/参数容差atol=1e-6、rtol=1e-4保持原值。', '',
           '| 场景 | 每路径样本/更新步数 | loss最大绝对差 | 梯度最大绝对差 | 参数最大绝对差 |',
           '|---|---|---|---|---|']
    for row in table:
        lines.append(f"| {row['case']} | {row['samples_per_branch']}/{row['updates_per_branch']} | {row['loss_max_abs']:.9g} | {row['gradient_max_abs']:.9g} | {row['parameter_max_abs']:.9g} |")
    lines += ['', '负例使用旧归一化版本。它的scaled loss最大差约0.163931、梯度最大差约1.6939e-4、更新后参数最大差约3.3822e-4，产生真实数值差异。负例PASS表示该错误对照已被拒绝，不是旧版本也等价。','',
              '## 通过范围','',
              '三类标签、变长目标、完整4步及余数、真实padding、完整16步加末尾13条、EOS与pad共ID均已覆盖。测试关闭dropout，并将LoRA A/B设为固定非零初值；原训练dropout=0.05另行保留。小模型保留248320完整词表，含3层线性注意力与1层完整注意力。标准路径使用原生Trainer，并记录token-sum参照；两路径使用同初值、同批次及同优化器设置。','',
              '此核验复算的是下载报告及源码/输入一致性，未在本地重新执行数值实验。报告支持该修复候选的CPU目标与更新逻辑；27B NF4+BF16数值差异、真实Train2141长度复算、10月17日训练脚本与checkpoint对应关系、GPU候选smoke与重载仍按各自证据登记。历史checkpoint不会因新候选CPU通过而自动改变。','',
              '## 下一步','',
              '先下载/home/admire/route1_cpu_fix_20261020_ORcZvZ.run.log，与本目录核验及实测目录一并发给陈明进。当前本项可报告“修复候选CPU FP32验证通过，日志归档待补”；不能写为整个Mbio复现核验已完成。','']
    (OUT/'核验结论.md').write_text('\n'.join(lines),encoding='utf-8')
    reply='修复候选已在A100完成小配置Qwen3.5同架构CPU FP32验证，使用实际LoRA与Trainer流程、完整词表和固定非零LoRA初值，测试关闭dropout。五个正向场景均通过，包含16步累积加末尾13条、真实padding及EOS/pad共ID；32个LoRA张量的梯度及更新后参数最大差均为0，loss最大绝对差约9.54e-7，容差未放宽。旧归一化版本的负例出现实际梯度和更新差异，已被识别。完整报告和源码哈希已核对，正在补齐运行日志。这个结论支持修复候选的CPU训练逻辑，27B量化数值等价性及历史checkpoint实现核验仍分别登记，现有Test成绩保持原口径。\n'
    (OUT/'给陈明进的结果说明.txt').write_text(reply,encoding='utf-8')
    (OUT/'file_hashes.json').write_text(json.dumps({p.name:sha(p) for p in OUT.iterdir() if p.is_file()},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'report':str(OUT/'核验结论.md'),'source_files_unchanged':True,'cases':len(table)},ensure_ascii=False))


if __name__=='__main__':main()
