"""Instrument real Trainer.train without replacing its loss/backward/accumulation.

First run --cpu-preflight. The real-27B GPU test is a separate --launch action.
All outputs are isolated. A smoke success is never used as equivalence evidence.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.metadata
import importlib.util
import inspect
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import datetime, timezone

PACKAGE_SHA = "7e1a0ce8619f66f1f0ef1f9d0f79e457ee22052a10ee81aa95f8874ea6a44b4b"
RUNNER_SHA = "24598dcd90bc28b1b3703bf0eaa9a81c9be74fcda77d9184e68e461ccbe7699b"
CONFIG_SHA = "191e0af232104ed8b65258cf3fb2b842e288008baca7633c11b82a1ac7203aab"
INPUT_SHA = "712338b41e7f1b56b8a4cb8a75018a57bab89706ed0b6d9f4a2e7dc8bd0d0180"
GOLD_SHA = "f245b94aafc67934b43c760a1d6c68b0f1042d7561f493280c77d49467c1fad8"
LOSS_ATOL = 1e-5
GRAD_MAX_ABS = 1e-4
GRAD_ATOL = 1e-5
GRAD_RTOL = 1e-4
SEED = 42
LABELS = ("ACCURATE", "NOT_ACCURATE", "IRRELEVANT")


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def unique_dir(parent, prefix):
    parent.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix=prefix + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") , dir=parent))


def check_task(task, model_path):
    require(task.name == "a100_assist_20261019_stage1_v1", "Unexpected stage1 task root")
    require((task / "PACKAGE_SHA256.txt").read_text().strip() == PACKAGE_SHA, "Package marker differs")
    payload = task / "payload"
    manifest = json.loads((task / "manifest.json").read_text(encoding="utf-8"))
    for rel, expected in manifest["payload_files"].items():
        source = (payload / rel).resolve()
        require(source.is_relative_to(payload.resolve()), "Unsafe payload path")
        require(sha(source) == expected, "Immutable payload changed: " + rel)
    require(sha(payload / "data/train.inputs.jsonl") == INPUT_SHA, "Train inputs changed")
    require(sha(payload / "data/train.gold.jsonl") == GOLD_SHA, "Train gold changed")
    require(sha(model_path / "config.json") == CONFIG_SHA, "Official base config changed")
    return payload


def select_coverage(items, count):
    """Select whole, unmodified short Train records; never truncate text/tokens."""
    require(count >= 3, "Need all three labels")
    ordered = sorted(items, key=lambda item: (len(item["feature"]["input_ids"]), item["index"]))
    chosen = []
    for label in LABELS:
        matches = [item for item in ordered if item["label"] == label]
        require(matches, "No sufficiently short Train example for " + label)
        chosen.append(matches[0])
    used = {item["index"] for item in chosen}
    for item in ordered:
        if len(chosen) == count:
            break
        if item["index"] not in used:
            chosen.append(item)
            used.add(item["index"])
    require(len(chosen) == count, "Not enough complete short Train examples")
    require(len({sum(t != -100 for t in item["feature"]["labels"]) for item in chosen}) >= 2,
            "Variable assistant target lengths not covered")
    return chosen


def validate_history(micro, steps, count, accum):
    require(len(micro) == count, "Incomplete microbatch history")
    require(len(steps) == math.ceil(count / accum), "An optimizer cycle was omitted/overwritten")
    require(sorted(row["sample_index"] for row in micro) == list(range(count)), "Samples repeated/omitted")
    for index, row in enumerate(micro):
        actual = min(accum, count - (index // accum) * accum)
        require(row["current_gradient_accumulation_steps"] == actual,
                "Actual Trainer accumulation divisor differs from expected full/tail cycle")
    require([row["global_step"] for row in steps] == list(range(1, math.ceil(count / accum) + 1)),
            "Optimizer step history incomplete")


def load_runtime(payload):
    sys.path.insert(0, str(payload / "code"))
    import torch
    from transformers import Trainer, TrainerCallback, TrainingArguments, set_seed
    from safetensors import safe_open
    from safetensors.torch import save_file
    from cmj.route1_qwen38_train_sarol_memopt_v1 import SupervisedLogitsTrainer
    from shared.route1_qwen38.data_contract import AssistantOnlyCollator, encode_assistant_record, load_gold, load_records
    return locals()


def snapshot(runtime, model, gradients):
    torch = runtime["torch"]
    tensors, none_names = {}, []
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        value = parameter.grad if gradients else parameter
        if value is None:
            none_names.append(name)
        else:
            value = value.detach().to(device="cpu", dtype=torch.float32).contiguous().clone()
            require(bool(torch.isfinite(value).all()), "Nonfinite trainable tensor: " + name)
            tensors[name] = value
    require(tensors, "Empty trainable gradient/parameter snapshot cannot pass")
    return tensors, sorted(none_names)


def compare_tensors(runtime, tensors, none_names, reference, reference_none, parameters=False):
    """Symmetric key checks, nonempty/finite gates and every tensor checked."""
    torch = runtime["torch"]
    with runtime["safe_open"](str(reference), framework="pt", device="cpu") as handle:
        ref_names = set(handle.keys())
        names = set(tensors)
        same_keys = names == ref_names and sorted(none_names) == sorted(reference_none)
        maximum, mismatches, checked = 0.0, [], 0
        for name in sorted(names & ref_names):
            actual, expected = tensors[name], handle.get_tensor(name)
            if actual.shape != expected.shape or not bool(torch.isfinite(expected).all()):
                mismatches.append({"name": name, "reason": "shape/nonfinite reference"})
                continue
            difference = float((actual - expected).abs().max())
            maximum = max(maximum, difference)
            checked += actual.numel()
            atol = 1e-5 if parameters else GRAD_ATOL
            close = bool(torch.allclose(actual, expected, atol=atol, rtol=GRAD_RTOL))
            if not close or (not parameters and difference > GRAD_MAX_ABS):
                mismatches.append({"name": name, "max_abs": difference})
        return {"passed": same_keys and bool(names) and checked > 0 and not mismatches,
                "same_keys_and_none_gradients": same_keys,
                "missing_names": sorted(ref_names - names), "extra_names": sorted(names - ref_names),
                "none_gradient_names": none_names, "tensors_compared": len(names & ref_names),
                "elements_compared": checked, "max_abs": maximum, "mismatches": mismatches}


def make_instrumentation(runtime):
    torch = runtime["torch"]
    Trainer = runtime["Trainer"]
    TrainerCallback = runtime["TrainerCallback"]
    Optimized = runtime["SupervisedLogitsTrainer"]
    set_seed = runtime["set_seed"]

    class Audit:
        def __init__(self, root, branch, count, accum, case_seed):
            self.root, self.branch, self.count, self.accum = root, branch, count, accum
            self.case_seed = case_seed
            self.out = root / branch
            self.out.mkdir(parents=True, exist_ok=False)
            self.micro, self.steps, self.raw = [], [], None
            self.passed = True

        def tensors(self, event, model, gradients):
            values, none_names = snapshot(runtime, model, gradients)
            reference = self.root / "standard" / (event + ".safetensors")
            sidecar = reference.with_suffix(".json")
            if self.branch == "standard":
                runtime["save_file"](values, str(reference))
                write_json(sidecar, {"none_names": none_names, "sha256": sha(reference)})
                result = {"reference_saved": True, "tensor_count": len(values), "none_gradient_names": none_names}
            else:
                prior = json.loads(sidecar.read_text(encoding="utf-8"))
                require(sha(reference) == prior["sha256"], "Reference gradient/parameter file changed")
                result = compare_tensors(runtime, values, none_names, reference, prior["none_names"], parameters=not gradients)
                self.passed = self.passed and result["passed"]
            del values
            return result

        def finish_micro(self, model, trainer, sample_index, loss, batch_info):
            number = len(self.micro) + 1
            require(self.raw is not None, "Original compute_loss was not called")
            event = "micro_%03d" % number
            row = {"sample_index": sample_index, "micro_step": number,
                   "raw_loss": self.raw, "returned_scaled_loss": loss,
                   "current_gradient_accumulation_steps": int(trainer.current_gradient_accumulation_steps),
                   "accelerator_gradient_accumulation_steps": int(trainer.accelerator.gradient_accumulation_steps),
                   "model_accepts_loss_kwargs": bool(trainer.model_accepts_loss_kwargs), **batch_info}
            row["gradients"] = self.tensors(event, model, True)
            if self.branch != "standard":
                prior = json.loads((self.root / "standard" / (event + ".event.json")).read_text(encoding="utf-8"))
                same = all(row[key] == prior[key] for key in (
                    "sample_index", "current_gradient_accumulation_steps", "accelerator_gradient_accumulation_steps",
                    "model_accepts_loss_kwargs", "batch_sha256", "supervised_tokens", "padding_tokens", "num_items_in_batch"))
                raw_diff = abs(row["raw_loss"] - prior["raw_loss"])
                scaled_diff = abs(row["returned_scaled_loss"] - prior["returned_scaled_loss"])
                row["loss_and_execution"] = {"passed": same and raw_diff <= LOSS_ATOL and scaled_diff <= LOSS_ATOL,
                                             "same_execution_contract": same, "raw_loss_abs_diff": raw_diff,
                                             "scaled_loss_abs_diff": scaled_diff}
                self.passed = self.passed and row["loss_and_execution"]["passed"]
            write_json(self.out / (event + ".event.json"), row)
            self.micro.append(row)
            print(f"EQUIV_MICRO branch={self.branch} step={number}/{self.count} raw_loss={self.raw:.9f} divisor={row['current_gradient_accumulation_steps']} passed_so_far={self.passed}", flush=True)
            self.raw = None

        def finish_update(self, model, global_step):
            row = {"global_step": int(global_step),
                   "parameters": self.tensors("update_%03d" % global_step, model, False)}
            self.steps.append(row)
            write_json(self.out / ("update_%03d.event.json" % global_step), row)

        def complete(self):
            validate_history(self.micro, self.steps, self.count, self.accum)
            result = {"passed": self.passed, "microbatches": self.micro, "optimizer_updates": self.steps,
                      "full_and_remainder_history_valid": True}
            write_json(self.out / "branch_result.json", result)
            return result

    class AuditMixin:
        def __init__(self, *args, audit, **kwargs):
            self.audit = audit
            super().__init__(*args, **kwargs)

        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            loss = super().compute_loss(model, inputs, return_outputs=return_outputs,
                                        num_items_in_batch=num_items_in_batch)
            tensor = loss[0] if return_outputs else loss
            value = float(tensor.detach())
            require(math.isfinite(value), "Nonfinite loss")
            self.audit.raw = value
            return loss

        def training_step(self, model, inputs, num_items_in_batch=None):
            inputs = dict(inputs)
            sample_index = int(inputs.pop("_audit_index").reshape(-1)[0])
            # Reproduce dropout RNG for the SAME microbatch in both paths, including
            # checkpoint recomputation. No loss/gradient scaling is replaced here.
            set_seed(self.audit.case_seed + len(self.audit.micro))
            signature = {key: inputs[key].tolist() for key in ("input_ids", "attention_mask", "labels")}
            info = {"batch_sha256": hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest(),
                    "supervised_tokens": int(inputs["labels"].ne(-100).sum()),
                    "padding_tokens": int(inputs["attention_mask"].eq(0).sum()),
                    "num_items_in_batch": int(num_items_in_batch) if num_items_in_batch is not None else None}
            result = super().training_step(model, inputs, num_items_in_batch=num_items_in_batch)
            self.audit.finish_micro(model, self, sample_index, float(result), info)
            return result

    class StandardAuditTrainer(AuditMixin, Trainer):
        pass

    class OptimizedAuditTrainer(AuditMixin, Optimized):
        pass

    class UpdateCallback(TrainerCallback):
        def __init__(self, audit):
            self.audit = audit

        def on_step_end(self, args, state, control, **kwargs):
            self.audit.finish_update(kwargs["model"], state.global_step)

    class Collator:
        def __init__(self, tokenizer, pad):
            self.base = runtime["AssistantOnlyCollator"](tokenizer)
            self.tokenizer, self.pad = tokenizer, pad

        def __call__(self, features):
            require(len(features) == 1, "Optimized trainer only supports microbatch one")
            index = features[0]["_audit_index"]
            batch = self.base([{key: value for key, value in features[0].items() if key != "_audit_index"}])
            require(not bool(batch["attention_mask"].eq(0).any()), "Unexpected pre-existing padding")
            if self.pad:
                width = batch["input_ids"].shape[1]
                extra = 128 - width % 128
                for key, fill in (("input_ids", self.tokenizer.pad_token_id), ("attention_mask", 0), ("labels", -100)):
                    batch[key] = torch.nn.functional.pad(batch[key], (0, extra), value=fill)
                require(bool(batch["labels"][:, -extra:].eq(-100).all()), "Padding is supervised")
                require(bool(batch["attention_mask"][:, -extra:].eq(0).all()), "Padding mask is wrong")
            batch["_audit_index"] = torch.tensor([index], dtype=torch.long)
            return batch

    return Audit, StandardAuditTrainer, OptimizedAuditTrainer, UpdateCallback, Collator


def train_pair(runtime, model, tokenizer, features, directory, accum, padded, case_seed, cpu=False, negative=False):
    torch = runtime["torch"]
    from datasets import Dataset
    Audit, Standard, Optimized, UpdateCallback, Collator = make_instrumentation(runtime)
    directory.mkdir(parents=True, exist_ok=False)
    initial, _ = snapshot(runtime, model, False)
    initial_file = directory / "initial_trainable.safetensors"
    runtime["save_file"](initial, str(initial_file))
    result = {"accumulation": accum, "count": len(features), "right_padding_to_next_128": padded,
              "initial_trainable_sha256": sha(initial_file), "branches": {}, "passed": False}
    dataset = Dataset.from_list([{**feature, "_audit_index": index} for index, feature in enumerate(features)])
    try:
        for branch, cls in (("standard", Standard), ("memopt", Optimized)):
            trainer, audit = None, None
            try:
                with torch.no_grad():
                    for name, parameter in model.named_parameters():
                        if parameter.requires_grad:
                            parameter.copy_(initial[name].to(parameter.device, dtype=parameter.dtype))
                model.zero_grad(set_to_none=True)
                runtime["set_seed"](case_seed)
                audit = Audit(directory, branch, len(features), accum, case_seed)
                arguments = dict(output_dir=str(directory / branch / "trainer_output"), num_train_epochs=1,
                    per_device_train_batch_size=1, gradient_accumulation_steps=accum,
                    learning_rate=1e-4, weight_decay=0.0, warmup_ratio=0.03, lr_scheduler_type="cosine",
                    bf16=not cpu, gradient_checkpointing=not cpu, report_to="none", seed=case_seed,
                    dataloader_pin_memory=False, dataloader_num_workers=0, remove_unused_columns=False,
                    save_strategy="no", logging_strategy="no", disable_tqdm=True,
                    use_cpu=cpu)
                if not cpu:
                    arguments["gradient_checkpointing_kwargs"] = {"use_reentrant": False}
                trainer = cls(model=model, args=runtime["TrainingArguments"](**arguments), train_dataset=dataset,
                              data_collator=Collator(tokenizer, padded), audit=audit,
                              callbacks=[UpdateCallback(audit)])
                require(type(trainer).training_step.__qualname__.startswith("make_instrumentation.<locals>.AuditMixin"),
                        "Unexpected audit path")
                trainer.train()
                result["branches"][branch] = audit.complete()
            except Exception as error:
                traceback.print_exc()
                result["branches"][branch] = {"passed": False, "error_type": type(error).__name__, "error": str(error)}
                # Do not continue with a missing standard reference and accidentally pass.
                if branch == "standard":
                    break
            finally:
                model.zero_grad(set_to_none=True)
                if trainer is not None:
                    if trainer.optimizer is not None:
                        trainer.optimizer.state.clear()
                    trainer.optimizer = None
                    trainer.lr_scheduler = None
                del trainer, audit
                gc.collect()
                if not cpu:
                    torch.cuda.empty_cache()
        result["passed"] = len(result["branches"]) == 2 and all(value.get("passed", False) for value in result["branches"].values())
        if result["passed"]:
            for branch_result in result["branches"].values():
                padding_seen = all(row["padding_tokens"] > 0 for row in branch_result["microbatches"])
                require(padding_seen == padded, "Actual padding coverage differs from scenario")
                require(len({row["supervised_tokens"] for row in branch_result["microbatches"]}) >= 2,
                        "Actual variable assistant target lengths were not covered")
        if negative:
            result["expected_negative_detected"] = len(result["branches"]) == 2 and not result["passed"]
        write_json(directory / "case_result.json", result)
        return result
    finally:
        del initial
        gc.collect()


def cpu_selfcheck(runtime, output):
    torch = runtime["torch"]
    from transformers import PreTrainedModel, PretrainedConfig
    from transformers.modeling_outputs import CausalLMOutput

    class Toy(PreTrainedModel):
        config_class = PretrainedConfig
        accepts_loss_kwargs = False

        def __init__(self):
            super().__init__(PretrainedConfig(vocab_size=32))
            self.embed = torch.nn.Embedding(32, 12)
            self.dropout = torch.nn.Dropout(0.05)
            self.head = torch.nn.Linear(12, 32, bias=False)

        def forward(self, input_ids=None, attention_mask=None, labels=None, logits_to_keep=0,
                    num_items_in_batch=None, **kwargs):
            hidden = self.dropout(self.embed(input_ids))
            if torch.is_tensor(logits_to_keep):
                hidden = hidden[:, logits_to_keep, :]
            logits = self.head(hidden)
            loss = None
            if labels is not None:
                shifted = torch.nn.functional.pad(labels, (0, 1), value=-100)[:, 1:]
                reduction = "sum" if num_items_in_batch is not None else "mean"
                loss = torch.nn.functional.cross_entropy(logits.reshape(-1, 32).float(), shifted.reshape(-1), ignore_index=-100, reduction=reduction)
                if num_items_in_batch is not None:
                    loss = loss / num_items_in_batch
            return CausalLMOutput(loss=loss, logits=logits)

    class Tokenizer:
        pad_token_id = 0
        padding_side = "right"

    features = []
    for index in range(17):
        length = 8 + index % 5
        ids = [1 + (index + item) % 30 for item in range(length)]
        supervised = 1 + index % 3
        features.append({"input_ids": ids, "attention_mask": [1] * length,
                         "labels": [-100] * (length - supervised) + ids[-supervised:]})
    cases = [("single_micro", 5, 1, False), ("accum4_tail", 5, 4, False),
             ("padded_accum4_tail", 5, 4, True), ("production_accum16_tail", 17, 16, False)]
    results = {}
    for index, (name, count, accum, padded) in enumerate(cases):
        print("CPU_HARNESS_CASE_START " + name, flush=True)
        runtime["set_seed"](SEED)
        result = train_pair(runtime, Toy(), Tokenizer(), features[:count], output / name,
                            accum, padded, 1000 + index * 100, cpu=True)
        require(result["passed"], "Tiny CPU harness failed: " + name)
        results[name] = True
    bad_model = Toy()
    bad_model.accepts_loss_kwargs = True
    print("CPU_NEGATIVE_TEST_START expected_numerical_mismatch=true", flush=True)
    negative = train_pair(runtime, bad_model, Tokenizer(), features[:5], output / "negative_loss_kwargs",
                          4, False, 2000, cpu=True, negative=True)
    require(negative.get("expected_negative_detected"), "Bad normalization was not rejected")
    require(any(not row["gradients"]["passed"] or row["loss_and_execution"]["raw_loss_abs_diff"] > LOSS_ATOL
                for row in negative["branches"]["memopt"]["microbatches"]),
            "Negative normalization case must produce an actual numerical discrepancy, not just a flag difference")
    results["negative_normalization_rejected"] = True
    print("CPU_NEGATIVE_TEST_PASS incorrect_normalization_was_rejected=true", flush=True)
    empty = output / "empty_gradients.safetensors"
    runtime["save_file"]({"unexpected": torch.ones(2)}, str(empty))
    require(not compare_tensors(runtime, {}, [], empty, [])["passed"], "Empty/asymmetric gradients were accepted")
    results["empty_and_asymmetric_gradients_rejected"] = True
    try:
        validate_history([{"sample_index": i, "current_gradient_accumulation_steps": 4 if i < 4 else 1} for i in range(5)],
                         [{"global_step": 2}], 5, 4)
    except RuntimeError:
        results["omitted_full_cycle_rejected"] = True
    require(results.get("omitted_full_cycle_rejected"), "Overwritten full cycle was accepted")
    require(not torch.cuda.is_initialized(), "CPU preflight initialized CUDA")
    return results


def select_real_records(runtime, payload, model_path):
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True, trust_remote_code=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    records = runtime["load_records"](payload / "data/train.inputs.jsonl",
                                      runtime["load_gold"](payload / "data/train.gold.jsonl", split="train"))
    require(len(records) == 2141, "Full Train count differs")
    short = []
    for index, row in enumerate(records):
        feature = runtime["encode_assistant_record"](row, tokenizer, 5120)
        if len(feature["input_ids"]) <= 768:
            short.append({"index": index, "claim_id": row["claim_id"], "label": row["label"], "feature": feature})
    selected = select_coverage(short, 17)
    require(set(item["label"] for item in selected[:5]) == set(LABELS), "Five-sample case must cover every label")
    require(len({sum(token != -100 for token in item["feature"]["labels"]) for item in selected[:5]}) >= 2,
            "Five-sample case lacks variable target lengths")
    return tokenizer, selected


def cpu_preflight(args):
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    payload = check_task(args.task_root, args.model_path)
    output = unique_dir(args.task_root / "equivalence_preflight", "cpu_")
    result = {"status": "FAIL", "script_sha256": sha(__file__), "source_input_sha256": INPUT_SHA,
              "source_gold_sha256": GOLD_SHA, "official_27b_loaded": False,
              "gpu_training_performed": False, "output": str(output)}
    code = 1
    try:
        runtime = load_runtime(payload)
        result["versions"] = {name: importlib.metadata.version(name) for name in ("torch", "transformers", "accelerate", "peft", "safetensors")}
        require(result["versions"]["transformers"] == "5.8.0" and result["versions"]["accelerate"] == "1.14.0", "Runtime changed; review implementation first")
        tokenizer, selected = select_real_records(runtime, payload, args.model_path)
        del tokenizer
        selected_path = output / "selected_train_records.json"
        write_json(selected_path, selected)
        result["selection_file"] = str(selected_path)
        result["selection_sha256"] = sha(selected_path)
        result["selected_ids"] = [item["claim_id"] for item in selected]
        result["first_five_coverage"] = [{"claim_id": item["claim_id"], "original_label": item["label"],
                      "tokens": len(item["feature"]["input_ids"]),
                      "supervised_tokens": sum(token != -100 for token in item["feature"]["labels"])} for item in selected[:5]]
        result["selection_policy"] = "Complete short Train records <=768 tokens; three original labels; no truncation, relabeling, Dev or Test"
        print("REAL_TRAIN_SELECTION=" + json.dumps(result["first_five_coverage"], ensure_ascii=False), flush=True)
        result["harness_checks"] = cpu_selfcheck(runtime, output / "harness")
        result["cuda_initialized"] = bool(runtime["torch"].cuda.is_initialized())
        result["status"] = "CPU_HARNESS_PREFLIGHT_PASS_NOT_27B_EQUIVALENCE"
        code = 0
    except Exception as error:
        traceback.print_exc()
        result["error_type"], result["error"] = type(error).__name__, str(error)
    write_json(output / "preflight.json", result)
    (output / "exit_code.txt").write_text(str(code) + "\n", encoding="ascii")
    print("CPU_PREFLIGHT_RESULT=" + result["status"], flush=True)
    print("report=" + str(output / "preflight.json"), flush=True)
    raise SystemExit(code)


def get_preflight(task):
    candidates = []
    for path in (task / "equivalence_preflight").glob("*/preflight.json"):
        value = json.loads(path.read_text(encoding="utf-8"))
        if value.get("status") == "CPU_HARNESS_PREFLIGHT_PASS_NOT_27B_EQUIVALENCE" and value.get("script_sha256") == sha(__file__):
            require(sha(value["selection_file"]) == value["selection_sha256"], "CPU selection changed")
            candidates.append((path, value))
    require(candidates, "Matching CPU harness preflight has not passed; do not launch GPU test")
    return sorted(candidates, key=lambda item: str(item[0]))[-1]


def gpu_run(args):
    import threading
    import fcntl
    output = args.run_dir.resolve()
    require(output.parent == args.task_root / "equivalence_runs", "Unexpected output location")
    require({path.name for path in output.iterdir()} <= {"run.log", "launch.json", "launcher.pid"}, "Refuse to overwrite existing results")
    result = {"status": "FAIL", "operator": "李云", "purpose": "陈明进 supervised logits 真实27B等价性验证",
              "script_sha256": sha(__file__), "official_27b_loaded": False,
              "loss_absolute_tolerance": LOSS_ATOL, "gradient_max_absolute_tolerance": GRAD_MAX_ABS,
              "gradient_allclose_atol": GRAD_ATOL, "gradient_allclose_rtol": GRAD_RTOL,
              "scope": "Selected short untruncated Train examples; microbatch1, replayed dropout RNG, actual Trainer.train. Not a proof for every Train record or other microbatch sizes.",
              "cases": {}, "started_utc": datetime.now(timezone.utc).isoformat()}
    lock, sampler, stop, torch_module = None, None, threading.Event(), None
    started, code = time.monotonic(), 1
    try:
        payload = check_task(args.task_root, args.model_path)
        require(shutil.disk_usage(output).free >= 25 * 1024**3, "Need at least 25 GiB free for full gradient/parameter reference evidence")
        preflight_path, preflight = get_preflight(args.task_root)
        result["cpu_preflight"] = {"path": str(preflight_path), "sha256": sha(preflight_path)}
        runner_path = Path("/home/admire/a100_stage1_gpu_runner_v1.py")
        require(sha(runner_path) == RUNNER_SHA, "Stage1 GPU monitoring helper changed")
        spec = importlib.util.spec_from_file_location("immutable_stage1_runner", runner_path)
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        lock = (args.task_root / ("gpu_%d.lock" % args.gpu)).open("a+")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = helper.read_gpu(args.gpu)
        require(before["free_mib"] >= 35000, "Less than 35000 MiB free; stop before model loading")
        result["gpu_before"] = before
        os.environ["CUDA_VISIBLE_DEVICES"] = before["uuid"]
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TOKENIZERS_PARALLELISM"] = "false"
        runtime = load_runtime(payload)
        torch = runtime["torch"]
        torch_module = torch
        require(torch.cuda.is_available() and torch.cuda.device_count() == 1, "Expected one CUDA device")
        torch.cuda.set_device(0)
        torch.cuda.reset_peak_memory_stats(0)
        result["versions"] = {name: importlib.metadata.version(name) for name in ("torch", "transformers", "accelerate", "peft", "bitsandbytes")}
        for name, version in result["versions"].items():
            if name in preflight["versions"]:
                require(version == preflight["versions"][name], "Runtime changed after CPU preflight: " + name)
        source_text = "\n\n".join(inspect.getsource(obj) for obj in (runtime["Trainer"].training_step, runtime["Trainer"].compute_loss,
                              runtime["SupervisedLogitsTrainer"], runtime["Trainer"].train))
        (output / "actual_runtime_sources.txt").write_text(source_text, encoding="utf-8")
        statistics = {"samples": 0, "sampling_errors": 0, "whole_gpu_sampled_max_mib": 0, "this_process_sampled_max_mib": 0}
        result["nvidia_smi_sampling"] = statistics
        sampler = threading.Thread(target=helper.sample_gpu, args=(stop, output / "gpu_samples.csv", args.gpu, before["uuid"], os.getpid(), statistics), daemon=True)
        sampler.start()
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        from peft import LoraConfig, TaskType, get_peft_model, prepare_model_for_kbit_training
        runtime["set_seed"](SEED)
        tokenizer = AutoTokenizer.from_pretrained(str(args.model_path), trust_remote_code=True, local_files_only=True)
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        tokenizer.padding_side = "right"
        selected = json.loads(Path(preflight["selection_file"]).read_text(encoding="utf-8"))
        require(len(selected) == 17, "Selection incomplete")
        write_json(output / "selected_train_records.json", selected)
        model = AutoModelForCausalLM.from_pretrained(str(args.model_path), trust_remote_code=True, local_files_only=True,
                    device_map={"": 0}, quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                    bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True))
        model.config.use_cache = False
        model = prepare_model_for_kbit_training(model)
        model = get_peft_model(model, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias="none", task_type=TaskType.CAUSAL_LM,
                                  target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]))
        result["official_27b_loaded"] = True
        result["trainable_parameters"] = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
        result["trainable_tensor_count"] = sum(parameter.requires_grad for parameter in model.parameters())
        result["adapter_initialization"] = "Fresh QLoRA on official base, not frozen Mbio or smoke adapter"
        require(result["trainable_parameters"] == 79691776, "Unexpected LoRA parameter count")
        model.print_trainable_parameters()
        for index, (name, count, accum, padded) in enumerate([
            ("single_micro", 5, 1, False), ("accum4_tail", 5, 4, False),
            ("padded_accum4_tail", 5, 4, True), ("production_accum16_tail", 17, 16, False)]):
            print("EQUIV_CASE_START " + name, flush=True)
            case = train_pair(runtime, model, tokenizer, [item["feature"] for item in selected[:count]],
                              output / name, accum, padded, SEED)
            result["cases"][name] = case
            write_json(output / "equivalence_test_results.json", result)
            print("EQUIV_CASE_RESULT " + name + " passed=" + str(case["passed"]), flush=True)
        result["status"] = "TESTED_27B_EQUIVALENCE_PASS" if len(result["cases"]) == 4 and all(case["passed"] for case in result["cases"].values()) else "EQUIVALENCE_NOT_ESTABLISHED"
        code = 0 if result["status"] == "TESTED_27B_EQUIVALENCE_PASS" else 1
    except BaseException as error:
        traceback.print_exc()
        result["error_type"], result["error"] = type(error).__name__, str(error)
        code = 130 if isinstance(error, KeyboardInterrupt) else 1
    finally:
        stop.set()
        if sampler is not None:
            sampler.join(timeout=35)
        if torch_module is not None and torch_module.cuda.is_initialized():
            result["pytorch_peak_allocated_bytes"] = int(torch_module.cuda.max_memory_allocated())
            result["pytorch_peak_reserved_bytes"] = int(torch_module.cuda.max_memory_reserved())
        result["elapsed_seconds_including_load_checks_and_gradient_io"] = round(time.monotonic() - started, 3)
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        result["exit_code"] = code
        write_json(output / "equivalence_test_results.json", result)
        (output / "exit_code.txt").write_text(str(code) + "\n", encoding="ascii")
        if lock is not None:
            lock.close()
        print("EQUIVALENCE_RESULT=" + result["status"] + " exit_code=" + str(code), flush=True)
        print("report=" + str(output / "equivalence_test_results.json"), flush=True)
    raise SystemExit(code)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-root", type=Path, default=Path("/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/a100_assist_20261019_stage1_v1"))
    parser.add_argument("--model-path", type=Path, default=Path("/home/admire/models/Qwen3.8-27B"))
    parser.add_argument("--gpu", type=int, default=2)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--cpu-preflight", action="store_true")
    mode.add_argument("--launch", action="store_true")
    mode.add_argument("--run-dir", type=Path)
    args = parser.parse_args()
    args.task_root = args.task_root.resolve()
    if args.cpu_preflight:
        cpu_preflight(args)
    elif args.launch:
        check_task(args.task_root, args.model_path)
        get_preflight(args.task_root)
        output = unique_dir(args.task_root / "equivalence_runs", "real27b_")
        command = [sys.executable, str(Path(__file__).resolve()), "--task-root", str(args.task_root),
                   "--model-path", str(args.model_path), "--gpu", str(args.gpu), "--run-dir", str(output)]
        with (output / "run.log").open("xb") as log:
            child = subprocess.Popen(command, env={**os.environ, "PYTHONUNBUFFERED": "1"}, cwd=args.task_root,
                        stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (output / "launcher.pid").write_text(str(child.pid) + "\n", encoding="ascii")
        write_json(output / "launch.json", {"pid": child.pid, "command": command, "script_sha256": sha(__file__)})
        (args.task_root / "LAST_EQUIVALENCE_RUN.txt").write_text(str(output) + "\n", encoding="utf-8")
        print("LAUNCHED_EQUIVALENCE pid=" + str(child.pid), flush=True)
        print("run_dir=" + str(output), flush=True)
        print("Launching is not completion; inspect exit_code.txt and equivalence_test_results.json.", flush=True)
    else:
        gpu_run(args)


if __name__ == "__main__":
    main()
