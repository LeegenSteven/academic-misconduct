"""Read completed equivalence evidence using stdlib only; never load a model."""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.metadata
import json
from pathlib import Path
import tempfile
from datetime import datetime, timezone

DEFAULT_RUN = "/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/a100_assist_20261019_stage1_v1/equivalence_runs/real27b_20261019T132930Z_nmayzrpd"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def metric_summary(value):
    return {key: value.get(key) for key in ("passed", "same_keys_and_none_gradients", "tensors_compared",
            "elements_compared", "max_abs", "missing_names", "extra_names", "none_gradient_names")} | {
            "mismatch_count": len(value.get("mismatches", [])),
            "first_three_mismatches": value.get("mismatches", [])[:3]}


def pair_summary(standard, optimized, selected):
    index = optimized.get("sample_index")
    source = selected[index] if isinstance(index, int) and 0 <= index < len(selected) else {}
    keys = ("raw_loss", "returned_scaled_loss", "current_gradient_accumulation_steps",
            "accelerator_gradient_accumulation_steps", "model_accepts_loss_kwargs", "num_items_in_batch",
            "supervised_tokens", "padding_tokens", "sample_index", "batch_sha256")
    left = {key: standard.get(key) for key in keys}
    right = {key: optimized.get(key) for key in keys}
    difference_keys = [key for key in keys if key not in ("raw_loss", "returned_scaled_loss")
                       and left[key] != right[key]]
    return {"micro_step": optimized.get("micro_step"), "claim_id": source.get("claim_id"),
            "original_train_label": source.get("label"), "standard": left, "memopt": right,
            "execution_field_differences": difference_keys,
            "loss_comparison": optimized.get("loss_and_execution"),
            "gradient_comparison": metric_summary(optimized.get("gradients", {}))}


def summarize_case(case, selected, loss_atol):
    branches = case.get("branches", {})
    standard, optimized = branches.get("standard", {}), branches.get("memopt", {})
    left, right = standard.get("microbatches", []), optimized.get("microbatches", [])
    left_by_step = {row.get("micro_step"): row for row in left}
    loss_fail, gradient_fail, pairs = [], [], []
    for row in right:
        step = row.get("micro_step")
        if step not in left_by_step:
            continue
        other = left_by_step[step]
        raw = abs(float(row["raw_loss"]) - float(other["raw_loss"]))
        scaled = abs(float(row["returned_scaled_loss"]) - float(other["returned_scaled_loss"]))
        if raw > loss_atol or scaled > loss_atol:
            loss_fail.append(step)
        if row.get("gradients", {}).get("passed") is not True:
            gradient_fail.append(step)
        pairs.append(pair_summary(other, row, selected))
    updates = optimized.get("optimizer_updates", [])
    update_fail = [row.get("global_step") for row in updates if row.get("parameters", {}).get("passed") is not True]
    representatives = []
    wanted = {1, right[-1].get("micro_step") if right else None,
              loss_fail[0] if loss_fail else None, gradient_fail[0] if gradient_fail else None}
    for pair in pairs:
        if pair["micro_step"] in wanted:
            representatives.append(pair)
    return {"passed": case.get("passed"), "count": case.get("count"), "accumulation": case.get("accumulation"),
            "padded": case.get("right_padding_to_next_128"),
            "standard_micro_count": len(left), "memopt_micro_count": len(right),
            "standard_update_count": len(standard.get("optimizer_updates", [])), "memopt_update_count": len(updates),
            "paired_micro_count": len(pairs), "raw_or_scaled_loss_fail_steps": loss_fail,
            "gradient_audit_fail_steps": gradient_fail, "optimizer_parameter_fail_steps": update_fail,
            "standard_error": standard.get("error"), "memopt_error": optimized.get("error"),
            "representative_microbatches": representatives,
            "optimizer_updates": [{"global_step": row.get("global_step"),
                                    "parameters": metric_summary(row.get("parameters", {}))} for row in updates]}


def runtime_sources():
    """Read installed Python source as text; no torch/transformers imports."""
    result = {}
    try:
        distribution = importlib.metadata.distribution("transformers")
        result["transformers_version"] = distribution.version
        path = Path(distribution.locate_file("transformers/loss/loss_utils.py"))
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        result["loss_utils"] = {"path": str(path), "sha256": sha(path)}
        result["loss_functions"] = {node.name: ast.get_source_segment(source, node) for node in tree.body
                                   if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                                   and node.name in ("fixed_cross_entropy", "ForCausalLMLoss")}
        model_path = Path(distribution.locate_file("transformers/models/qwen3_5/modeling_qwen3_5.py"))
        model_source = model_path.read_text(encoding="utf-8")
        model_tree = ast.parse(model_source)
        result["qwen_model_source"] = {"path": str(model_path), "sha256": sha(model_path)}
        classes = {}
        for node in model_tree.body:
            if not isinstance(node, ast.ClassDef):
                continue
            if not any(part in node.name for part in ("CausalLM", "ConditionalGeneration", "PreTrainedModel")):
                continue
            pieces = []
            for member in node.body:
                if isinstance(member, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "accepts_loss_kwargs" for target in member.targets):
                    pieces.append(ast.get_source_segment(model_source, member))
                if isinstance(member, ast.FunctionDef) and member.name == "forward":
                    lines = ast.get_source_segment(model_source, member).splitlines()
                    indices = set()
                    for index, line in enumerate(lines):
                        if any(word in line for word in ("self.loss_function", "num_items_in_batch", "labels=labels")):
                            indices.update(range(max(0, index-4), min(len(lines), index+6)))
                    if indices:
                        pieces.append("\n".join(lines[index] for index in sorted(indices)))
            if pieces:
                classes[node.name] = pieces
        result["model_loss_snippets"] = classes
    except Exception as error:
        result["inspection_error"] = type(error).__name__ + ": " + str(error)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=Path(DEFAULT_RUN))
    args = parser.parse_args()
    root = args.run_dir.resolve()
    source_path = root / "equivalence_test_results.json"
    original_hash = sha(source_path)
    source = read_json(source_path)
    selected_path = root / "selected_train_records.json"
    selected = read_json(selected_path)
    report = {"diagnostic_kind": "read_only_failure_summary_not_a_new_equivalence_run",
              "prepared_for_user_date": "2026-10-20", "generated_utc": datetime.now(timezone.utc).isoformat(),
              "tool_sha256": sha(__file__), "source_report": str(source_path), "source_sha256": original_hash,
              "status": source.get("status"), "exit_code": source.get("exit_code"),
              "original_thresholds": {key: source.get(key) for key in ("loss_absolute_tolerance",
                    "gradient_max_absolute_tolerance", "gradient_allclose_atol", "gradient_allclose_rtol")},
              "official_27b_loaded": source.get("official_27b_loaded"), "versions": source.get("versions"),
              "error_type": source.get("error_type"), "error": source.get("error"),
              "cases": {name: summarize_case(case, selected, source.get("loss_absolute_tolerance", 1e-5))
                        for name, case in source.get("cases", {}).items()},
              "installed_loss_implementation": runtime_sources(),
              "notes": ["Different raw loss scaling alone does not prove different effective gradients.",
                        "Execution metadata, scaled loss, every gradient and optimizer parameter checks are reported separately.",
                        "The original FAIL status and thresholds are unchanged. No model, training, inference or GPU API is used."]}
    if sha(source_path) != original_hash:
        raise RuntimeError("Original source report changed during diagnostic read")
    with tempfile.NamedTemporaryFile(mode="w", prefix="diagnosis_20261020_", suffix=".json", dir=root,
                                     encoding="utf-8", delete=False) as handle:
        json.dump(report, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")
        output = Path(handle.name)
    print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
    print("DIAGNOSIS_READ_COMPLETE=" + str(output))
    print("diagnosis_sha256=" + sha(output))


if __name__ == "__main__":
    main()
