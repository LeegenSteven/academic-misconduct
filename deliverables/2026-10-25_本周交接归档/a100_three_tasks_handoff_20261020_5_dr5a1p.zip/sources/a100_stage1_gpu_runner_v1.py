"""Run one immutable Sarol smoke trainer in an isolated fresh directory."""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import importlib.metadata
import io
import json
import math
import os
import re
import runpy
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

PACKAGE_SHA = "7e1a0ce8619f66f1f0ef1f9d0f79e457ee22052a10ee81aa95f8874ea6a44b4b"
CONFIG_SHA = "191e0af232104ed8b65258cf3fb2b842e288008baca7633c11b82a1ac7203aab"
TRAIN_INPUT_SHA = "3675d36859434e4d37bf7c96a626aa3e25fa3a6bb334f570adcbfd19e5dc9bf1"
TRAIN_GOLD_SHA = "4ba3335edede70d3de0cf2e55b8fb1ffc322e08b21e57d59dd91cde6320299ca"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def smi(*args):
    return subprocess.run(["nvidia-smi", *args], check=True, capture_output=True, text=True, timeout=15).stdout


def read_gpu(index):
    data = list(csv.reader(io.StringIO(smi("-i", str(index), "--query-gpu=index,uuid,name,memory.used,memory.free,utilization.gpu", "--format=csv,noheader,nounits"))))
    require(len(data) == 1, "GPU selection is ambiguous")
    r = [x.strip() for x in data[0]]
    return {"physical_index": int(r[0]), "uuid": r[1], "name": r[2], "used_mib": int(r[3]), "free_mib": int(r[4]), "utilization_percent": int(r[5])}


def sample_gpu(stop, log_path, gpu_index, gpu_uuid, process_id, summary):
    with log_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["utc", "gpu_index", "gpu_uuid", "whole_gpu_used_mib", "whole_gpu_free_mib", "gpu_util_percent", "this_process_gpu_mib", "error"])
        while not stop.is_set():
            error, own, gpu = "", None, None
            try:
                gpu = read_gpu(gpu_index)
                apps = csv.reader(io.StringIO(smi("--query-compute-apps=pid,used_gpu_memory,gpu_uuid", "--format=csv,noheader,nounits")))
                for r in apps:
                    r = [v.strip() for v in r]
                    if len(r) == 3 and r[0] == str(process_id) and r[2] == gpu_uuid:
                        own = int(r[1])
                summary["samples"] += 1
                summary["whole_gpu_sampled_max_mib"] = max(summary["whole_gpu_sampled_max_mib"], gpu["used_mib"])
                if own is not None:
                    summary["this_process_sampled_max_mib"] = max(summary["this_process_sampled_max_mib"], own)
            except Exception as e:
                error = type(e).__name__ + ": " + str(e)
                summary["sampling_errors"] += 1
            writer.writerow([datetime.now(timezone.utc).isoformat(), gpu_index, gpu_uuid, gpu["used_mib"] if gpu else "", gpu["free_mib"] if gpu else "", gpu["utilization_percent"] if gpu else "", own if own is not None else "", error])
            f.flush()
            stop.wait(2)


def check_artifacts(run_dir, variant, model_path):
    import torch
    from safetensors import safe_open
    train = run_dir / "train"
    config_path = train / "training_config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    for key, value in {"train_samples": 32, "max_length": 5120, "epochs": 1, "seed": 42, "enable_thinking": False, "input_sha256": TRAIN_INPUT_SHA, "gold_sha256": TRAIN_GOLD_SHA, "model_path": str(model_path)}.items():
        require(config.get(key) == value, "Training config mismatch: " + key)
    require(config.get("grad_accum") == 16 and config.get("micro_batch") == 1, "Unexpected batch/accumulation configuration")
    require(config.get("lora_r") == 16 and config.get("lora_alpha") == 32 and config.get("lora_dropout") == 0.05, "Unexpected LoRA configuration")
    require(math.isfinite(config["training_time_minutes"]), "Nonfinite training runtime")
    if variant == "memopt":
        require(config.get("loss_implementation") == "experimental supervised-position logits; causal next-token mean cross-entropy", "Unexpected optimized loss implementation")
    weights = train / "final_adapter/adapter_model.safetensors"
    require(weights.is_file() and weights.stat().st_size > 0, "Adapter weights missing/empty")
    tensors = 0
    with safe_open(weights, framework="pt", device="cpu") as f:
        for name in f.keys():
            require(bool(torch.isfinite(f.get_tensor(name)).all().item()), "Nonfinite adapter tensor: " + name)
            tensors += 1
    require(tensors > 0, "Adapter contains no tensors")
    log_text = (run_dir / "train.log").read_text(encoding="utf-8", errors="replace")
    summaries = re.findall(r"\{[^\r\n]*['\"]train_loss['\"]\s*:[^\r\n]*\}", log_text)
    require(summaries, "Saved adapter found, but training-loss summary absent; inspect the complete log")
    train_summary = ast.literal_eval(summaries[-1])
    require(math.isfinite(float(train_summary["train_loss"])), "Nonfinite training loss")
    require(abs(float(train_summary["epoch"]) - 1.0) < 1e-6, "Training did not complete one epoch")
    files = [config_path, weights, train / "final_adapter/adapter_config.json"]
    return {"saved_tensor_count": tensors, "adapter_tensors_finite": True, "train_summary_from_raw_log": train_summary, "files": {str(p.relative_to(run_dir)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in files}, "reloaded_in_separate_process": False}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--variant", choices=("standard", "memopt"), required=True)
    ap.add_argument("--gpu", type=int, required=True)
    ap.add_argument("--task-root", type=Path, required=True)
    ap.add_argument("--run-dir", type=Path)
    ap.add_argument("--launch", action="store_true", help="Create a fresh run directory and detach a logged child process")
    ap.add_argument("--model-path", type=Path, default=Path("/home/admire/models/Qwen3.8-27B"))
    args = ap.parse_args()
    task = args.task_root.resolve()
    if args.launch:
        require(args.run_dir is None, "--launch creates its own run directory")
        require(task.name == "a100_assist_20261019_stage1_v1", "Unexpected task root")
        require((task / "PACKAGE_SHA256.txt").read_text().strip() == PACKAGE_SHA, "Wrong stage1 package")
        parent = task / "smoke_runs"
        parent.mkdir(exist_ok=True)
        prefix = args.variant + "_smoke32_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_"
        new_run = Path(tempfile.mkdtemp(prefix=prefix, dir=parent))
        require(new_run.parent.resolve() == parent.resolve(), "Unexpected run directory")
        command = [sys.executable, str(Path(__file__).resolve()), "--variant", args.variant, "--gpu", str(args.gpu), "--task-root", str(task), "--run-dir", str(new_run), "--model-path", str(args.model_path)]
        env = {**os.environ, "PYTHONUNBUFFERED": "1", "TOKENIZERS_PARALLELISM": "false"}
        with (new_run / "train.log").open("xb") as log:
            child = subprocess.Popen(command, cwd=task, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (new_run / "launcher.pid").write_text(str(child.pid) + "\n", encoding="ascii")
        (task / ("LAST_" + args.variant.upper() + "_RUN.txt")).write_text(str(new_run) + "\n", encoding="utf-8")
        write_json(new_run / "launch.json", {"pid": child.pid, "command": command, "run_dir": str(new_run), "detached_new_session": True, "launcher_script_sha256": sha(Path(__file__))})
        print("LAUNCHED variant=" + args.variant + " pid=" + str(child.pid), flush=True)
        print("run_dir=" + str(new_run), flush=True)
        print("log=" + str(new_run / "train.log"), flush=True)
        print("Launching is not completion; inspect exit_code.txt and run_metadata.json.", flush=True)
        return
    require(args.run_dir is not None, "Use --launch or provide --run-dir")
    run_dir = args.run_dir.resolve()
    require(task.name == "a100_assist_20261019_stage1_v1", "Unexpected task root")
    require(run_dir.parent == task / "smoke_runs", "Run directory must be under this isolated task's smoke_runs")
    require(run_dir.is_dir(), "Create a new empty run directory first")
    require({p.name for p in run_dir.iterdir()} <= {"train.log", "launcher.pid", "launch.json"}, "Run directory contains existing results; refusing overwrite")
    report = {"operator": "李云", "purpose": "陈明进Sarol32条训练代跑", "variant": args.variant, "pid": os.getpid(), "started_utc": datetime.now(timezone.utc).isoformat(), "task_root": str(task), "run_dir": str(run_dir), "script_path": str(Path(__file__).resolve()), "script_sha256": sha(Path(__file__)), "exclusive_gpu": False, "note": "Shared GPU. nvidia-smi peaks are sampled observations; PyTorch peaks are this-process allocator statistics. This run does not establish training equivalence or complete reload validation."}
    stop, sampler, torch_module, lock = threading.Event(), None, None, None
    code = 1
    began = time.monotonic()
    try:
        require((task / "PACKAGE_SHA256.txt").read_text().strip() == PACKAGE_SHA, "Wrong stage1 package")
        manifest = json.loads((task / "manifest.json").read_text(encoding="utf-8"))
        payload = task / "payload"
        for rel, expected in manifest["payload_files"].items():
            require(sha(payload / rel) == expected, "Payload changed: " + rel)
        require(sha(args.model_path / "config.json") == CONFIG_SHA, "Base config hash changed")
        successful = []
        for p in (task / "preflight_reports").glob("*/preflight.json"):
            prior = json.loads(p.read_text(encoding="utf-8"))
            if prior.get("status") == "A100_CPU_PREFLIGHT_PASS" and prior.get("package_sha256") == PACKAGE_SHA:
                successful.append(p)
        require(successful, "Matching A100 CPU preflight has not passed")
        report["cpu_preflight"] = {"path": str(sorted(successful)[-1]), "sha256": sha(sorted(successful)[-1])}
        import fcntl
        lock = (task / ("gpu_" + str(args.gpu) + ".lock")).open("a+")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = read_gpu(args.gpu)
        require(before["free_mib"] >= 35000, "Less than 35000 MiB currently free; stop before model loading")
        report["gpu_before"] = before
        (run_dir / "gpu_before.txt").write_text(smi("-i", str(args.gpu)), encoding="utf-8")
        # Bind by UUID so CUDA's enumeration order cannot select another card.
        os.environ["CUDA_VISIBLE_DEVICES"] = before["uuid"]
        os.environ["TOKENIZERS_PARALLELISM"] = "false"
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        sys.path.insert(0, str(payload / "code"))
        import torch
        torch_module = torch
        require(torch.cuda.is_available() and torch.cuda.device_count() == 1, "Expected exactly one visible CUDA GPU")
        torch.cuda.set_device(0)
        torch.cuda.reset_peak_memory_stats(0)
        report["torch_runtime"] = torch.__version__
        report["versions"] = {p: importlib.metadata.version(p) for p in ("transformers", "peft", "accelerate", "bitsandbytes", "datasets")}
        report["gpu_visible_name"] = torch.cuda.get_device_name(0)
        report["cuda_visible_devices"] = before["uuid"]
        statistics = {"samples": 0, "sampling_errors": 0, "whole_gpu_sampled_max_mib": 0, "this_process_sampled_max_mib": 0}
        report["nvidia_smi_sampling"] = statistics
        sampler = threading.Thread(target=sample_gpu, args=(stop, run_dir / "gpu_samples.csv", args.gpu, before["uuid"], os.getpid(), statistics), daemon=True)
        sampler.start()
        script_name = "route1_qwen38_train_sarol_v1.py" if args.variant == "standard" else "route1_qwen38_train_sarol_memopt_v1.py"
        script = payload / "code/cmj" / script_name
        invocation = [str(script), "--smoke", "--model-path", str(args.model_path), "--inputs", str(payload / "data/smoke32.inputs.jsonl"), "--gold", str(payload / "data/smoke32.gold.jsonl"), "--max-length", "5120", "--epochs", "1", "--output-dir", str(run_dir / "train")]
        report["trainer_script_sha256"] = sha(script)
        report["trainer_argv"] = invocation
        write_json(run_dir / "run_metadata.json", report)
        print("run_dir=" + str(run_dir), flush=True)
        print("variant=" + args.variant + " physical_gpu=" + str(args.gpu), flush=True)
        sys.argv = invocation
        try:
            runpy.run_path(str(script), run_name="__main__")
        except SystemExit as e:
            require(e.code in (None, 0), "Trainer exited: " + str(e.code))
        report["artifacts"] = check_artifacts(run_dir, args.variant, args.model_path)
        report["status"] = "SMOKE_TRAIN_AND_SAVE_PASS"
        code = 0
    except BaseException as e:
        report["status"] = "FAIL"
        report["error_type"] = type(e).__name__
        report["error"] = str(e)
        traceback.print_exc()
        code = 130 if isinstance(e, KeyboardInterrupt) else 1
    finally:
        stop.set()
        if sampler is not None:
            sampler.join(timeout=35)
        if torch_module is not None:
            try:
                report["pytorch_this_process_peak_allocated_bytes"] = int(torch_module.cuda.max_memory_allocated(0))
                report["pytorch_this_process_peak_reserved_bytes"] = int(torch_module.cuda.max_memory_reserved(0))
            except Exception as e:
                report["pytorch_peak_query_error"] = str(e)
        report["elapsed_seconds_including_load_and_artifact_checks"] = round(time.monotonic() - began, 3)
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        report["exit_code"] = code
        write_json(run_dir / "run_metadata.json", report)
        (run_dir / "exit_code.txt").write_text(str(code) + "\n", encoding="ascii")
        if lock is not None:
            lock.close()
        print("GPU_RUN_RESULT=" + report["status"] + " exit_code=" + str(code), flush=True)
        print("metadata=" + str(run_dir / "run_metadata.json"), flush=True)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
