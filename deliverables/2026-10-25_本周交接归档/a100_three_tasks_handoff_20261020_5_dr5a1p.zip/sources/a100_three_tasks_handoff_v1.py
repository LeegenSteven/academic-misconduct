"""Collect three completed A100 tasks; verify ZIP locally before final delivery.

Stdlib only. No SSH, GPU API, model loading, training or inference in this tool.
Expected experiment failures remain failures; transfer PASS means integrity only.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tempfile
import zipfile
from datetime import datetime, timezone

TASK = Path("/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/a100_assist_20261019_stage1_v1")
PATHS = {
    "cpu_input": "preflight_reports/20261019T124104Z_1792413664812622488",
    "standard": "smoke_runs/standard_smoke32_20261019T125426Z_3ay_10ha",
    "memopt": "smoke_runs/memopt_smoke32_20261019T130040Z_1heijeei",
    "cpu_equivalence": "equivalence_preflight/cpu_20261019T132527Z_1sg7vp70",
    "equivalence": "equivalence_runs/real27b_20261019T132930Z_nmayzrpd",
    "inference_blocked": "eight_edge_runs/eight_edges_20261020T024356Z_v3ny3rzv",
    "inference": "eight_edge_runs/eight_edges_20261020T024852Z_td3pqjmn",
}
HASHES = {
    "package": "7e1a0ce8619f66f1f0ef1f9d0f79e457ee22052a10ee81aa95f8874ea6a44b4b",
    "equivalence": "3eaaa8e9ee1815ff31938b26bf9e696c47b244e5f98abca80964bdc483faf04e",
    "diagnosis": "d9c1feb0748422ed137bba61a74ebd09347996eb44e3af4838ffad7dcfcdb2bf",
    "predictions": "0187801d4513972a32dfd0f4248a978031682775f40ae6cd83b12cbbca77a7f2",
    "inference_metadata": "7e08364aa0b27af11d337bf535d06dc520a9a3c48581ebd69b8994e36ae3acc8",
    "smoke_config": "cf60a36991e6c4204c02c172627b0f0da7083b0c0520749a183f10618c4186ea",
    "smoke_weights": "c87a5b51ca818fec8764ce22087b5fa10d99571d941087beab62e2b330d79783",
    "frozen_weights": "0f4019af9d0f510408f841797c1038bb19abfee8b6e5f24dc7f222501776bd09",
}
SCRIPTS = {
    "a100_assist_20261019_stage1_v1.pyz": HASHES["package"],
    "a100_stage1_gpu_runner_v1.py": "24598dcd90bc28b1b3703bf0eaa9a81c9be74fcda77d9184e68e461ccbe7699b",
    "a100_stage2_equivalence_v1.py": "994356c993d6f627f3d4f113fffa581a3abe0e5b5469fb03cd396c6b632e1579",
    "a100_equivalence_diagnose_v1.py": "926aec626301ebb86417b9e8746f6f3bb26f3175a7bb29a3e48d0fb05fbd62a5",
    "a100_stage3_eight_edges_v1.py": "6baa83cc804c8d0f8608aaf6b0cee470fc088a10a278f215932b68805dbff4a1",
}
IDS = ["PMC-OA-V3-" + value for value in ("02", "03", "04", "05", "06", "07", "09", "10")]
PREDS = ["NOT_ACCURATE", "NOT_ACCURATE", "ACCURATE", "NOT_ACCURATE", "ACCURATE", "NOT_ACCURATE", "NOT_ACCURATE", "NOT_ACCURATE"]


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def as_json(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")


def key(role, relative):
    return "a100/" + PATHS[role] + "/" + relative


def read_json(get, name):
    return json.loads(get(name).decode("utf-8"))


def check_cycle_counts(case, count, accum):
    require(case.get("passed") is False and case.get("count") == count and case.get("accumulation") == accum, "Equivalence case identity/status differs")
    for branch in ("standard", "memopt"):
        data = case["branches"][branch]
        require(data.get("error") is None, "Equivalence branch has an unreported runtime error")
        rows, updates = data["microbatches"], data["optimizer_updates"]
        require(len(rows) == count and len(updates) == (count+accum-1)//accum, "Missing equivalence microbatch or optimizer cycle")
        require(sorted(row["sample_index"] for row in rows) == list(range(count)), "Repeated/missing equivalence example")
        for index, row in enumerate(rows):
            expected = min(accum, count-(index//accum)*accum)
            require(row["current_gradient_accumulation_steps"] == expected, "Tail accumulation divisor differs")


def audit_evidence(get):
    """Used BOTH on A100 raw evidence and the downloaded ZIP's byte contents."""
    for filename, expected in SCRIPTS.items():
        require(digest(get("sources/" + filename)) == expected, "Execution source changed: " + filename)
    package = get("sources/a100_assist_20261019_stage1_v1.pyz")
    with zipfile.ZipFile(io.BytesIO(package)) as nested:
        require(nested.testzip() is None, "Original source/input package CRC failed")
        manifest = json.loads(nested.read("manifest.json"))
        for rel, expected in manifest["payload_files"].items():
            require(digest(nested.read("payload/" + rel)) == expected, "Original payload hash differs: " + rel)
        rows = [json.loads(line) for line in nested.read("payload/data/eight_edges.inputs.jsonl").decode().splitlines() if line.strip()]
    require([row["claim_id"] for row in rows] == IDS, "Input eight-edge IDs/order differ")
    cpu = read_json(get, key("cpu_input", "preflight.json"))
    require(cpu.get("status") == "A100_CPU_PREFLIGHT_PASS", "Stage1 CPU preflight is not passed")
    for role, status, code in (("standard", "FAIL", 1), ("memopt", "SMOKE_TRAIN_AND_SAVE_PASS", 0),
                               ("inference_blocked", "FAIL", 1), ("inference", "INFERENCE_EXECUTED_AND_ARTIFACTS_VERIFIED", 0)):
        report = read_json(get, key(role, "run_metadata.json"))
        require(report.get("status") == status and report.get("exit_code") == code, "Unexpected result for " + role)
        require(int(get(key(role, "exit_code.txt")).decode().strip()) == code, "Exit-code file differs: " + role)
    standard = read_json(get, key("standard", "run_metadata.json"))
    require(standard.get("error_type") == "OutOfMemoryError", "Standard smoke failure cause differs")
    blocked = read_json(get, key("inference_blocked", "run_metadata.json"))
    require("Less than 35000 MiB" in blocked.get("error", ""), "Inference blocked attempt cause differs")
    cfg_bytes = get(key("memopt", "train/training_config.json"))
    require(digest(cfg_bytes) == HASHES["smoke_config"], "Smoke training config hash differs")
    cfg = json.loads(cfg_bytes)
    for name, value in {"train_samples": 32, "epochs": 1, "max_length": 5120, "seed": 42,
                        "enable_thinking": False, "micro_batch": 1, "grad_accum": 16}.items():
        require(cfg.get(name) == value, "Smoke setting differs: " + name)
    eq_bytes = get(key("equivalence", "equivalence_test_results.json"))
    require(digest(eq_bytes) == HASHES["equivalence"], "Original equivalence report hash differs")
    eq = json.loads(eq_bytes)
    require(eq.get("status") == "EQUIVALENCE_NOT_ESTABLISHED" and eq.get("exit_code") == 1, "Equivalence failure was overwritten/misreported")
    require(int(get(key("equivalence", "exit_code.txt")).decode().strip()) == 1, "Equivalence exit file differs")
    expected_cases = {"single_micro": (5, 1), "accum4_tail": (5, 4), "padded_accum4_tail": (5, 4), "production_accum16_tail": (17, 16)}
    require(set(eq.get("cases", {})) == set(expected_cases), "Missing equivalence scenario")
    for name, (count, accum) in expected_cases.items():
        check_cycle_counts(eq["cases"][name], count, accum)
    cpu_eq = read_json(get, key("cpu_equivalence", "preflight.json"))
    require(cpu_eq.get("status") == "CPU_HARNESS_PREFLIGHT_PASS_NOT_27B_EQUIVALENCE", "CPU harness preflight differs")
    diagnostic = get(key("equivalence", "diagnosis_20261020_2s5i7cut.json"))
    require(digest(diagnostic) == HASHES["diagnosis"], "Diagnostic report hash differs")
    require(json.loads(diagnostic)["source_sha256"] == HASHES["equivalence"], "Diagnostic source/report alignment differs")
    pred_bytes = get(key("inference", "inference/cited_pdf_demo.predictions.jsonl"))
    meta_bytes = get(key("inference", "inference/cited_pdf_demo.inference_metadata.json"))
    require(digest(pred_bytes) == HASHES["predictions"] and digest(meta_bytes) == HASHES["inference_metadata"], "Raw inference output hash differs")
    predictions = [json.loads(line) for line in pred_bytes.decode("utf-8").splitlines() if line.strip()]
    require(len(predictions) == 8, "Incomplete eight-edge output")
    meta = json.loads(meta_bytes)
    for name, value in {"adapter_sha256": HASHES["frozen_weights"], "predictions_sha256": HASHES["predictions"],
                        "enable_thinking": False, "do_sample": False, "max_length": 5120, "max_new_tokens": 512}.items():
        require(meta.get(name) == value, "Inference metadata differs: " + name)
    for source, pred, expected in zip(rows, predictions, PREDS):
        require(pred["candidate_id"] == source["claim_id"] and pred["input_sha256"] == source["input_sha256"], "Inference row IDs/input hashes differ")
        require(pred["pred"] == expected and pred["label_valid"] is True, "Prediction differs from original A100 return")
        require(json.loads(pred["raw_output"].strip()) == {"label": expected}, "Raw output has changed or contains other generated fields")
    comparison = []
    for source, pred in zip(rows, predictions):
        reference = "NOT_ACCURATE" if source["claim_id"] in ("PMC-OA-V3-03", "PMC-OA-V3-05") else "ACCURATE"
        comparison.append({"candidate_id": source["claim_id"], "model_label": pred["pred"],
                           "handoff_text_reference_label": reference, "matches_text_reference": pred["pred"] == reference})
    summary = {"smoke_standard": "FAIL_OOM", "smoke_memopt": "TRAIN_AND_SAVE_PASS_RELOAD_NOT_DONE",
               "equivalence": "FOUR_SCENARIOS_NOT_PASSED", "eight_edge_inference": "EXECUTED_ARTIFACTS_VERIFIED",
               "eight_predictions": dict(zip(IDS, PREDS)), "valid_label_count": 8, "invalid_label_count": 0,
               "raw_evidence_and_reason_generated_count": 0, "formal_accuracy_computed": False,
               "text_reference_comparison": {"source": "Chen original handoff prose only; original per-row blind return absent from handoff",
                    "status": "PROVISIONAL_REFERENCE_COMPARISON_NOT_FORMAL_ACCURACY_OR_INDEPENDENT_AGREEMENT",
                    "matching_count": sum(row["matches_text_reference"] for row in comparison), "total": 8, "records": comparison}}
    require(summary["text_reference_comparison"]["matching_count"] == 4, "Handoff-text comparison differs")
    return summary


def read_checked_archive(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "ZIP contains duplicate members")
        require(archive.testzip() is None, "ZIP CRC check failed")
        for name in names:
            pure = PurePosixPath(name)
            require(not pure.is_absolute() and ".." not in pure.parts and "\\" not in name and ":" not in name,
                    "Unsafe ZIP member: " + name)
            info = archive.getinfo(name)
            require(not ((info.external_attr >> 16) & 0o170000) == 0o120000, "ZIP symlink not permitted")
        manifest = json.loads(archive.read("manifest.json"))
        require(set(names) == set(manifest["files"]) | {"manifest.json"}, "Manifest/member set differs")
        entries = {}
        for name, info in manifest["files"].items():
            value = archive.read(name)
            require(len(value) == info["bytes"] and digest(value) == info["sha256"], "ZIP file hash differs: " + name)
            entries[name] = value
        entries["manifest.json"] = archive.read("manifest.json")
    return manifest, entries


def collect(task):
    require(task.name == TASK.name and task.is_dir(), "Unexpected task root")
    entries = {}
    for role, relative in PATHS.items():
        directory = task / relative
        require(directory.is_dir(), "Expected evidence directory absent: " + role)
        for path in sorted(directory.rglob("*")):
            if not path.is_file():
                continue
            require(not path.is_symlink() and path.resolve().is_relative_to(task.resolve()), "Evidence path escapes task")
            if path.suffix.lower() in (".json", ".jsonl", ".txt", ".log", ".csv"):
                require(path.stat().st_size <= 30 * 1024**2, "Unexpectedly large text artifact")
                entries["a100/" + path.relative_to(task).as_posix()] = path.read_bytes()
        print("COLLECTED role=" + role, flush=True)
    for name, expected in SCRIPTS.items():
        path = Path("/home/admire") / name
        require(file_sha(path) == expected, "A100 execution script/package changed: " + name)
        entries["sources/" + name] = path.read_bytes()
    entries["sources/a100_three_tasks_handoff_v1.py"] = Path(__file__).read_bytes()
    frozen_root = Path("/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/cmj_sarol_mbio_full_memopt_trial_20261017_gpu2/train")
    for source, destination, expected in (
        (frozen_root / "checkpoint-100/adapter_config.json", "frozen_Mbio_checkpoint100/adapter_config.json",
         "b425bcd6ba101d02dcb1dd8d9f892b315bd082a7b6feeba938b43bc58aedc2f8"),
        (frozen_root / "training_config.json", "frozen_Mbio_checkpoint100/training_config_from_original_run.json",
         "f468c2cc6c7c16098c814a106db8eb0f44f235228a5b5ee5802a0d1518328d42")):
        data = source.read_bytes()
        require(digest(data) == expected, "Frozen historical configuration differs: " + str(source))
        entries[destination] = data
    entries["a100/manifest.json"] = (task / "manifest.json").read_bytes()
    entries["a100/PACKAGE_SHA256.txt"] = (task / "PACKAGE_SHA256.txt").read_bytes()
    summary = audit_evidence(entries.__getitem__)
    large = []
    weights = [(task / PATHS["memopt"] / "train/final_adapter/adapter_model.safetensors", HASHES["smoke_weights"], "smoke_adapter"),
               (Path("/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/cmj_sarol_mbio_full_memopt_trial_20261017_gpu2/train/checkpoint-100/adapter_model.safetensors"), HASHES["frozen_weights"], "frozen_Mbio_checkpoint100")]
    for path, expected, role in weights:
        actual = file_sha(path)
        require(actual == expected, "Server adapter weights changed: " + role)
        large.append({"role": role, "a100_path": str(path), "bytes": path.stat().st_size,
                      "sha256": actual, "hash_basis": "remeasured_at_collection", "included_in_zip": False})
    eq = json.loads(entries[key("equivalence", "equivalence_test_results.json")])
    eq_root = task / PATHS["equivalence"]
    for path in sorted(eq_root.rglob("*.safetensors")):
        require(path.resolve().is_relative_to(eq_root.resolve()) and not path.is_symlink(), "Unsafe gradient reference")
        if path.name == "initial_trainable.safetensors":
            recorded = eq["cases"][path.parent.name]["initial_trainable_sha256"]
        else:
            recorded = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))["sha256"]
        large.append({"role": "equivalence_gradient_or_parameter_reference", "a100_path": str(path),
                      "bytes": path.stat().st_size, "sha256": recorded,
                      "hash_basis": "recorded_during_equivalence_run_not_rehashed_at_collection", "included_in_zip": False})
    entries["evidence_summary.json"] = as_json(summary)
    entries["server_large_files.json"] = as_json(large)
    entries["README_交接说明.txt"] = ("陈明进A100三项协助实测结果｜李云｜2026-10-20\n\n"
        "这是三项代跑的实测交接包，不代表三项均验收通过。\n"
        "1. 标准32条：显存不足失败；优化32条：训练和保存检查通过，未做独立重载。训练240.5秒，汇总loss=2.88；只有汇总loss，不能声称已观察逐步下降曲线。\n"
        "2. 真实27B等价性：四场景均未通过；每条microbatch与每次optimizer更新记录保留。测试仅使用完整短Train样本及所列场景，未用短样本替代标准32条OOM结果。标准按周期有效token加权，优化按样本均值平均；单条loss相同也存在超阈值梯度差，不能只改显示或放宽阈值登记通过。\n"
        "3. 8条引用边：冻结Mbio checkpoint-100，无gold推理完整执行，8个标签均可解析，2条ACCURATE、6条NOT_ACCURATE；全部原始响应只有label，没有实际生成证据编号或理由。另保留一次加载模型前显存预检查拦截的记录。\n\n"
        "按原交接说明文字列出的人工参考标签，暂有4/8一致，分歧为V3-02/07/09/10。交接包未附与此输入版本逐条匹配的原始人工盲标回传，本对照只能作为参考，不能称为正式准确率或独立人工一致率。\n\n"
        "a100/保存原始日志、报告、配置、逐条预测和各case记录；sources/保存实际执行脚本以及原始输入包pyz。\n"
        "pyz作为ZIP可查看原始输入、gold、共享代码和陈明进交接说明；无需执行即可查看。\n"
        "server_large_files.json登记大体积adapter及梯度参考的A100路径、大小、哈希及是否本次重新实测。它们未装入ZIP，不把历史记录的梯度哈希冒称为本次重新测量。\n"
        "保留标准OOM和等价性未通过的原值。未改写冻结adapter、正式Test预测或历史分类指标，也未启动全量重训。\n"
        "下一步请陈明进复核优化损失归一化及单样本梯度差异，并核对8条预测对应的原始人工记录与证据。\n").encode("utf-8")
    entries["给陈明进_发送说明.txt"] = ("师兄，10月19日交接的三项A100协助已完成实测并整理附件：标准32条因显存不足失败，优化32条训练及保存检查通过；真实27B四组等价性验证均未通过，报告中保留损失归一化、逐参数梯度和更新差异；原冻结Mbio checkpoint-100的8条无gold推理已跑完，原始预测、元数据和日志齐全，8条都只输出label。按交接说明文字参考标签暂有4/8一致，仍请与这版输入对应的原始人工记录核对，未当作正式准确率。失败记录均保留，未改旧模型或正式Test结果。请重点复核等价性问题和V3-02/07/09/10的模型—文字参考分歧。附件中有完整文件哈希；大体积权重与梯度参考的A100路径、哈希单列。\n").encode("utf-8")
    manifest = {"bundle_type": "A100_THREE_TASKS_ACTUAL_RESULTS", "user_date": "2026-10-20",
                "collected_utc": datetime.now(timezone.utc).isoformat(), "all_experiments_passed": False,
                "files": {name: {"sha256": digest(value), "bytes": len(value)} for name, value in sorted(entries.items())}}
    parent = task / "deliveries"
    parent.mkdir(exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix="a100_three_tasks_handoff_20261020_", suffix=".zip", dir=parent, delete=False) as handle:
        archive_path = Path(handle.name)
    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, value in entries.items():
            archive.writestr(name, value)
        archive.writestr("manifest.json", as_json(manifest))
    checked_manifest, checked_entries = read_checked_archive(archive_path)
    require(audit_evidence(checked_entries.__getitem__) == summary, "Packed evidence summary differs")
    print("COLLECT_PASS", flush=True)
    print("archive=" + str(archive_path), flush=True)
    print("archive_sha256=" + file_sha(archive_path), flush=True)
    print("files=" + str(len(checked_manifest["files"]) + 1), flush=True)
    print("bytes=" + str(archive_path.stat().st_size), flush=True)
    print("Transfer integrity PASS; standard OOM and equivalence NOT PASSED remain unchanged.", flush=True)


def verify_local(archive_path, destination, expected_sha):
    require(file_sha(archive_path) == expected_sha.lower(), "Downloaded ZIP SHA-256 differs")
    manifest, entries = read_checked_archive(archive_path)
    summary = audit_evidence(entries.__getitem__)
    require(read_json(entries.__getitem__, "evidence_summary.json") == summary, "Summary is not consistent with raw artifacts")
    require(not destination.exists(), "Final destination already exists; refusing overwrite")
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="_交接验收暂存_", dir=destination.parent))
    for name, value in entries.items():
        target = staging.joinpath(*PurePosixPath(name).parts)
        require(target.resolve().is_relative_to(staging.resolve()), "Extraction path escapes staging")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value)
    for name, info in manifest["files"].items():
        require(file_sha(staging.joinpath(*PurePosixPath(name).parts)) == info["sha256"], "Extracted file differs: " + name)
    (staging / "本地验收结果.json").write_bytes(as_json({"status": "TRANSFER_INTEGRITY_AND_EVIDENCE_ALIGNMENT_PASS",
        "archive_path": str(archive_path.resolve()), "archive_sha256": expected_sha.lower(), "files_checked": len(manifest["files"]),
        "all_experiments_passed": False, "summary": summary}))
    staging.rename(destination)
    print("VERIFY_PASS final_dir=" + str(destination.resolve()))
    print("All original failure states retained; this PASS is file integrity and evidence alignment only.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--collect", action="store_true")
    mode.add_argument("--verify-local", type=Path)
    parser.add_argument("--task-root", type=Path, default=TASK)
    parser.add_argument("--destination", type=Path)
    parser.add_argument("--expected-sha256")
    args = parser.parse_args()
    if args.collect:
        collect(args.task_root.resolve())
    else:
        require(args.destination is not None and args.expected_sha256 is not None, "Local verification needs destination and SHA-256")
        verify_local(args.verify_local, args.destination.resolve(), args.expected_sha256)


if __name__ == "__main__":
    main()
