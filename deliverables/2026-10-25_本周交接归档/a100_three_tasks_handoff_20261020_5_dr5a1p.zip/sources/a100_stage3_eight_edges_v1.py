"""Isolated, logged execution of Chen's unchanged eight-edge inference script."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import runpy
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from datetime import datetime, timezone

TASK = Path("/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/a100_assist_20261019_stage1_v1")
MODEL = Path("/home/admire/models/Qwen3.8-27B")
ADAPTER = Path("/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/cmj_sarol_mbio_full_memopt_trial_20261017_gpu2/train/checkpoint-100")
PACKAGE_SHA = "7e1a0ce8619f66f1f0ef1f9d0f79e457ee22052a10ee81aa95f8874ea6a44b4b"
HELPER_SHA = "24598dcd90bc28b1b3703bf0eaa9a81c9be74fcda77d9184e68e461ccbe7699b"
INPUT_SHA = "b4fbaa273017fbdd62a2727e6c097965ab33a4424edccf842f577ab098087b7d"
SCRIPT_SHA = "1504c65efab48ee17601650a13d2b534b78919609aba776a8c6ff6f739537afb"
MODEL_CONFIG_SHA = "191e0af232104ed8b65258cf3fb2b842e288008baca7633c11b82a1ac7203aab"
ADAPTER_SHA = "0f4019af9d0f510408f841797c1038bb19abfee8b6e5f24dc7f222501776bd09"
ADAPTER_CONFIG_SHA = "b425bcd6ba101d02dcb1dd8d9f892b315bd082a7b6feeba938b43bc58aedc2f8"
IDS = ["PMC-OA-V3-" + part for part in ("02", "03", "04", "05", "06", "07", "09", "10")]


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def raw_fields(text, allowed_ids):
    raw = text.strip()
    if raw.startswith("```") and raw.endswith("```"):
        lines = raw.splitlines()
        if len(lines) >= 3 and lines[0].lower() in ("```", "```json"):
            raw = "\n".join(lines[1:-1]).strip()
    try:
        value = json.loads(raw)
    except (TypeError, ValueError):
        value = None
    value = value if isinstance(value, dict) else {}
    ids = value.get("evidence_ids")
    reason = value.get("reason")
    return {"raw_json_keys": sorted(value),
            "raw_contains_all_four_fields": all(key in value for key in ("label", "evidence_ids", "reason", "confidence")),
            "evidence_ids_nonempty_and_allowed": isinstance(ids, list) and bool(ids) and all(isinstance(item, str) and item in allowed_ids for item in ids),
            "reason_nonempty": isinstance(reason, str) and bool(reason.strip()),
            "confidence_value": value.get("confidence"),
            "confidence_is_calibrated_probability": False}


def check_sources(task, model, adapter):
    require(task.name == TASK.name, "Unexpected task root")
    require((task / "PACKAGE_SHA256.txt").read_text().strip() == PACKAGE_SHA, "Stage1 package differs")
    payload = task / "payload"
    for rel, expected in read_json(task / "manifest.json")["payload_files"].items():
        source = (payload / rel).resolve()
        require(source.is_relative_to(payload.resolve()), "Unsafe payload path")
        require(sha(source) == expected, "Immutable payload changed: " + rel)
    checks = [(payload / "data/eight_edges.inputs.jsonl", INPUT_SHA),
              (payload / "code/cmj/route1_cited_pdf_inference_v1.py", SCRIPT_SHA),
              (model / "config.json", MODEL_CONFIG_SHA),
              (adapter / "adapter_model.safetensors", ADAPTER_SHA),
              (adapter / "adapter_config.json", ADAPTER_CONFIG_SHA)]
    for path, expected in checks:
        require(sha(path) == expected, "Frozen source hash differs: " + str(path))
    rows = jsonl(payload / "data/eight_edges.inputs.jsonl")
    require([row["claim_id"] for row in rows] == IDS, "Wrong eight-edge IDs/order")
    require(all(set(row) == {"claim_id", "system_prompt", "user_prompt", "candidate_evidence", "allowed_evidence_ids", "input_sha256"} for row in rows), "Unexpected input fields; do not pass labels or reasons to model")
    return payload, rows


def audit_outputs(output, rows, inputs_path, adapter, parse_label, model_path=MODEL):
    predictions_path = output / "cited_pdf_demo.predictions.jsonl"
    metadata_path = output / "cited_pdf_demo.inference_metadata.json"
    predictions, metadata = jsonl(predictions_path), read_json(metadata_path)
    require(len(predictions) == len(rows) == 8, "Inference has not returned exactly eight rows")
    expected = {"model_path": str(model_path), "adapter": str(adapter), "adapter_sha256": ADAPTER_SHA,
                "inputs": str(inputs_path), "inputs_sha256": INPUT_SHA,
                "predictions": str(predictions_path), "predictions_sha256": sha(predictions_path),
                "enable_thinking": False, "do_sample": False, "max_new_tokens": 512,
                "max_length": 5120, "operator": "李云"}
    for key, value in expected.items():
        require(metadata.get(key) == value, "Inference metadata mismatch: " + key)
    require(isinstance(metadata.get("inference_time_seconds"), (int, float)) and math.isfinite(metadata["inference_time_seconds"]) and metadata["inference_time_seconds"] >= 0, "Invalid inference runtime")
    records = []
    for index, (prediction, row) in enumerate(zip(predictions, rows)):
        require(prediction["candidate_id"] == row["claim_id"], "Candidate IDs/order differ at " + str(index))
        require(prediction["input_sha256"] == row["input_sha256"], "Per-record input SHA differs")
        parsed = parse_label(prediction["raw_output"])
        require(prediction["pred"] == parsed, "Saved label disagrees with raw output")
        valid = parsed in ("ACCURATE", "NOT_ACCURATE", "IRRELEVANT")
        require(prediction["label_valid"] == valid, "label_valid flag differs")
        require(isinstance(prediction["input_tokens"], int) and prediction["input_tokens"] > 0 and prediction["input_tokens"] + 512 <= 5120, "Token budget invalid")
        records.append({"candidate_id": row["claim_id"], "pred": parsed, "label_valid": valid,
                        "input_tokens": prediction["input_tokens"], **raw_fields(prediction["raw_output"], row["allowed_evidence_ids"])})
    return {"records": records, "total": 8,
            "valid_label_count": sum(row["label_valid"] for row in records),
            "invalid_label_count": sum(not row["label_valid"] for row in records),
            "raw_four_field_count": sum(row["raw_contains_all_four_fields"] for row in records),
            "populated_evidence_and_reason_count": sum(row["evidence_ids_nonempty_and_allowed"] and row["reason_nonempty"] for row in records),
            "gold_used": False, "accuracy_computed": False,
            "note": "Execution/file audit only; four populated wrapper keys are not proof the model generated evidence or reasons. Evidence correctness still requires source review.",
            "files": {path.name: {"sha256": sha(path), "bytes": path.stat().st_size} for path in (predictions_path, metadata_path)}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-root", type=Path, default=TASK)
    parser.add_argument("--model-path", type=Path, default=MODEL)
    parser.add_argument("--adapter", type=Path, default=ADAPTER)
    parser.add_argument("--gpu", type=int, default=2)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--launch", action="store_true")
    modes.add_argument("--run-dir", type=Path)
    args = parser.parse_args()
    task = args.task_root.resolve()
    if args.launch:
        check_sources(task, args.model_path, args.adapter)
        parent = task / "eight_edge_runs"
        parent.mkdir(exist_ok=True)
        root = Path(tempfile.mkdtemp(prefix="eight_edges_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_"), dir=parent))
        command = [sys.executable, str(Path(__file__).resolve()), "--task-root", str(task),
                   "--model-path", str(args.model_path), "--adapter", str(args.adapter), "--gpu", str(args.gpu), "--run-dir", str(root)]
        with (root / "run.log").open("xb") as log:
            child = subprocess.Popen(command, env={**os.environ, "PYTHONUNBUFFERED": "1"}, cwd=task,
                    stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (root / "launcher.pid").write_text(str(child.pid) + "\n", encoding="ascii")
        write_json(root / "launch.json", {"pid": child.pid, "command": command, "script_sha256": sha(__file__)})
        (task / "LAST_EIGHT_EDGE_RUN.txt").write_text(str(root) + "\n", encoding="utf-8")
        print("LAUNCHED_EIGHT_EDGE_INFERENCE pid=" + str(child.pid), flush=True)
        print("run_dir=" + str(root), flush=True)
        print("Launching is not completion; inspect exit_code.txt and run_metadata.json.", flush=True)
        return
    root = args.run_dir.resolve()
    require(root.parent == task / "eight_edge_runs", "Unexpected run directory")
    require({path.name for path in root.iterdir()} <= {"run.log", "launch.json", "launcher.pid"}, "Refuse overwrite of existing inference")
    report = {"status": "FAIL", "operator": "李云", "purpose": "陈明进交接的8条PMC引用边无gold推理",
              "script_sha256": sha(__file__), "started_utc": datetime.now(timezone.utc).isoformat(),
              "run_dir": str(root), "frozen_adapter": str(args.adapter), "adapter_sha256": ADAPTER_SHA,
              "train_or_test_rerun": False, "new_training_performed": False,
              "equivalence_test_status": "Separate run did not establish equivalence; this inference does not repair or override that result."}
    stop, sampler, lock, torch_module = threading.Event(), None, None, None
    started, code = time.monotonic(), 1
    try:
        payload, rows = check_sources(task, args.model_path, args.adapter)
        helper_path = Path("/home/admire/a100_stage1_gpu_runner_v1.py")
        require(sha(helper_path) == HELPER_SHA, "Monitoring helper changed")
        spec = importlib.util.spec_from_file_location("immutable_stage1_helper", helper_path)
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        import fcntl
        lock = (task / ("gpu_%d.lock" % args.gpu)).open("a+")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        before = helper.read_gpu(args.gpu)
        require(before["free_mib"] >= 35000, "Less than 35000 MiB free; stop before model loading")
        report["gpu_before"] = before
        report["exclusive_gpu"] = False
        os.environ["CUDA_VISIBLE_DEVICES"] = before["uuid"]
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TOKENIZERS_PARALLELISM"] = "false"
        sys.path.insert(0, str(payload / "code"))
        import torch
        from shared.route1_qwen38.data_contract import parse_label
        torch_module = torch
        require(torch.cuda.is_available() and torch.cuda.device_count() == 1, "Expected exactly one CUDA GPU")
        torch.cuda.set_device(0)
        torch.cuda.reset_peak_memory_stats(0)
        statistics = {"samples": 0, "sampling_errors": 0, "whole_gpu_sampled_max_mib": 0, "this_process_sampled_max_mib": 0}
        report["gpu_sampling"] = statistics
        sampler = threading.Thread(target=helper.sample_gpu, args=(stop, root / "gpu_samples.csv", args.gpu, before["uuid"], os.getpid(), statistics), daemon=True)
        sampler.start()
        inputs_path = payload / "data/eight_edges.inputs.jsonl"
        source = payload / "code/cmj/route1_cited_pdf_inference_v1.py"
        inference_output = root / "inference"
        invocation = [str(source), "--model-path", str(args.model_path), "--adapter", str(args.adapter),
                      "--inputs", str(inputs_path), "--output-dir", str(inference_output),
                      "--max-length", "5120", "--max-new-tokens", "512", "--operator", "李云"]
        report["inference_script_sha256"] = sha(source)
        report["inference_argv"] = invocation
        write_json(root / "run_metadata.json", report)
        sys.argv = invocation
        print("EIGHT_EDGE_INFERENCE_START frozen_adapter_sha256=" + ADAPTER_SHA, flush=True)
        try:
            runpy.run_path(str(source), run_name="__main__")
        except SystemExit as error:
            require(error.code in (None, 0), "Inference script exited: " + str(error.code))
        report["artifact_audit"] = audit_outputs(inference_output, rows, inputs_path, args.adapter, parse_label, args.model_path)
        check_sources(task, args.model_path, args.adapter)
        report["status"] = "INFERENCE_EXECUTED_AND_ARTIFACTS_VERIFIED"
        code = 0
    except BaseException as error:
        traceback.print_exc()
        report["error_type"], report["error"] = type(error).__name__, str(error)
        code = 130 if isinstance(error, KeyboardInterrupt) else 1
    finally:
        stop.set()
        if sampler is not None:
            sampler.join(timeout=35)
        if torch_module is not None and torch_module.cuda.is_initialized():
            report["pytorch_peak_allocated_bytes"] = int(torch_module.cuda.max_memory_allocated())
            report["pytorch_peak_reserved_bytes"] = int(torch_module.cuda.max_memory_reserved())
        report["elapsed_seconds_including_load_checks"] = round(time.monotonic() - started, 3)
        report["finished_utc"], report["exit_code"] = datetime.now(timezone.utc).isoformat(), code
        write_json(root / "run_metadata.json", report)
        (root / "exit_code.txt").write_text(str(code) + "\n", encoding="ascii")
        if lock is not None:
            lock.close()
        print("EIGHT_EDGE_RESULT=" + report["status"] + " exit_code=" + str(code), flush=True)
        if "artifact_audit" in report:
            for row in report["artifact_audit"]["records"]:
                print(json.dumps(row, ensure_ascii=False), flush=True)
        print("report=" + str(root / "run_metadata.json"), flush=True)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
