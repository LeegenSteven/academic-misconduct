"""SupervisedLogitsTrainer(v2) 与标准 Trainer 的 loss/梯度等价性测试（A100 GPU 版）。

v2 同步修订（2026-10-25，配套 route1_qwen38_train_sarol_memopt_v2.py）：

1. 标准版参照改为**真实 Trainer 路径**：`model(**batch, num_items_in_batch=total_tokens)`，
   由模型内部 fixed_cross_entropy 完成 sum/n_items 归一，不再用
   `outputs.loss * n_sup / total_tokens` 手工换算（v1 的近似参照本身会引入
   mean*n 的 fp32 舍入差，且未覆盖 Trainer 传参路径）。
2. 优化版参照同步修订后的 compute_loss：labels 与 num_items_in_batch 回传模型，
   loss = outputs.loss（模型内部 fixed_cross_entropy），不再自行切片 FCE。
3. 新增 --exact-equivalence 对照：优化版不截断 logits（全 shape），用于确认
   全 shape 模式下与标准版逐位一致（诊断结论：截断 shape 在 bf16 下的输出头
   反向存在 kernel 级确定性差异，详见修订说明）。

覆盖场景：
1. next-token shift 一致性（单条样本 loss/梯度，含 num_items_in_batch 路径）
2. 梯度累积（含最后不足一个周期）
3. 变长标签与 padding

运行要求：A100 或同等 GPU（需加载 Qwen3.8-27B 4-bit NF4）。
用法：
  python test_supervised_logits_equivalence_v2.py \
    --model-path <path> --inputs <train.inputs.jsonl> --gold <train.gold.jsonl> \
    [--exact-equivalence] --num-samples 5 --output equivalence_results_v2.json
"""
import os, sys, json, argparse, hashlib
from pathlib import Path

import torch
import numpy as np
from datasets import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
    Trainer,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType

_HERE = Path(__file__).resolve().parent
_REPO_ROOT = _HERE.parents[1] if (_HERE.parents[1] / "shared" / "route1_qwen38" / "data_contract.py").exists() else _HERE.parents[0]
sys.path.insert(0, str(_REPO_ROOT))
from shared.route1_qwen38.data_contract import AssistantOnlyCollator, encode_assistant_record, load_gold, load_records

sys.path.insert(0, str(_HERE))
from route1_qwen38_train_sarol_memopt_v2 import SupervisedLogitsTrainer

LORA_R = 16
LORA_ALPHA = 32
LORA_DROPOUT = 0.05
MAX_LENGTH = 5120
SEED = 42

# 协议容差（CPU 包协议，与 v1 一致，未改门槛）
LOSS_ATOL = 1e-6
LOSS_RTOL = 1e-5
GRAD_ATOL = 1e-6
GRAD_RTOL = 1e-4


def set_seed(seed):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_model_and_tokenizer(model_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True, local_files_only=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        quantization_config=bnb_config,
        device_map="auto",
        trust_remote_code=True,
        local_files_only=True,
    )
    model.config.use_cache = False
    model = prepare_model_for_kbit_training(model)

    lora_config = LoraConfig(
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        task_type=TaskType.CAUSAL_LM,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    model = get_peft_model(model, lora_config)
    return model, tokenizer


def get_trainable_gradients(model):
    """提取所有可训练参数的梯度，返回dict {name: grad_tensor}"""
    grads = {}
    for name, param in model.named_parameters():
        if param.requires_grad and param.grad is not None:
            grads[name] = param.grad.detach().clone().float()
    return grads


def compare_gradients(grads1, grads2, rtol=GRAD_RTOL, atol=GRAD_ATOL):
    """对比两版梯度，返回最大差异和不一致参数数（协议门槛）"""
    max_diff = 0.0
    mismatched = 0
    total_params = 0
    for name in grads1:
        if name not in grads2:
            mismatched += 1
            continue
        g1 = grads1[name]
        g2 = grads2[name]
        if g1.shape != g2.shape:
            mismatched += 1
            continue
        diff = (g1 - g2).abs().max().item()
        max_diff = max(max_diff, diff)
        total_params += g1.numel()
        if not torch.allclose(g1, g2, rtol=rtol, atol=atol):
            mismatched += 1
    return max_diff, mismatched, len(grads1)


def run_standard(model, batch, total_tokens):
    """标准版：真实 Trainer 路径（model 内部 fixed_cross_entropy, num_items_in_batch）"""
    model.zero_grad()
    outputs = model(**batch, num_items_in_batch=total_tokens)
    loss = outputs.loss
    loss.backward()
    return loss.item(), get_trainable_gradients(model)


def run_memopt(model, batch, total_tokens, exact_equivalence=False):
    """优化版 v2：与 compute_loss 一致——labels/num_items_in_batch 回传模型，
    loss=outputs.loss；exact_equivalence=True 时不截断 logits。"""
    model.zero_grad()
    labels = batch["labels"]
    model_kwargs = {k: v for k, v in batch.items()}
    if total_tokens is not None:
        model_kwargs["num_items_in_batch"] = total_tokens
    if not exact_equivalence:
        positions = torch.nonzero(labels[0, 1:].ne(-100), as_tuple=False).flatten()
        if positions.numel() == 0:
            raise ValueError("No supervised next-token labels in this batch")
        outputs = model(**model_kwargs, logits_to_keep=positions)
    else:
        outputs = model(**model_kwargs)
    loss = outputs.loss
    loss.backward()
    return loss.item(), get_trainable_gradients(model)


def test_single_batch_loss(model, tokenizer, records, max_length, exact_equivalence=False):
    """测试1: 单条样本 loss/梯度一致性（Trainer num_items_in_batch 路径）"""
    print("\n=== 测试1: 单条样本 loss 一致性（num_items_in_batch=单条有效token数） ===")
    collator = AssistantOnlyCollator(tokenizer)
    results = []

    for i, record in enumerate(records):
        dataset = Dataset.from_list([encode_assistant_record(record, tokenizer, max_length)])
        batch = collator([dataset[0]])
        batch = {k: v.to(model.device) for k, v in batch.items()}
        labels = batch["labels"]
        n_sup = int(labels[0, 1:].ne(-100).sum().item())

        loss_std, grads_std = run_standard(model, batch, total_tokens=n_sup)
        loss_opt, grads_opt = run_memopt(model, batch, total_tokens=n_sup, exact_equivalence=exact_equivalence)

        loss_diff = abs(loss_std - loss_opt)
        max_grad_diff, mismatched, total = compare_gradients(grads_std, grads_opt)

        results.append({
            'sample': i,
            'claim_id': record.get('claim_id', i),
            'loss_std': loss_std,
            'loss_opt': loss_opt,
            'loss_diff': loss_diff,
            'max_grad_diff': max_grad_diff,
            'mismatched_params': mismatched,
            'total_params': total,
            'supervised_tokens': n_sup,
            'seq_len': batch['input_ids'].shape[1],
        })
        print(f"  样本{i} (claim_id={record.get('claim_id','?')}): "
              f"loss_std={loss_std:.6f} loss_opt={loss_opt:.6f} "
              f"diff={loss_diff:.2e} max_grad_diff={max_grad_diff:.2e} "
              f"supervised_tokens={n_sup} seq_len={batch['input_ids'].shape[1]}")

    return results


def test_gradient_accumulation(model, tokenizer, records, max_length, accum_steps=4, exact_equivalence=False):
    """测试2: 梯度累积一致性（含最后不足一个周期，真实 Trainer 路径）"""
    print(f"\n=== 测试2: 梯度累积一致性 (accum_steps={accum_steps}) ===")
    collator = AssistantOnlyCollator(tokenizer)

    n_samples = accum_steps + 1
    test_records = records[:n_samples]

    sample_supervised_tokens = []
    for record in test_records:
        dataset = Dataset.from_list([encode_assistant_record(record, tokenizer, max_length)])
        batch = collator([dataset[0]])
        labels = batch["labels"]
        supervised = labels[0, 1:].ne(-100).sum().item()
        sample_supervised_tokens.append(supervised)

    def run_standard_accum(records_subset, total_tokens):
        model.zero_grad()
        losses = []
        for i, record in enumerate(records_subset):
            dataset = Dataset.from_list([encode_assistant_record(record, tokenizer, max_length)])
            batch = collator([dataset[0]])
            batch = {k: v.to(model.device) for k, v in batch.items()}
            loss, _ = run_standard(model, batch, total_tokens)
            losses.append(loss)
            if (i + 1) % accum_steps == 0 or i == len(records_subset) - 1:
                step_grads = get_trainable_gradients(model)
                model.zero_grad()
        return losses, step_grads

    def run_memopt_accum(records_subset, total_tokens):
        model.zero_grad()
        losses = []
        for i, record in enumerate(records_subset):
            dataset = Dataset.from_list([encode_assistant_record(record, tokenizer, max_length)])
            batch = collator([dataset[0]])
            batch = {k: v.to(model.device) for k, v in batch.items()}
            loss, _ = run_memopt(model, batch, total_tokens, exact_equivalence=exact_equivalence)
            losses.append(loss)
            if (i + 1) % accum_steps == 0 or i == len(records_subset) - 1:
                step_grads = get_trainable_gradients(model)
                model.zero_grad()
        return losses, step_grads

    cycle_tokens = sum(sample_supervised_tokens[:accum_steps])
    losses_std, grads_std = run_standard_accum(test_records[:accum_steps], cycle_tokens)
    losses_opt, grads_opt = run_memopt_accum(test_records[:accum_steps], cycle_tokens)

    max_grad_diff, mismatched, total = compare_gradients(grads_std, grads_opt)
    loss_diffs = [abs(a - b) for a, b in zip(losses_std, losses_opt)]

    print(f"  完整周期: {accum_steps}条, total_supervised_tokens={cycle_tokens}")
    print(f"  loss差异: max={max(loss_diffs):.2e}, mean={np.mean(loss_diffs):.2e}")
    print(f"  累积后梯度差异: max={max_grad_diff:.2e}, 不一致参数={mismatched}/{total}")

    if n_samples > accum_steps:
        tail_records = test_records[accum_steps:]
        tail_tokens = sum(sample_supervised_tokens[accum_steps:])
        losses_std_tail, grads_std_tail = run_standard_accum(tail_records, tail_tokens)
        losses_opt_tail, grads_opt_tail = run_memopt_accum(tail_records, tail_tokens)
        max_grad_diff_tail, mismatched_tail, _ = compare_gradients(grads_std_tail, grads_opt_tail)
        loss_diffs_tail = [abs(a - b) for a, b in zip(losses_std_tail, losses_opt_tail)]
        print(f"  尾部周期: {len(tail_records)}条, total_supervised_tokens={tail_tokens}")
        print(f"  尾部loss差异: max={max(loss_diffs_tail):.2e}")
        print(f"  尾部梯度差异: max={max_grad_diff_tail:.2e}, 不一致参数={mismatched_tail}/{total}")

    return {
        'n_samples': n_samples,
        'accum_steps': accum_steps,
        'cycle_tokens': cycle_tokens,
        'loss_diffs': loss_diffs,
        'max_grad_diff': max_grad_diff,
        'mismatched_params': mismatched,
    }


def test_variable_length_and_padding(model, tokenizer, records, max_length, exact_equivalence=False):
    """测试3: 变长标签和padding（Trainer num_items_in_batch 路径）"""
    print("\n=== 测试3: 变长标签和padding ===")
    collator = AssistantOnlyCollator(tokenizer)

    sorted_records = sorted(records, key=lambda r: len(json.dumps(r, ensure_ascii=False)))
    short = sorted_records[0]
    long = sorted_records[-1]

    for name, record in [('short', short), ('long', long)]:
        dataset = Dataset.from_list([encode_assistant_record(record, tokenizer, max_length)])
        batch = collator([dataset[0]])
        batch = {k: v.to(model.device) for k, v in batch.items()}
        labels = batch["labels"]
        supervised = (labels != -100).sum().item()
        seq_len = batch['input_ids'].shape[1]
        padding_count = (labels == -100).sum().item()

        loss_std, _ = run_standard(model, batch, total_tokens=supervised)
        loss_opt, _ = run_memopt(model, batch, total_tokens=supervised, exact_equivalence=exact_equivalence)

        print(f"  {name}: seq_len={seq_len}, supervised_tokens={supervised}, "
              f"padding_tokens={padding_count}, loss_diff={abs(loss_std - loss_opt):.2e}")

    return {'status': 'completed'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--inputs", required=True)
    parser.add_argument("--gold", required=True)
    parser.add_argument("--num-samples", type=int, default=5)
    parser.add_argument("--max-length", type=int, default=MAX_LENGTH)
    parser.add_argument("--exact-equivalence", action="store_true",
                        help="优化版不截断 logits（全 shape），对照验证 kernel 级差异来源")
    parser.add_argument("--output", type=str, default="equivalence_results_v2.json")
    args = parser.parse_args()

    set_seed(SEED)

    print(f"加载模型: {args.model_path}")
    model, tokenizer = load_model_and_tokenizer(args.model_path)
    model.print_trainable_parameters()

    print(f"\n加载测试数据: {args.inputs}")
    gold = load_gold(args.gold, split="train")
    records = load_records(args.inputs, gold, max_samples=args.num_samples)
    print(f"测试样本数: {len(records)}")
    print(f"exact_equivalence={args.exact_equivalence}")

    all_results = {}
    all_results['test1_single_batch'] = test_single_batch_loss(model, tokenizer, records, args.max_length, args.exact_equivalence)
    all_results['test2_grad_accum'] = test_gradient_accumulation(model, tokenizer, records, args.max_length, accum_steps=4, exact_equivalence=args.exact_equivalence)
    all_results['test3_variable_length'] = test_variable_length_and_padding(model, tokenizer, records, args.max_length, args.exact_equivalence)

    print("\n=== 汇总 ===")
    t1 = all_results['test1_single_batch']
    all_loss_diff = max(r['loss_diff'] for r in t1)
    all_grad_diff = max(r['max_grad_diff'] for r in t1)
    print(f"测试1: max_loss_diff={all_loss_diff:.2e}, max_grad_diff={all_grad_diff:.2e}")
    print(f"测试2: max_grad_diff={all_results['test2_grad_accum']['max_grad_diff']:.2e}")

    # 判定（协议门槛：loss atol=1e-6/rtol=1e-5；梯度 atol=1e-6/rtol=1e-4）
    pass_loss = all_loss_diff < max(LOSS_ATOL, LOSS_RTOL * abs(all_results['test1_single_batch'][0]['loss_std']))
    pass_grad_test1 = all_grad_diff < max(GRAD_ATOL, GRAD_RTOL * 1.0)
    pass_grad_test2 = all_results['test2_grad_accum']['max_grad_diff'] < max(GRAD_ATOL, GRAD_RTOL * 1.0)

    print(f"\n判定（协议 loss atol={LOSS_ATOL}/rtol={LOSS_RTOL}, 梯度 atol={GRAD_ATOL}/rtol={GRAD_RTOL}）:")
    print(f"  测试1 loss: {'PASS' if pass_loss else 'FAIL'}")
    print(f"  测试1 梯度: {'PASS' if pass_grad_test1 else 'FAIL'}")
    print(f"  测试2 梯度: {'PASS' if pass_grad_test2 else 'FAIL'}")

    all_results['summary'] = {
        'max_loss_diff_test1': all_loss_diff,
        'max_grad_diff_test1': all_grad_diff,
        'max_grad_diff_test2': all_results['test2_grad_accum']['max_grad_diff'],
        'exact_equivalence': args.exact_equivalence,
        'protocol': {'loss_atol': LOSS_ATOL, 'loss_rtol': LOSS_RTOL, 'grad_atol': GRAD_ATOL, 'grad_rtol': GRAD_RTOL},
        'pass_loss_test1': pass_loss,
        'pass_grad_test1': pass_grad_test1,
        'pass_grad_test2': pass_grad_test2,
        'note': (
            'exact_equivalence=True 时优化版不截断 logits，逐 op 对齐标准 Trainer；'
            'exact_equivalence=False 时保留 supervised-position 截断，bf16 下输出头反向'
            '存在诊断已定量的 kernel 级 shape 差异，见修订说明。'
        ),
        'model_path': args.model_path,
        'inputs_sha256': hashlib.sha256(Path(args.inputs).read_bytes()).hexdigest(),
        'gold_sha256': hashlib.sha256(Path(args.gold).read_bytes()).hexdigest(),
    }

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n结果已保存: {args.output}")


if __name__ == "__main__":
    main()
