"""Read-only supplemental diagnosis; never promote or rewrite original first attempts."""
from __future__ import annotations
import argparse, ast, hashlib, importlib.util, json, re, sys, zipfile
from collections import Counter
from pathlib import Path
from datetime import datetime, timezone
VERSION="route1_pdf_first5_offline_fence_diagnosis_v1r2_20261022"
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def txtsha(s):return hashlib.sha256(s.encode()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding="utf-8"))
def jsonl(p):return [json.loads(s) for s in Path(p).read_text(encoding="utf-8").splitlines() if s.strip()]
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def save_rows(p,rows):Path(p).write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in rows),encoding="utf-8",newline="\n")
def require(ok,msg):
    if not ok:raise ValueError(msg)
def unwrap(raw):
    # Only one complete enclosing json fence; no JSON repair or quote normalization.
    m=re.fullmatch(r"\s*```json[ \t]*\r?\n([\s\S]*?)\r?\n```[ \t]*\s*",raw)
    return (m.group(1),"exact_outer_json_fence_removed") if m else (raw,"unchanged")
def inventory(root):return {p.relative_to(root).as_posix():sha(p) for p in root.rglob("*") if p.is_file()}
def validate_member(root,name):
    p=(root/name).resolve()
    require(p.is_relative_to(root.resolve()) and p.is_file(),"Unsafe/missing artifact")
    return p
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run-root",type=Path,required=True);p.add_argument("--repo-root",type=Path,required=True)
    p.add_argument("--execution-package",type=Path,required=True);p.add_argument("--output-dir",type=Path,required=True)
    p.add_argument("--runtime-plan",type=Path,required=True)
    a=p.parse_args();run=a.run_root.resolve();out=a.output_dir.resolve()
    require(not out.exists() and not out.is_relative_to(run),"New diagnosis directory outside original run required")
    before=inventory(run);require(len(before)==15,"Expected15 downloaded run files")
    req=read(run/"execution_request.json");total=read(run/"execution_summary.json")
    require(sha(a.execution_package)==req["package_sha256"]=="1a9349c25dd967f41119dba183a0d4962845832ae70b42673dcad2b8a283ddfb","Execution package identity mismatch")
    require(req["source_scope_release_sha256"]=="57ce1f04fe089ed4f59cff2923965573237883ef0e12cca2aaeed0ce5cf1c7d8","Scope release differs")
    require(req["execution_release_sha256"]==total["execution_release_sha256"]=="7fbbfe1e363367d3bb9cd97124b44716d25432fa97e96d7629be932b8d1a4a04","Execution resource release differs")
    with zipfile.ZipFile(a.execution_package) as z:
        manifest=json.loads(z.read("manifest.json"))
        for n,h in manifest["files"].items():require(hashlib.sha256(z.read(n)).hexdigest()==h,"Package changed")
        policy=json.loads(z.read("policy.json"))
        require(manifest["files"]["resource_backend.py"]==req["actual_backend_source_sha256"]==total["actual_backend_source_sha256"],"Actual backend differs")
    require(req["settings"]==policy["frozen_settings"] and req["fixed_denominator"]==20,"Frozen settings differ")
    for n,h in req["original_contract_code_sha256"].items():
        require(sha(a.repo_root/"code/ly"/n)==h,"Original validation code differs")
    sys.path.insert(0,str((a.repo_root/"code/ly").resolve()))
    import route1_pdf_pipeline_v3 as contract
    selected=req["selected_case_ids"]
    require(len(selected)==len(set(selected))==5 and selected==policy["probe_policy"]["selected_case_ids"],"First5 point set changed")
    require(sha(a.runtime_plan)=="39b7698258b3baee1d40d6940c56b16f3d03e45ab43c37166887a9f72e9ea678","Frozen A100 CPU input plan differs")
    original_plan=read(a.runtime_plan)
    expected_by_id={r["case_id"]:r for r in original_plan["rows"]}
    records=jsonl(run/"assembled/records.jsonl");byid={r["case_id"]:r for r in records}
    require(len(records)==len(byid)==20 and set(selected)<=set(byid),"Keep original20 rows")
    require(read(run/"assembled/summary.json")==total["assembly"],"Assembly summary mismatch")
    all_responses={};meta={}
    for role in ("classifier","explainer"):
        m=read(run/role/"run_metadata.json");meta[role]=m
        require(m["status"]=="finished" and m["exit_code"]==0 and total["stage_exit_codes"][role]==0,"Stage did not finish")
        require((run/role/"exit_code.txt").read_text().strip()=="0","Exit file differs")
        require(m["selected_case_ids"]==selected and m["fixed_denominator"]==20 and m["settings"]==req["settings"],"Stage selection/settings differ")
        require(m["release_sha256"]==req["source_scope_release_sha256"] and m["execution_release_sha256"]==req["execution_release_sha256"],"Stage release differs")
        require(m["actual_backend_source_sha256"]==req["actual_backend_source_sha256"],"Stage backend differs")
        for n,h in m["files_sha256"].items():require(sha(validate_member(run/role,n))==h,"Stage file hash differs")
        model=m["actual_model"]
        require(model["role"]==role and model["revision"]=="1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0" and model["weights_verified"] is True and model["gpu_loaded"] is True,"Model identity/weight proof differs")
        require(model["adapter_loaded"] is (role=="classifier") and model["adapter_sha256"]==(contract.ADAPTER_SHA if role=="classifier" else None),"Adapter role differs")
        require(model["quantization"]["bnb_4bit_quant_type"]=="nf4" and model["quantization"]["bnb_4bit_compute_dtype"]=="bfloat16" and model["quantization"]["bnb_4bit_use_double_quant"] is False,"Quantization differs")
        require(model["actual_backend_source_sha256"]==req["actual_backend_source_sha256"],"Loaded backend differs")
        budget=model["resource_policy"]
        require(budget["min_free_MiB"]==30000 and budget["headroom_MiB"]==2048 and budget["pytorch_allocator_budget_bytes"]==model["gpu_free_before_load_bytes"]-2048*1024**2,"Resource guard/budget differs")
        rs=jsonl(run/role/"responses.jsonl")
        require([r["case_id"] for r in rs]==selected and all(r["attempted"] is True for r in rs),"Incomplete/reordered first attempts")
        all_responses[role]={r["case_id"]:r for r in rs}
    require(meta["classifier"]["actual_model"]["shards_sha256"]==meta["explainer"]["actual_model"]["shards_sha256"],"Base weight shards differ")
    diagnostics=[];mismatches=[];review=[]
    for ordinal,cid in enumerate(selected,1):
        row=byid[cid];c=all_responses["classifier"][cid];e=all_responses["explainer"][cid]
        require(row["classifier_response"]==c and row["explanation_response"]==e,"Assembled raw response differs")
        candidates=row["retrieval"]["candidates"];available={x["evidence_id"]:x for x in candidates}
        strict_c=contract.parse_classifier(c["raw_output"]);strict_e=contract.parse_explanation(e["raw_output"],candidates)
        require(strict_c==c["parsed"] and strict_e==e["parsed"],"Original strict parse not reproducible")
        require(strict_c["status"]=="valid_label" and strict_c["label"]==row["label"],"Classifier label differs")
        require(row["engineering_success"] is (strict_e["status"]=="structure_and_quotes_valid_pending_human_semantics"),"Original engineering result differs")
        for role,response in (("classifier",c),("explainer",e)):
            obs=response["observed_input"]
            expected=expected_by_id[cid]["stages"][role]
            require(response["input_sha256"]==expected["input_sha256"],"Response frozen input hash differs")
            require(all(obs[k]==expected[k] for k in ("input_tokens","input_ids_sha256","required_total","within_budget","truncation")),"Actual input token fingerprint/budget differs")
            require(obs["generated_tokens"]==len(obs["generated_token_ids"])<=512 and obs["within_budget"] is True,"Generation/token count differs")
        body,operation=unwrap(e["raw_output"]);supp=contract.parse_explanation(body,candidates);obj=contract.strict_json(body)
        require(row["formal_end_to_end_accepted"] is False and row["reason_for_display"] is None and all(x is None for x in row["human_review"].values()),"Unexpected human acceptance")
        bad=[]
        for qi,q in enumerate(obj.get("quotes",[]),1):
            evidence=available[q["evidence_id"]];count=evidence["model_text"].count(q["quote"])
            if count!=1:
                item={"case_id":cid,"quote_index":qi,"evidence_id":q["evidence_id"],"exact_occurrences":count,
                    "model_quote":q["quote"],"candidate_model_text":evidence["model_text"],"candidate_raw_text":evidence["raw_text"],
                    "source_pdf_sha256":evidence["source_pdf_sha256"],"pdf_fragments":evidence["pdf_fragments"],
                    "not_repaired_or_accepted":True}
                mismatches.append(item);bad.append({"quote_index":qi,"evidence_id":q["evidence_id"],"exact_occurrences":count})
        diag={"case_id":cid,"batch_order":ordinal,"original_list_order":next(i for i,r in enumerate(records,1) if r["case_id"]==cid),
            "classifier_label_as_model_output":row["label"],"raw_response_sha256":txtsha(e["raw_output"]),
            "supplemental_operation":operation,"body_sha256":txtsha(body),"original_strict_parsed":strict_e,
            "supplemental_parsed":supp,"non_verbatim_quotes":bad,"generated_tokens":e["observed_input"]["generated_tokens"],
            "original_engineering_success":row["engineering_success"],"formal_semantic_verified":False,
            "original_run_modified":False,"new_inference_performed":False}
        diagnostics.append(diag)
        review.append({"case_id":cid,"batch_order":ordinal,"scope":row["scope"]["prepared_query"],
            "citing_pdf":row["citing_pdf"],"cited_pdf":row["cited_pdf"],
            "model_label":row["label"],"model_reason_not_accepted":obj.get("reason"),"model_selected_evidence_ids":obj.get("evidence_ids"),
            "raw_model_quotes":obj.get("quotes"),"candidates":candidates,
            "original_strict_status":strict_e["status"],"supplemental_status":supp["status"],
            "prediction_exposure":True,"independent_blind_claimed":False,
            "locator_human_check":None,"classification_human_label":None,
            "explanation_semantic_review":None,"reviewer":None,"reviewed_at":None,"joint_adjudication":None})
    remaining=[r for r in records if r["case_id"] not in selected]
    require(len(remaining)==15 and all(r["classifier_response"] is None and r["explanation_response"] is None for r in remaining),"Unreleased point got model output")
    require(sum(r["engineering_success"] for r in records)==total["assembly"]["engineering_success"]==1,"Original engineering total differs")
    counts=Counter(d["supplemental_parsed"]["status"] for d in diagnostics)
    require(sum(d["supplemental_operation"]!="unchanged" for d in diagnostics)==4,"Expected4 enclosed json fences")
    require(counts=={"invalid_explanation_output":2,"structure_and_quotes_valid_pending_human_semantics":3},"Unexpected supplemental diagnosis")
    # Boundary tests for the only new transformation: enclosing fence extraction.
    require(unwrap('```json\n{"x":1}\n```')[0]=='{"x":1}',"Fence test failed")
    for invalid in ('prefix\n```json\n{}\n```','```json\n{}\n```\nsuffix','```json\n{}','```python\n{}\n```'):
        require(unwrap(invalid)==(invalid,"unchanged"),"Unexpected arbitrary extraction")
    require(inventory(run)==before and "torch" not in sys.modules,"Original files changed or torch imported")
    out.mkdir(parents=True)
    save_rows(out/"逐点补充解析.jsonl",diagnostics)
    save_rows(out/"逐字摘录不一致明细.jsonl",mismatches)
    save_rows(out/"5点人工复核材料_未填写.jsonl",review)
    save(out/"原始15文件_SHA256.json",before)
    report={"version":VERSION,"checked_at_utc":datetime.now(timezone.utc).isoformat(),
        "status":"OFFLINE_SUPPLEMENTAL_DIAGNOSIS_COMPLETE_NOT_RESULT_PROMOTION",
        "original_strict_engineering_success":1,"first_batch_points":5,"fixed_denominator":20,
        "original_classifier_valid_labels":5,"fenced_responses":4,"all5_JSON_bodies_valid":True,
        "frozen_A100_runtime_plan_sha256":sha(a.runtime_plan),"actual_input_fingerprints_matched":10,
        "supplemental_structure_and_quotes_passed":counts["structure_and_quotes_valid_pending_human_semantics"],
        "supplemental_structure_and_quotes_failed":counts["invalid_explanation_output"],
        "non_verbatim_quote_count":len(mismatches),"semantic_verified":0,"formal_end_to_end_accepted":0,
        "new_model_inference":False,"original_files_unchanged":inventory(run)==before,
        "scope_release_sha256":req["source_scope_release_sha256"],"execution_release_sha256":req["execution_release_sha256"],
        "pending_A100_external_hash_comparison_of_downloaded_unhashed_metadata":True,
        "note":"Original stage artifact hashes verified. No server-supplied hash list exists for all15 root/metadata files; local hashes archived. Supplemental normalization is not a changed frozen parser."}
    save(out/"核对摘要.json",report)
    lines=["# 首批5点离线补充诊断（2026-10-22）","",
        "## 结论","",
        "- 两模型阶段均完成：分类5点、解释5点；权重、量化、输入、首次输出及原解析记录核对一致。",
        "- 原始严格工程结果仍为1/5；固定分母20，其他15点未运行，人工验收0。",
        "- 4条解释被单层Markdown json围栏包裹。仅在新诊断文件中移除完整外层围栏后，5条正文均可解析JSON。",
        "- 继续调用未修改的原结构和逐字摘录检查：补充结果3/5通过、2/5仍失败。这不是正式结果替换或语义通过。",
        "- 15个下载文件保持逐字节不变；原stage元数据中的文件哈希已验证。其他文件仅归档本地SHA，未冒称全部已与独立服务器哈希表比对。",
        "","## 逐点结果（模型标签不等于人工结论）","",
        "| 首批次序 | 原清单次序 | 引用主题 | 模型标签 | 原严格工程检查 | 去围栏补充检查 |",
        "|---|---|---|---|---|---|"]
    titles=["PDB结构数量","Trimmomatic","AfterQC","2019年12月初武汉病例","新型RNA冠状病毒"]
    for d,title in zip(diagnostics,titles):
        lines.append(f"| {d['batch_order']} | {d['original_list_order']} | {title} | {d['classifier_label_as_model_output']} | {'通过' if d['original_engineering_success'] else '失败'} | {'结构/摘录通过，语义待核' if d['supplemental_parsed']['status']=='structure_and_quotes_valid_pending_human_semantics' else '摘录非逐字匹配'} |")
    lines+=["","## 仍需人工核对的问题","",
        "以下为基于已保存候选文本的复核提示，不是李云/陈明进意见或共同裁决；没有填写人工标签、签名或日期。",
        "",
        "1. PDB：三处摘录未逐字匹配原候选，涉及换行和断词连字符。理由还直接比较144,000个各类结构模型与约100,000个独特蛋白质；须核查计数对象及时间口径，不能只据数值大小认定矛盾。",
        "2. Trimmomatic：补充结构/摘录通过；仍需核查理由对adapter工具和popular等修饰语的支持范围，不能把模型自述当裁决。",
        "3. AfterQC：补充结构/摘录通过；理由将detect and cut adapters与adapter trimming视作支持有限，并质疑功能整合表述，需按语义而非要求逐词同名来复核。",
        "4. 武汉病例：原严格结构/摘录已通过；D01:S05写的是首位患者的symptom onset date（发病日期），须区分被识别日期以及原句first cases等范围。",
        "5. 新型冠状病毒：三处摘录未逐字匹配，含换行、断词及软连字符；还需核查候选中的enveloped支持与限制，不能先给最终语义结论。",
        "",
        "## 下一步","",
        "先提交本轮真实5点结果、失败明细及复核问题给陈明进/负责人，逐点核对。若决定采用容忍外层代码围栏的解析规则，应另立解析版本及验收口径，并保留当前1/5原结果；本诊断没有修改冻结解析器。",
        "两位实际意见及共同裁决尚未填写。当前材料已展示模型预测，不能记为独立盲复核或人工一致率。",
        "",
        "文件：逐点补充解析.jsonl、逐字摘录不一致明细.jsonl、5点人工复核材料_未填写.jsonl、核对摘要.json及原始15文件_SHA256.json。"]
    (out/"核对报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8",newline="\n")
    require(inventory(run)==before,"Source file changed during diagnosis")
    print(json.dumps(report,ensure_ascii=True))
if __name__=="__main__":main()

