"""FP32 logic layer: tiny real Qwen3_5 + LoRA + actual Trainer.train.

Reuses the previously archived full-vocabulary config and tokenized fixtures.
No pretrained 27B weights, NF4, frozen adapter, Train/Test evaluation or GPU is
used. Candidate selected mode is mandatory; full-shape is not an acceptance
shortcut. All original tolerances remain unchanged. See bundle manifest.
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import importlib.metadata
import inspect
import json
import math
from pathlib import Path
import sys
import traceback

import torch
import torch.nn.functional as F
from transformers import (AutoModelForCausalLM, Qwen3_5TextConfig, Trainer,
                          TrainerCallback, TrainingArguments, set_seed)
from peft import LoraConfig, TaskType, get_peft_model
from route1_qwen38_train_sarol_memopt_v3 import SupervisedLogitsTrainer

LOSS_ATOL, LOSS_RTOL = 1e-6, 1e-5
GRAD_ATOL, GRAD_RTOL = 1e-6, 1e-4
TARGETS = ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']
CASES = (
    ('single_micro', 5, 1, False, False, None),
    ('accum4_tail1', 5, 4, False, False, None),
    ('padded_accum4_tail1', 5, 4, True, False, None),
    ('production_accum16_tail13', 29, 16, False, False, None),
    ('eos_as_pad_accum4_tail1', 5, 4, True, True, None),
    ('reject_micro_mean', 5, 4, False, False, 'micro_mean'),
    ('reject_reset_gradient', 5, 4, False, False, 'reset_gradient'),
)


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + '\n', encoding='utf-8')


def loss_compare(actual, reference):
    finite = math.isfinite(actual) and math.isfinite(reference)
    diff = abs(actual - reference) if finite else None
    return {'finite': finite, 'max_abs': diff,
            'passed_A': finite and diff < 1e-5,
            'passed_B': finite and diff <= LOSS_ATOL + LOSS_RTOL * abs(reference)}


def compare(actual, reference):
    same = bool(actual) and set(actual) == set(reference)
    details = []
    for name in sorted(set(actual) | set(reference)):
        valid = (name in actual and name in reference and
                 actual[name].shape == reference[name].shape and
                 bool(torch.isfinite(actual[name]).all()) and
                 bool(torch.isfinite(reference[name]).all()))
        diff = float((actual[name] - reference[name]).abs().max()) if valid else None
        details.append({'name': name, 'max_abs': diff, 'finite_same_shape': valid,
                        'passed_A': valid and diff < 1e-4,
                        'passed_B': valid and bool(torch.allclose(actual[name], reference[name],
                                                                atol=GRAD_ATOL, rtol=GRAD_RTOL))})
    return {'same_names_nonempty': same, 'tensor_count': len(details),
            'max_abs': max((x['max_abs'] for x in details if x['max_abs'] is not None), default=None),
            'passed_A': same and all(x['passed_A'] for x in details),
            'passed_B': same and all(x['passed_B'] for x in details), 'per_tensor': details}


def validate_history(micros, updates, count, accum, padded):
    need(len(micros) == count, 'Missing microbatch')
    need(sorted(x['sample_index'] for x in micros) == list(range(count)), 'Missing/duplicate sample')
    need([x['step'] for x in updates] == list(range(1, math.ceil(count / accum) + 1)),
         'Missing optimizer update, including tail')
    for start in range(0, count, accum):
        cycle = micros[start:start + accum]
        total = sum(x['supervised_tokens'] for x in cycle)
        need(all(x['num_items_in_batch'] == total for x in cycle), 'Wrong cycle denominator')
        need(all(x['actual_accumulation_steps'] == len(cycle) for x in cycle), 'Wrong tail length')
    need(all((x['padding_tokens'] > 0) == padded and x['eos_supervised'] for x in micros),
         'Missing real padding/EOS coverage')
    need(all(x['gradient_carry_preserved'] for x in micros), 'Gradients not retained between micros')
    need(all(x['optimizer_steps'] == [x['step']] and x['changed'] for x in updates),
         'Optimizer state reset or degenerate update')


def branch_pass(micros, updates):
    return (bool(micros) and bool(updates) and all(x.get('passed_B', False) for x in micros)
            and all(x.get('passed_B', False) for x in updates))


def controls():
    """Acceptance negative cases, separate from actual Trainer numerical cases."""
    need(not compare({}, {})['passed_B'], 'Accepted empty gradients')
    need(not compare({'a': torch.ones(1)}, {'b': torch.ones(1)})['passed_B'], 'Accepted missing names')
    need(not compare({'a': torch.ones(1)}, {'a': torch.ones(2)})['passed_B'], 'Accepted shape mismatch')
    for value in (float('nan'), float('inf')):
        need(not compare({'a': torch.tensor([value])}, {'a': torch.zeros(1)})['passed_B'], 'Accepted nonfinite tensor')
        need(not loss_compare(value, 0)['passed_B'], 'Accepted nonfinite loss')
    ref = torch.tensor([0.006317138671875])
    need(not compare({'g': ref + 3.0517578125e-5}, {'g': ref})['passed_B'], 'Old B failure waived')
    need(not branch_pass([{'passed_B': True}], [{'passed_B': False}]), 'Update failure ignored')
    need(not branch_pass([{'passed_B': True}, {'passed_B': False}], [{'passed_B': True}]), 'Tail failure ignored')
    need(not branch_pass([], [{'passed_B': True}]), 'Missing micros accepted')
    good = [{'sample_index': i, 'supervised_tokens': 2, 'num_items_in_batch': 8 if i < 4 else 2,
             'actual_accumulation_steps': 4 if i < 4 else 1, 'padding_tokens': 3,
             'eos_supervised': True, 'gradient_carry_preserved': True} for i in range(5)]
    updates = [{'step': i, 'optimizer_steps': [i], 'changed': True} for i in (1, 2)]
    validate_history(good, updates, 5, 4, True)
    rejected = []
    for kind in ('missing_tail', 'optimizer_reset', 'fake_padding', 'wrong_denominator'):
        rows = [dict(x) for x in good]; steps = [dict(x) for x in updates]
        if kind == 'missing_tail': steps.pop()
        if kind == 'optimizer_reset': steps[1]['optimizer_steps'] = [1]
        if kind == 'fake_padding': rows[0]['padding_tokens'] = 0
        if kind == 'wrong_denominator': rows[-1]['num_items_in_batch'] = 8
        try:
            validate_history(rows, steps, 5, 4, True)
        except RuntimeError:
            rejected.append(kind)
        else:
            raise RuntimeError('Invalid history accepted: ' + kind)
    from types import SimpleNamespace
    from transformers.loss.loss_utils import ForCausalLMLoss
    class Projection(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.weight = torch.nn.Parameter(torch.arange(66, dtype=torch.float32).reshape(1, 6, 11) / 30)
        def forward(self, labels=None, logits_to_keep=0, num_items_in_batch=None):
            ix = slice(-logits_to_keep, None) if isinstance(logits_to_keep, int) else logits_to_keep
            logits = self.weight[:, ix, :]
            loss = None if labels is None else ForCausalLMLoss(logits, labels, 11, num_items_in_batch=num_items_in_batch)
            return SimpleNamespace(logits=logits, loss=loss)
    projection = Projection()
    labels = torch.tensor([[-100, -100, 2, -100, 7, 8]])
    for denominator in (None, 3, 9):
        native = projection(labels=labels, num_items_in_batch=denominator).loss
        selected, outputs = SupervisedLogitsTrainer.compute_loss(
            SimpleNamespace(exact_equivalence=False), projection, {'labels': labels}, True, denominator)
        need(loss_compare(float(selected.detach()), float(native.detach()))['passed_B'], 'Shift/normalization API mismatch')
        need(outputs.logits.shape == (1, 3, 11), 'Candidate did not select the three target positions')
        ga = torch.autograd.grad(selected, projection.weight, retain_graph=True)[0]
        gb = torch.autograd.grad(native, projection.weight)[0]
        need(compare({'weight': ga}, {'weight': gb})['passed_B'], 'Selected shift gradient mismatch')
    for bad_labels, denominator in ((torch.full_like(labels, -100), 3), (labels.repeat(2, 1), 3),
                                    (labels, 0), (labels, float('nan'))):
        try:
            SupervisedLogitsTrainer.compute_loss(SimpleNamespace(exact_equivalence=False), projection,
                                                {'labels': bad_labels}, num_items_in_batch=denominator)
        except ValueError:
            pass
        else:
            raise RuntimeError('Malformed candidate input accepted')
    return {'passed': True, 'history_negative_controls': rejected,
            'selected_shift_mean_and_cycle_sum_api_and_gradient_checks': True,
            'empty_asymmetric_nonfinite_shape_and_false_pass_controls': True}


def run(output, fixtures_path, config_path, threads=4):
    need(not torch.cuda.is_initialized(), 'FP32 CPU layer must not initialize CUDA')
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True, warn_only=False)
    versions = {n: importlib.metadata.version(n) for n in ('torch', 'transformers', 'peft', 'accelerate', 'datasets')}
    for name, expected in {'transformers': '5.8.0', 'peft': '0.21.2', 'accelerate': '1.14.0'}.items():
        need(versions[name] == expected, name + ' differs from audited API version')
    fixtures = json.loads(Path(fixtures_path).read_text(encoding='utf-8'))
    features = fixtures['features']
    need(len(features) == 29 and len(fixtures['records']) == 29, 'Need all 29 frozen synthetic fixtures')
    cfg = Qwen3_5TextConfig.from_dict(json.loads(Path(config_path).read_text(encoding='utf-8')))
    need(cfg.vocab_size == 248320 and cfg.hidden_size == 32 and cfg.num_hidden_layers == 4,
         'Unexpected tiny architecture/full vocabulary')
    cfg._attn_implementation = 'eager'
    for f in features:
        need(len(f['input_ids']) == len(f['labels']) == len(f['attention_mask']), 'Malformed feature')
        need(f['labels'][0] == -100 and max(f['input_ids']) < cfg.vocab_size, 'Invalid feature IDs/shift')
        need(any(x == cfg.eos_token_id for x in f['labels']), 'Missing supervised EOS')
    need(len({sum(t != -100 for t in f['labels']) for f in features}) >= 2, 'Need variable target lengths')
    summary = {'status': 'RUNNING', 'versions': versions, 'controls': controls(), 'cases': {},
               'scope': 'Synthetic fixtures, tiny randomly initialized real Qwen3_5 architecture, full vocabulary, FP32 CPU, actual LoRA/Trainer; not 27B/NF4 or classification evaluation',
               'candidate_sha256': sha(Path(inspect.getfile(SupervisedLogitsTrainer))),
               'test_sha256': sha(__file__), 'fixtures_sha256': sha(fixtures_path), 'config_sha256': sha(config_path),
               'candidate_mode': 'selected_logits', 'original_B_failures_retained': True,
               'dropout_numerical_only': 0.0, 'production_dropout_unchanged': 0.05,
               'nonzero_lora_A_B': True, 'optimizer': 'adamw_torch', 'weight_decay': 0.0,
               'learning_rate': 1e-4, 'scheduler_numerical_protocol': 'constant, warmup=0',
               'production_scheduler_unchanged': 'cosine, warmup_ratio=0.03',
               'max_grad_norm': 1.0, 'gradient_checkpointing': True,
               'tolerance_A': {'loss_abs_strict_lt': 1e-5, 'gradient_abs_strict_lt': 1e-4},
               'tolerance_B': {'loss_atol': LOSS_ATOL, 'loss_rtol': LOSS_RTOL,
                               'tensor_atol': GRAD_ATOL, 'tensor_rtol': GRAD_RTOL},
               'required_cases': [x[0] for x in CASES]}
    write(output / 'summary.json', summary)
    (output / 'actual_runtime_sources.txt').write_text('\n\n'.join(inspect.getsource(x) for x in (
        Trainer.training_step, Trainer.compute_loss, Trainer._inner_training_loop, SupervisedLogitsTrainer)), encoding='utf-8')
    set_seed(42)
    base = AutoModelForCausalLM.from_config(cfg, trust_remote_code=False)
    need(type(base).__name__ == 'Qwen3_5ForCausalLM', 'Wrong actual architecture')
    for p in base.parameters(): p.requires_grad_(False)
    model = get_peft_model(base, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.0,
        target_modules=TARGETS, bias='none', task_type=TaskType.CAUSAL_LM)).to('cpu', dtype=torch.float32)
    rng = torch.Generator(device='cpu').manual_seed(314159)
    with torch.no_grad():
        for n, p in model.named_parameters():
            if p.requires_grad:
                need('lora_' in n, 'Unexpected trainable parameter')
                p.copy_(torch.randn(p.shape, generator=rng) * 0.02)
    for module in model.modules():
        if isinstance(module, torch.nn.Dropout): need(module.p == 0, 'Numerical dropout must be zero')

    def snapshot(gradients=False):
        result = {}
        for n, p in model.named_parameters():
            if not p.requires_grad: continue
            v = p.grad if gradients else p
            need(v is not None and v.dtype == torch.float32 and v.device.type == 'cpu', 'Missing/non-FP32 tensor: ' + n)
            need(bool(torch.isfinite(v).all()), 'Nonfinite tensor: ' + n)
            result[n] = v.detach().clone()
        need(bool(result), 'Empty trainable tensors')
        return result

    def digest(values):
        h = hashlib.sha256()
        for n, v in sorted(values.items()):
            h.update(n.encode()); h.update(v.detach().contiguous().numpy().tobytes())
        return h.hexdigest()

    initial = snapshot()
    need(any('lora_A' in n for n in initial) and any('lora_B' in n for n in initial), 'No LoRA A/B')
    need(all(v.ne(0).any() for v in initial.values()), 'Degenerate LoRA initialization')
    base_before = digest({n: p for n, p in model.named_parameters() if not p.requires_grad})
    summary['initial_lora_sha256'] = digest(initial)

    class Collator:
        def __init__(self, padded, eos_pad):
            self.padded = padded
            self.pad_id = cfg.eos_token_id if eos_pad else cfg.pad_token_id
        def __call__(self, rows):
            need(len(rows) == 1, 'Microbatch must be one')
            row = dict(rows[0]); index = row.pop('_audit_index')
            row = {k: list(v) for k, v in row.items()}
            if self.padded:
                extra = 3 + index % 5
                for k, v in (('input_ids', self.pad_id), ('attention_mask', 0), ('labels', -100)):
                    row[k] += [v] * extra
            batch = {k: torch.tensor([v], dtype=torch.long) for k, v in row.items()}
            need(bool(batch['labels'][batch['attention_mask'].eq(0)].eq(-100).all()), 'Supervised padding')
            batch['_audit_index'] = torch.tensor([index])
            return batch

    class Observe:
        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            labels = inputs['labels']
            loss, outputs = super().compute_loss(model, dict(inputs), return_outputs=True, num_items_in_batch=num_items_in_batch)
            self.raw = float(loss.detach())
            need(loss.dtype == torch.float32 and math.isfinite(self.raw), 'Non-FP32 loss')
            if self.branch == 'standard':
                with torch.no_grad():
                    targets = F.pad(labels, (0, 1), value=-100)[:, 1:]
                    oracle = F.cross_entropy(outputs.logits.float().reshape(-1, cfg.vocab_size),
                                             targets.reshape(-1), ignore_index=-100, reduction='sum') / num_items_in_batch
                need(loss_compare(self.raw, float(oracle))['passed_B'], 'Native loss differs from sum/N oracle')
            return (loss, outputs) if return_outputs else loss
        def training_step(self, model, inputs, num_items_in_batch=None):
            inputs = dict(inputs); index = int(inputs.pop('_audit_index').item())
            labels = inputs['labels']
            micro = len(self.micros)
            cycle_start = micro % self.args.gradient_accumulation_steps == 0
            existing_grad = None if cycle_start else snapshot(True)
            carried = cycle_start or all(torch.equal(existing_grad[n], v) for n, v in self.previous_grad.items())
            row = {'micro': micro + 1, 'sample_index': index,
                   'batch_sha256': hashlib.sha256(json.dumps({k: v.tolist() for k, v in inputs.items()}, sort_keys=True).encode()).hexdigest(),
                   'supervised_tokens': int(labels[:, 1:].ne(-100).sum()),
                   'num_items_in_batch': int(num_items_in_batch),
                   'actual_accumulation_steps': int(self.current_gradient_accumulation_steps),
                   'padding_tokens': int(inputs['attention_mask'].eq(0).sum()),
                   'eos_supervised': bool((labels == cfg.eos_token_id).any()),
                   'gradient_carry_preserved': carried}
            result = super().training_step(model, inputs, num_items_in_batch=num_items_in_batch)
            gradients = snapshot(True)
            self.previous_grad = gradients
            row.update(raw_loss=self.raw, scaled_loss=float(result))
            if self.branch == 'standard':
                self.references.append({'row': dict(row), 'gradients': gradients})
            else:
                ref = self.references[micro]
                row['same_execution'] = all(row[k] == ref['row'][k] for k in (
                    'sample_index', 'batch_sha256', 'supervised_tokens', 'num_items_in_batch',
                    'actual_accumulation_steps', 'padding_tokens', 'eos_supervised'))
                row['loss'] = loss_compare(self.raw, ref['row']['raw_loss'])
                row['scaled_loss_comparison'] = loss_compare(float(result), ref['row']['scaled_loss'])
                row['gradients'] = compare(gradients, ref['gradients'])
                row['passed_A'] = row['same_execution'] and all(row[k]['passed_A'] for k in ('loss', 'scaled_loss_comparison', 'gradients'))
                row['passed_B'] = carried and row['same_execution'] and all(row[k]['passed_B'] for k in ('loss', 'scaled_loss_comparison', 'gradients'))
            self.micros.append(row)
            print(f'MICRO case={self.case} branch={self.branch} step={micro+1} loss={self.raw:.8f}', flush=True)
            return result

    class Standard(Observe, Trainer): pass
    class Candidate(Observe, SupervisedLogitsTrainer): pass
    class WrongMean(SupervisedLogitsTrainer):
        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            return super().compute_loss(model, inputs, return_outputs, num_items_in_batch=None)
    class MeanNegative(Observe, WrongMean): pass
    class WrongReset(SupervisedLogitsTrainer):
        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            model.zero_grad(set_to_none=True)
            return super().compute_loss(model, inputs, return_outputs, num_items_in_batch)
    class ResetNegative(Observe, WrongReset): pass

    for name, count, accum, padded, eos_pad, fault in CASES:
        directory = output / name; directory.mkdir()
        refs, update_refs, branches = [], [], {}
        cls_candidate = {'micro_mean': MeanNegative, 'reset_gradient': ResetNegative}.get(fault, Candidate)
        for branch, cls in (('standard', Standard), ('candidate', cls_candidate)):
            with torch.no_grad():
                for n, p in model.named_parameters():
                    if p.requires_grad: p.copy_(initial[n])
            model.zero_grad(set_to_none=True)
            set_seed(42)
            updates = []
            previous_parameters = {n: v.clone() for n, v in initial.items()}

            class Updates(TrainerCallback):
                def on_train_begin(self, args, state, control, **kwargs):
                    need(not kwargs['optimizer'].state_dict()['state'], 'Initial optimizer state not empty')
                    self.optimizer_id = id(kwargs['optimizer'])
                def on_step_end(self, args, state, control, **kwargs):
                    nonlocal previous_parameters
                    optimizer = kwargs['optimizer']
                    need(id(optimizer) == self.optimizer_id, 'Optimizer object replaced mid-run')
                    params = snapshot()
                    delta = {n: params[n] - previous_parameters[n] for n in params}
                    previous_parameters = params
                    slots = optimizer.state_dict()['state']
                    need(len(slots) == len(params), 'Missing optimizer state')
                    steps = sorted({int(v['step']) for v in slots.values()})
                    moments = {f'{i}:{key}': value.detach().clone() for i, slot in slots.items()
                               for key, value in slot.items() if torch.is_tensor(value)}
                    row = {'step': int(state.global_step), 'optimizer_steps': steps,
                           'changed': any(bool(v.ne(0).any()) for v in delta.values())}
                    if branch == 'standard':
                        update_refs.append({'parameters': params, 'delta': delta, 'moments': moments})
                    else:
                        ref = update_refs[len(updates)]
                        for key, values in (('parameters', params), ('delta', delta), ('moments', moments)):
                            row[key] = compare(values, ref[key])
                        row['passed_B'] = steps == [int(state.global_step)] and row['changed'] and all(row[k]['passed_B'] for k in ('parameters', 'delta', 'moments'))
                    updates.append(row)

            arguments = TrainingArguments(output_dir=str(directory / branch), use_cpu=True,
                num_train_epochs=1, per_device_train_batch_size=1, gradient_accumulation_steps=accum,
                learning_rate=1e-4, weight_decay=0.0, optim='adamw_torch', lr_scheduler_type='constant',
                warmup_steps=0, max_grad_norm=1.0, bf16=False, fp16=False,
                gradient_checkpointing=True, gradient_checkpointing_kwargs={'use_reentrant': False},
                report_to='none', seed=42, data_seed=42, remove_unused_columns=False,
                dataloader_drop_last=False, dataloader_num_workers=0, dataloader_pin_memory=False,
                save_strategy='no', logging_strategy='no', disable_tqdm=True)
            trainer = cls(model=model, args=arguments, train_dataset=[{**f, '_audit_index': i} for i, f in enumerate(features[:count])],
                          data_collator=Collator(padded, eos_pad), callbacks=[Updates()])
            need(trainer.model_accepts_loss_kwargs, 'Trainer does not use cycle token denominator')
            trainer.branch, trainer.case, trainer.micros, trainer.references = branch, name, [], refs
            trainer.train()
            validate_history(trainer.micros, updates, count, accum, padded)
            branches[branch] = {'micros': trainer.micros, 'updates': updates,
                                'initial_lora_sha256': digest(initial), 'history_valid': True}
            write(directory / (branch + '.json'), branches[branch])
            trainer.optimizer.state.clear(); trainer.optimizer = None; trainer.lr_scheduler = None
            del trainer
            model.zero_grad(set_to_none=True); gc.collect()
        actual_pass = branch_pass(branches['candidate']['micros'], branches['candidate']['updates'])
        numeric_rejected = any(not r['gradients']['passed_B'] or not r['loss']['passed_B'] for r in branches['candidate']['micros'])
        actual_A = all(r['passed_A'] for r in branches['candidate']['micros'])
        case = {'passed': (actual_pass and actual_A) if fault is None else (not actual_pass and numeric_rejected),
                'expected_negative': fault, 'candidate_passed_B': actual_pass,
                'candidate_passed_A_loss_gradients': actual_A,
                'count': count, 'accumulation': accum, 'padded': padded, 'eos_as_pad': eos_pad,
                'loss_max_abs': max(r['loss']['max_abs'] for r in branches['candidate']['micros']),
                'gradient_max_abs': max(r['gradients']['max_abs'] for r in branches['candidate']['micros']),
                'parameter_max_abs': max(r['parameters']['max_abs'] for r in branches['candidate']['updates']),
                'delta_max_abs': max(r['delta']['max_abs'] for r in branches['candidate']['updates']),
                'updates': len(branches['candidate']['updates']),
                'artifacts': [str(directory / (b + '.json')) for b in branches]}
        write(directory / 'case_result.json', case)
        summary['cases'][name] = case
        write(output / 'summary.json', summary)
        print('CASE=' + json.dumps(case), flush=True)
        del refs, update_refs, branches
        gc.collect()
    need(digest({n: p for n, p in model.named_parameters() if not p.requires_grad}) == base_before,
         'Frozen tiny base parameters changed')
    need(not torch.cuda.is_initialized(), 'CUDA initialized unexpectedly')
    summary['cuda_initialized'] = False
    summary['all_required_cases_present'] = set(summary['cases']) == {x[0] for x in CASES}
    passed = summary['all_required_cases_present'] and all(x['passed'] for x in summary['cases'].values())
    summary['status'] = 'FP32_TINY_ACTUAL_TRAINER_PASS_NOT_27B_ACCEPTANCE' if passed else 'FP32_EQUIVALENCE_NOT_ESTABLISHED'
    write(output / 'summary.json', summary)
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixtures', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--threads', type=int, default=4)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    try:
        code = run(args.output_dir, args.fixtures, args.config, args.threads)
    except Exception as exc:
        traceback.print_exc()
        p = args.output_dir / 'summary.json'
        d = json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
        d.update(status='FP32_WORKER_FAILED', error_type=type(exc).__name__, error=str(exc))
        write(p, d); code = 1
    (args.output_dir / 'exit_code.txt').write_text(str(code) + '\n', encoding='utf-8')
    return code


if __name__ == '__main__':
    sys.exit(main())
