"""v3a launcher: distinguish distribution metadata from Torch runtime build.

Numerical code, data and tolerances are byte-identical to v3.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import tempfile
import traceback
import zipfile

ROOT = Path('/home/admire/citation_integrity_member2/incoming/quality_v1_20261009/cmj_gpu_validation_v2_20261025')
POINTER = 'LAST_FP32_REVISION_V3_RUN.txt'


def need(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def read_bundle(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        need(len(names) == len(set(names)), 'Duplicate archive member')
        for name in names:
            p = PurePosixPath(name)
            need(not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name,
                 'Unsafe archive path')
        manifest = json.loads(z.read('manifest.json'))
        need(set(names) == set(manifest['files']) | {'manifest.json'}, 'Unlisted/missing package files')
        files = {n: z.read(n) for n in manifest['files']}
    for name, data in files.items():
        need(digest(data) == manifest['files'][name], 'Package hash mismatch: ' + name)
    return manifest, files


def environment():
    versions = {}
    for name in ('torch', 'transformers', 'peft', 'accelerate', 'datasets'):
        try: versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError: versions[name] = None
    return {'python': sys.version, 'platform': platform.platform(), 'versions': versions,
            'CUDA_VISIBLE_DEVICES_for_worker': '', 'threads': 4}


def probe_torch_runtime():
    # Probe in the same interpreter as the future worker, with CUDA hidden.
    # Importing Torch and reading these attributes does not load a model.
    program = (
        "import json,torch; print('TORCH_RUNTIME=' + json.dumps({"
        "'version':str(torch.__version__),'cuda':torch.version.cuda,"
        "'module_file':torch.__file__,'cuda_initialized':torch.cuda.is_initialized()}))"
    )
    result = subprocess.run([sys.executable, '-c', program],
                            env={**os.environ, 'CUDA_VISIBLE_DEVICES': '', 'PYTHONUTF8': '1'},
                            stdin=subprocess.DEVNULL, capture_output=True, text=True,
                            encoding='utf-8', errors='replace', timeout=60)
    need(result.returncode == 0, 'Torch runtime import failed: ' + result.stderr[-2000:])
    lines = [line.removeprefix('TORCH_RUNTIME=') for line in result.stdout.splitlines()
             if line.startswith('TORCH_RUNTIME=')]
    need(len(lines) == 1, 'Torch runtime probe did not return one record')
    return json.loads(lines[0])


def validate_environment(env, manifest):
    policy = manifest['torch_version_policy']
    actual_metadata = env['versions'].get('torch')
    runtime = env.get('torch_runtime', {})
    need(actual_metadata in policy['accepted_metadata_versions'],
         'Torch distribution version differs: ' + str(actual_metadata))
    need(runtime.get('version') in policy['accepted_runtime_versions'],
         'Torch runtime version differs: ' + str(runtime.get('version')))
    need(runtime.get('cuda') == policy['required_runtime_cuda'],
         'Torch CUDA build differs: ' + str(runtime.get('cuda')))
    need(runtime.get('cuda_initialized') is False, 'CPU preflight unexpectedly initialized CUDA')
    for name, expected in manifest['a100_required_versions'].items():
        if name != 'torch':
            need(env['versions'].get(name) == expected,
                 'A100 environment changed: ' + name + '=' + str(env['versions'].get(name)))
    return {'passed': True, 'torch_metadata_version': actual_metadata,
            'torch_runtime_version': runtime['version'], 'torch_runtime_cuda': runtime['cuda'],
            'policy': policy}


def checked_run(root, explicit=None):
    directory = Path(explicit or (root / POINTER).read_text(encoding='utf-8').strip()).resolve()
    need(directory.is_relative_to((root / 'fp32_revision_v3_runs').resolve()), 'Run outside expected directory')
    need((directory / 'run_metadata.json').is_file(), 'No run metadata')
    return directory


def worker(directory):
    metadata_path = directory / 'run_metadata.json'
    metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
    code = 1
    try:
        manifest, files = read_bundle(directory / 'execution.pyz')
        for name, expected in manifest['files'].items():
            need(digest((directory / 'assets' / name).read_bytes()) == expected,
                 'Extracted payload changed before execution: ' + name)
        metadata.update(status='RUNNING', worker_started_utc=utc())
        write(metadata_path, metadata)
        assets = directory / 'assets'
        env = {**os.environ, 'CUDA_VISIBLE_DEVICES': '', 'HF_HUB_OFFLINE': '1',
               'TRANSFORMERS_OFFLINE': '1', 'PYTHONUTF8': '1', 'TOKENIZERS_PARALLELISM': 'false',
               'OMP_NUM_THREADS': '4', 'MKL_NUM_THREADS': '4'}
        command = [sys.executable, '-u', str(assets / 'test_supervised_logits_equivalence_v3.py'),
                   '--fixtures', str(assets / 'fixtures.json'), '--config', str(assets / 'tiny_config.json'),
                   '--output-dir', str(directory / 'result'), '--threads', '4']
        metadata['command'] = command; write(metadata_path, metadata)
        code = subprocess.call(command, env=env, cwd=directory, stdin=subprocess.DEVNULL)
        summary_path = directory / 'result/summary.json'
        summary = json.loads(summary_path.read_text(encoding='utf-8')) if summary_path.exists() else {}
        if code == 0 and summary.get('status') != 'FP32_TINY_ACTUAL_TRAINER_PASS_NOT_27B_ACCEPTANCE':
            code = 1
        metadata.update(status=summary.get('status', 'WORKER_FAILED_NO_SUMMARY'), exit_code=code,
                        summary_sha256=digest(summary_path.read_bytes()) if summary_path.exists() else None)
    except Exception as exc:
        traceback.print_exc()
        metadata.update(status='LAUNCHER_WORKER_FAILED', error=str(exc), exit_code=1)
    finally:
        metadata['finished_utc'] = utc(); write(metadata_path, metadata)
        (directory / 'exit_code.txt').write_text(str(code) + '\n', encoding='utf-8')
    return code


def collect(directory):
    need((directory / 'exit_code.txt').exists(), 'Execution has not finished')
    metadata = json.loads((directory / 'run_metadata.json').read_text(encoding='utf-8'))
    paths = sorted(p for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    manifest = {str(p.relative_to(directory)).replace('\\', '/'): digest(p.read_bytes()) for p in paths}
    archive = directory.with_suffix('.zip')
    if archive.exists():
        with zipfile.ZipFile(archive) as z:
            existing = json.loads(z.read('handoff_manifest.json'))
            need(existing['files'] == manifest, 'Existing handoff differs; refusing overwrite')
            need(all(digest(z.read(n)) == h for n, h in manifest.items()), 'Existing handoff corrupt')
    else:
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
            for p in paths: z.write(p, str(p.relative_to(directory)).replace('\\', '/'))
            z.writestr('handoff_manifest.json', json.dumps({'scope': metadata['scope'], 'files': manifest}, indent=2))
        with zipfile.ZipFile(archive) as z:
            need(z.testzip() is None, 'Handoff CRC check failed')
            need(all(digest(z.read(n)) == h for n, h in manifest.items()), 'Handoff content hash mismatch')
    print('handoff=' + str(archive))
    print('sha256=' + digest(archive.read_bytes()))
    return archive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--inspect', action='store_true')
    mode.add_argument('--launch', action='store_true')
    mode.add_argument('--status', action='store_true')
    mode.add_argument('--collect', action='store_true')
    mode.add_argument('--worker', type=Path, help=argparse.SUPPRESS)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--run-dir', type=Path)
    args = parser.parse_args()
    if args.worker:
        return worker(args.worker)
    if args.status or args.collect:
        directory = checked_run(args.root, args.run_dir)
        if args.collect:
            collect(directory); return 0
        metadata = json.loads((directory / 'run_metadata.json').read_text(encoding='utf-8'))
        print('run_dir=' + str(directory)); print('status=' + metadata['status'])
        done = directory / 'exit_code.txt'
        print('exit_code=' + (done.read_text().strip() if done.exists() else 'RUNNING_OR_INTERRUPTED'))
        log = directory / 'run.log'
        if log.exists(): print('\n'.join(log.read_text(encoding='utf-8', errors='replace').splitlines()[-8:]))
        return 0
    bundle = Path(sys.argv[0]).resolve()
    manifest, files = read_bundle(bundle)
    env = environment()
    env['torch_runtime'] = probe_torch_runtime()
    if args.inspect:
        print(json.dumps({'package_hashes_verified': len(files), 'scope': manifest['scope'], 'environment': env}, indent=2))
        return 0
    need(os.name == 'posix', '--launch is for the A100 Linux host; use test script for local verification')
    env['preflight_validation'] = validate_environment(env, manifest)
    if (args.root / POINTER).exists():
        prior = checked_run(args.root)
        need((prior / 'exit_code.txt').exists(), 'Prior v3 run has no terminal record; inspect it before launching again')
    parent = args.root / 'fp32_revision_v3_runs'; parent.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix='fp32_v3_' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ_'), dir=parent))
    assets = directory / 'assets'; assets.mkdir()
    for name, data in files.items():
        target = assets / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
    write(assets / 'manifest.json', manifest)
    frozen = directory / 'execution.pyz'; frozen.write_bytes(bundle.read_bytes())
    metadata = {'status': 'PREPARED', 'created_utc': utc(), 'scope': manifest['scope'],
                'package_sha256': digest(frozen.read_bytes()), 'environment': env,
                'GPU_model_run': False, 'full_training': False}
    write(directory / 'run_metadata.json', metadata)
    with (directory / 'run.log').open('wb') as log:
        child = subprocess.Popen([sys.executable, '-u', str(frozen), '--worker', str(directory)],
                                 stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                 start_new_session=True, cwd=directory)
    # The worker owns metadata once spawned; keep PID separate to avoid a race.
    (directory / 'pid.txt').write_text(str(child.pid) + '\n', encoding='utf-8')
    (args.root / POINTER).write_text(str(directory) + '\n', encoding='utf-8')
    print('LAUNCHED_FP32_CPU_ONLY pid=' + str(child.pid))
    print('run_dir=' + str(directory))
    print('Launching is not completion; use --status, then --collect.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        traceback.print_exc(); raise SystemExit(1)
