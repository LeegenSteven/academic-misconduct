"""Real 27B/NF4 comparison through native Trainer.train and the exact candidate.

References are stored on CPU/disk. No historical adapter is loaded or changed.
GPU numerical equivalence is established only by the resulting measurements.
"""
from __future__ import annotations

import gc
import hashlib
import inspect
import json
import math
from pathlib import Path
from types import SimpleNamespace


LOSS_ATOL, LOSS_RTOL = 1e-6, 1e-5
TENSOR_ATOL, TENSOR_RTOL = 1e-6, 1e-4
SCRIPT_LOSS, SCRIPT_GRAD = 1e-5, 1e-4
LABELS = ("ACCURATE", "NOT_ACCURATE", "IRRELEVANT")
CASES = (
    ("single_micro", 5, 1, False, False),
    ("accum4_tail1", 5, 4, False, False),
    ("padded_accum4_tail1", 5, 4, True, False),
    ("production_accum16_tail13", 29, 16, False, False),
    ("eos_as_pad_accum4_tail1", 5, 4, True, True),
)


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n", encoding="utf-8")


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for part in iter(lambda: f.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def loss_comparison(actual, reference):
    finite = math.isfinite(actual) and math.isfinite(reference)
    difference = abs(actual - reference) if finite else None
    return {"finite": finite, "max_abs": difference,
            "passed_A": finite and difference < SCRIPT_LOSS,
            "passed_B": finite and difference <= LOSS_ATOL + LOSS_RTOL * abs(reference)}


def select_records(items, count=29):
    """Whole short Train records only; no truncation, replacement or relabeling."""
    ordered = sorted(items, key=lambda x: (len(x["feature"]["input_ids"]), x["index"]))
    selected = []
    for label in LABELS:
        candidates = [r for r in ordered if r["label"] == label]
        need(candidates, "No complete short Train record for " + label)
        selected.append(candidates[0])
    used = {r["index"] for r in selected}
    for row in ordered:
        if len(selected) >= count:
            break
        if row["index"] not in used:
            selected.append(row)
            used.add(row["index"])
    need(len(selected) == count, "Insufficient whole short Train records")
    need(len({sum(t != -100 for t in r["feature"]["labels"]) for r in selected[:5]}) >= 2,
         "First five records must cover variable supervised target lengths")
    return selected


def validate_history(micros, updates, count, accum, padded):
    need(len(micros) == count, "Missing microbatch events")
    need(sorted(r["sample_index"] for r in micros) == list(range(count)), "Repeated/missing input record")
    need([r["global_step"] for r in updates] == list(range(1, math.ceil(count / accum) + 1)),
         "Missing or overwritten full/tail optimizer cycle")
    for start in range(0, count, accum):
        cycle = micros[start:start + accum]
        denominator = sum(r["supervised_tokens"] for r in cycle)
        need(all(r["num_items_in_batch"] == denominator for r in cycle), "Incorrect cycle token denominator")
        need(all(r["actual_accumulation_steps"] == len(cycle) for r in cycle), "Incorrect tail accumulation count")
    need(all((r["padding_tokens"] > 0) == padded for r in micros), "Actual padding coverage differs")
    need(all(r["eos_supervised"] for r in micros), "Assistant EOS supervision was lost")


def run(output, assets, model_path, package_info):
    import torch
    import torch.nn.functional as F
    from datasets import Dataset
    from safetensors import safe_open
    from safetensors.torch import save_file
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from transformers import Trainer, TrainerCallback, TrainingArguments, set_seed
    from peft import LoraConfig, TaskType, get_peft_model, prepare_model_for_kbit_training
    from cmj.route1_qwen38_train_sarol_memopt_v1 import SupervisedLogitsTrainer
    from shared.route1_qwen38.data_contract import AssistantOnlyCollator, encode_assistant_record, load_gold, load_records

    need(torch.cuda.is_available() and torch.cuda.device_count() == 1, "Expected exactly one selected CUDA device")
    torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    set_seed(42)
    tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True, trust_remote_code=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    need(tokenizer.eos_token_id is not None, "Tokenizer has no EOS")
    need(tokenizer.padding_side in ("left", "right"), "Unexpected padding side")
    records = load_records(assets / "data/train.inputs.jsonl", load_gold(assets / "data/train.gold.jsonl", split="train"))
    need(len(records) == 2141, "Train count differs")
    short = []
    for index, record in enumerate(records):
        feature = encode_assistant_record(record, tokenizer, 5120)
        need(feature["labels"][0] == -100, "First token must not be a causal target")
        if len(feature["input_ids"]) <= 768:
            short.append({"index": index, "claim_id": record["claim_id"], "label": record["label"], "feature": feature})
    selected = select_records(short)
    write(output / "selected_train_records.json", {
        "policy": "Complete real Train examples <=768 tokens; shortest per class then shortest remaining; numerical coverage only",
        "max_training_length": 5120, "truncated": False, "records": selected})
    (output / "actual_runtime_sources.txt").write_text("\n\n".join(inspect.getsource(obj) for obj in (
        Trainer.training_step, Trainer.compute_loss, Trainer._inner_training_loop, SupervisedLogitsTrainer)), encoding="utf-8")

    model = AutoModelForCausalLM.from_pretrained(str(model_path), local_files_only=True, trust_remote_code=True,
        device_map={"": 0}, quantization_config=BitsAndBytesConfig(load_in_4bit=True,
        bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True))
    model.config.use_cache = False
    model = prepare_model_for_kbit_training(model)
    model = get_peft_model(model, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.0, bias="none",
        task_type=TaskType.CAUSAL_LM, target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]))
    generator = torch.Generator(device="cpu").manual_seed(314159)
    with torch.no_grad():
        for name, p in model.named_parameters():
            if p.requires_grad:
                need("lora_" in name, "Unexpected trainable parameter: " + name)
                p.copy_((torch.randn(p.shape, generator=generator, dtype=torch.float32) * 0.02).to(p.device, dtype=p.dtype))
    for module in model.modules():
        if isinstance(module, torch.nn.Dropout):
            need(module.p == 0.0, "Numerical test requires dropout zero; smoke training keeps original 0.05")

    def snapshot(gradients=False):
        values, missing = {}, []
        for name, p in model.named_parameters():
            if not p.requires_grad:
                continue
            value = p.grad if gradients else p
            if value is None:
                missing.append(name)
            else:
                cpu = value.detach().to(device="cpu", dtype=torch.float32).contiguous().clone()
                need(bool(torch.isfinite(cpu).all()), "Nonfinite trainable tensor: " + name)
                values[name] = cpu
        need(values and not missing, "Empty or missing trainable gradients/parameters: " + str(missing[:5]))
        return values

    initial = snapshot()
    need(any("lora_A" in n for n in initial) and any("lora_B" in n for n in initial), "LoRA A/B coverage missing")
    need(all(bool(v.ne(0).any()) for v in initial.values()), "Degenerate zero LoRA initialization")
    save_file(initial, str(output / "initial_trainable.safetensors"))

    def compare_reference(values, reference):
        details = []
        with safe_open(str(reference), framework="pt", device="cpu") as f:
            ref_names, names = set(f.keys()), set(values)
            same_names = bool(names) and names == ref_names
            for name in sorted(names & ref_names):
                actual, expected = values[name], f.get_tensor(name)
                valid = actual.shape == expected.shape and bool(torch.isfinite(expected).all())
                difference = float((actual - expected).abs().max()) if valid else None
                details.append({"name": name, "max_abs": difference,
                    "passed_A": valid and difference < SCRIPT_GRAD,
                    "passed_B": valid and bool(torch.allclose(actual, expected, atol=TENSOR_ATOL, rtol=TENSOR_RTOL))})
        return {"same_names": same_names, "missing_names": sorted(ref_names - names), "extra_names": sorted(names - ref_names),
            "tensor_count": len(details), "max_abs": max((r["max_abs"] for r in details if r["max_abs"] is not None), default=None),
            "passed_A": same_names and all(r["passed_A"] for r in details),
            "passed_B": same_names and all(r["passed_B"] for r in details), "per_tensor": details}

    class Collator:
        def __init__(self, padded, eos_pad):
            self.padded = padded
            self.pad_id = tokenizer.eos_token_id if eos_pad else tokenizer.pad_token_id
            self.base = AssistantOnlyCollator(SimpleNamespace(pad_token_id=self.pad_id, padding_side=tokenizer.padding_side))

        def __call__(self, rows):
            need(len(rows) == 1, "Microbatch must be one")
            row = dict(rows[0])
            index = row.pop("_audit_index")
            if self.padded:
                extra = 3 + index % 5
                for key, fill in (("input_ids", self.pad_id), ("attention_mask", 0), ("labels", -100)):
                    row[key] = row[key] + [fill] * extra if tokenizer.padding_side == "right" else [fill] * extra + row[key]
            batch = self.base([row])
            need(bool(batch["labels"][batch["attention_mask"].eq(0)].eq(-100).all()), "Padding is supervised")
            batch["_audit_index"] = torch.tensor([index])
            return batch

    class Observe:
        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            labels = inputs["labels"]
            loss, outputs = super().compute_loss(model, dict(inputs), return_outputs=True, num_items_in_batch=num_items_in_batch)
            self._raw_loss = float(loss.detach())
            need(math.isfinite(self._raw_loss), "Nonfinite loss")
            if self._branch == "standard":
                with torch.no_grad():
                    shifted = F.pad(labels, (0, 1), value=-100)[:, 1:]
                    summed = F.cross_entropy(outputs.logits.float().reshape(-1, outputs.logits.shape[-1]),
                        shifted.reshape(-1), ignore_index=-100, reduction="sum")
                    denominator = num_items_in_batch if num_items_in_batch is not None else shifted.ne(-100).sum()
                    oracle = float(summed / denominator)
                need(loss_comparison(self._raw_loss, oracle)["passed_B"], "Native standard loss disagrees with token-sum oracle")
            return (loss, outputs) if return_outputs else loss

        def training_step(self, model, inputs, num_items_in_batch=None):
            inputs = dict(inputs)
            index = int(inputs.pop("_audit_index").item())
            set_seed(42 + len(self._micros))
            signature = {k: inputs[k].tolist() for k in ("input_ids", "attention_mask", "labels")}
            row = {"micro_step": len(self._micros) + 1, "sample_index": index,
                "batch_sha256": hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest(),
                "supervised_tokens": int(inputs["labels"][:, 1:].ne(-100).sum()),
                "padding_tokens": int(inputs["attention_mask"].eq(0).sum()),
                "eos_supervised": bool(((inputs["input_ids"] == tokenizer.eos_token_id) & inputs["labels"].ne(-100)).any()),
                "num_items_in_batch": int(num_items_in_batch) if num_items_in_batch is not None else None,
                "actual_accumulation_steps": int(self.current_gradient_accumulation_steps)}
            result = super().training_step(model, inputs, num_items_in_batch=num_items_in_batch)
            row.update(raw_loss=self._raw_loss, returned_scaled_loss=float(result))
            need(math.isfinite(row["returned_scaled_loss"]), "Nonfinite returned loss")
            event = f"micro_{row['micro_step']:03}"
            values = snapshot(True)
            ref = self._case_dir / "standard" / (event + ".safetensors")
            if self._branch == "standard":
                save_file(values, str(ref))
                row["gradient_reference_sha256"] = sha(ref)
            else:
                prior = json.loads((self._case_dir / "standard" / (event + ".json")).read_text(encoding="utf-8"))
                need(sha(ref) == prior["gradient_reference_sha256"], "Reference gradients changed")
                row["same_execution"] = all(row[k] == prior[k] for k in (
                    "sample_index", "batch_sha256", "num_items_in_batch", "actual_accumulation_steps", "supervised_tokens", "padding_tokens", "eos_supervised"))
                row["raw_loss_comparison"] = loss_comparison(row["raw_loss"], prior["raw_loss"])
                row["scaled_loss_comparison"] = loss_comparison(row["returned_scaled_loss"], prior["returned_scaled_loss"])
                row["gradients"] = compare_reference(values, ref)
                row["passed_A"] = row["same_execution"] and all(row[k]["passed_A"] for k in ("raw_loss_comparison", "scaled_loss_comparison", "gradients"))
                row["passed_B"] = row["same_execution"] and all(row[k]["passed_B"] for k in ("raw_loss_comparison", "scaled_loss_comparison", "gradients"))
            del values
            self._micros.append(row)
            write(self._case_dir / self._branch / (event + ".json"), row)
            print(f"GPU_MICRO case={self._case_dir.name} branch={self._branch} step={row['micro_step']} cycle_tokens={row['num_items_in_batch']} loss={self._raw_loss:.8f}", flush=True)
            return result

    class Standard(Observe, Trainer):
        pass

    class Fixed(Observe, SupervisedLogitsTrainer):
        pass

    class Updates(TrainerCallback):
        def __init__(self, branch, directory, rows):
            self.branch, self.directory, self.rows = branch, directory, rows

        def on_train_begin(self, args, state, control, **kwargs):
            need(not kwargs["optimizer"].state_dict()["state"], "Optimizer state must start empty")

        def on_step_end(self, args, state, control, **kwargs):
            values = snapshot()
            event = f"update_{state.global_step:03}"
            ref = self.directory / "standard" / (event + ".safetensors")
            row = {"global_step": int(state.global_step),
                   "parameters_changed": any(not torch.equal(v, initial[n]) for n, v in values.items())}
            need(row["parameters_changed"], "Degenerate optimizer update")
            if self.branch == "standard":
                save_file(values, str(ref))
                row["parameter_reference_sha256"] = sha(ref)
            else:
                prior = json.loads((self.directory / "standard" / (event + ".json")).read_text(encoding="utf-8"))
                need(sha(ref) == prior["parameter_reference_sha256"], "Reference parameters changed")
                row["parameters_B"] = compare_reference(values, ref)
                row["parameters_B"].pop("passed_A", None)
                for detail in row["parameters_B"]["per_tensor"]:
                    detail.pop("passed_A", None)
            del values
            self.rows.append(row)
            write(self.directory / self.branch / (event + ".json"), row)

    summary = {"status": "RUNNING", "scope": "Real 27B/NF4; whole short Train subset; actual native Trainer and exact repaired trainer. Not historical checkpoint repair or full-Train performance.",
        "package": package_info, "candidate_trainer_sha256": sha(assets / "code/cmj/route1_qwen38_train_sarol_memopt_v1.py"),
        "loaded_model_class": type(model.get_base_model()).__name__, "dropout_for_numerical_test": 0.0,
        "original_smoke_training_dropout": 0.05, "nonzero_lora_A_B_initialization": True,
        "tolerance_A": {"loss_abs_strict_lt": SCRIPT_LOSS, "gradient_abs_strict_lt": SCRIPT_GRAD, "parameters": "not specified by original A protocol; assessed separately under B"},
        "tolerance_B": {"loss_atol": LOSS_ATOL, "loss_rtol": LOSS_RTOL, "tensor_atol": TENSOR_ATOL, "tensor_rtol": TENSOR_RTOL},
        "cases": {}, "frozen_adapters_modified": False}
    write(output / "equivalence_results.json", summary)
    for name, count, accum, padded, eos_pad in CASES:
        directory = output / name
        directory.mkdir()
        case = {"count": count, "accumulation": accum, "padded": padded, "eos_as_pad": eos_pad, "branches": {}}
        for branch, cls in (("standard", Standard), ("fixed", Fixed)):
            trainer = None
            (directory / branch).mkdir()
            try:
                with torch.no_grad():
                    for n, p in model.named_parameters():
                        if p.requires_grad:
                            p.copy_(initial[n].to(p.device, dtype=p.dtype))
                model.zero_grad(set_to_none=True)
                set_seed(42)
                updates = []
                arguments = TrainingArguments(output_dir=str(directory / branch / "trainer_output"),
                    num_train_epochs=1, per_device_train_batch_size=1, gradient_accumulation_steps=accum,
                    learning_rate=1e-4, optim="adamw_torch", weight_decay=0.0, warmup_steps=0,
                    lr_scheduler_type="constant", max_grad_norm=1.0, bf16=True, fp16=False,
                    gradient_checkpointing=True, gradient_checkpointing_kwargs={"use_reentrant": False},
                    report_to="none", seed=42, data_seed=42, remove_unused_columns=False,
                    dataloader_drop_last=False, dataloader_num_workers=0, dataloader_pin_memory=False,
                    save_strategy="no", logging_strategy="no", disable_tqdm=True)
                dataset = Dataset.from_list([{**r["feature"], "_audit_index": i} for i, r in enumerate(selected[:count])])
                trainer = cls(model=model, args=arguments, train_dataset=dataset, data_collator=Collator(padded, eos_pad),
                              callbacks=[Updates(branch, directory, updates)])
                trainer._branch, trainer._case_dir, trainer._micros = branch, directory, []
                need(trainer.model_accepts_loss_kwargs, "Native or candidate trainer does not receive cycle token counts")
                result = trainer.train()
                validate_history(trainer._micros, updates, count, accum, padded)
                record = {"executed": True, "history_valid": True, "microbatches": trainer._micros,
                          "optimizer_updates": updates, "train_result": result.metrics}
                if branch == "fixed":
                    record["passed_A_loss_gradients"] = all(r["passed_A"] for r in trainer._micros)
                    record["passed_B_including_parameters"] = all(r["passed_B"] for r in trainer._micros) and all(r["parameters_B"]["passed_B"] for r in updates)
                case["branches"][branch] = record
            except Exception as exc:
                import traceback
                traceback.print_exc()
                case["branches"][branch] = {"executed": False, "error_type": type(exc).__name__, "error": str(exc)}
            finally:
                if trainer is not None:
                    if trainer.optimizer is not None:
                        trainer.optimizer.state.clear()
                    trainer.optimizer, trainer.lr_scheduler = None, None
                del trainer
                model.zero_grad(set_to_none=True)
                gc.collect()
                torch.cuda.empty_cache()
            write(directory / "case_result.json", case)
            if not case["branches"][branch].get("executed"):
                break
        fixed = case["branches"].get("fixed", {})
        case["passed_A_loss_gradients"] = fixed.get("passed_A_loss_gradients", False)
        case["passed_B_including_parameters"] = fixed.get("passed_B_including_parameters", False)
        summary["cases"][name] = case
        write(directory / "case_result.json", case)
        write(output / "equivalence_results.json", summary)
    summary["passed_A_loss_gradients"] = all(r["passed_A_loss_gradients"] for r in summary["cases"].values())
    summary["passed_B_including_parameters"] = all(r["passed_B_including_parameters"] for r in summary["cases"].values())
    summary["status"] = "TESTED_27B_NF4_EQUIVALENCE_PASS" if summary["passed_A_loss_gradients"] and summary["passed_B_including_parameters"] else "EQUIVALENCE_NOT_ESTABLISHED"
    summary["peak_allocated_bytes"] = int(torch.cuda.max_memory_allocated())
    summary["peak_reserved_bytes"] = int(torch.cuda.max_memory_reserved())
    write(output / "equivalence_results.json", summary)
    return summary
